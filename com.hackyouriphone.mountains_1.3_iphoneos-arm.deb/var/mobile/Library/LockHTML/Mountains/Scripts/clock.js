	function updateDate() { 
		var currentTime = new Date();
		var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
		document.getElementById("dayOfWeek").innerHTML = days[currentTime.getDay()];
		document.getElementById("day").innerHTML = currentDate;
		document.getElementById("month").innerHTML = currentTime.getMonth() + 1;
		document.getElementById("year").innerHTML = currentTime.getFullYear();
	}
	function updateClock() { 
		var currentTime = new Date();
		var currentHours = currentTime.getHours();
		var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
		var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
		timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

		if (clock == "24h"){
			timeOfDay = "";
			currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
			currentTimeString = currentHours + ":" + currentMinutes;
		}
		if (clock == "12h"){
			currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
			currentHours = ( currentHours == 0 ) ? 12 : currentHours;
			currentTimeString = currentHours + ":" + currentMinutes;
		}

		document.getElementById("hour").innerHTML = currentHours;
		document.getElementById("minute").innerHTML = currentMinutes;
		//document.getElementById("ampm").innerHTML = timeOfDay;
	}
