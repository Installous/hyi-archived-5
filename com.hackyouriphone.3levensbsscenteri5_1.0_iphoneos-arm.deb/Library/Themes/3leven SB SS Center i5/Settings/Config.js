// Configuration Clock //







	var ampm = false;	  // change to true to display 12h clock







// Configuration Weather //







       var locale = "SPxx0059"	 // change the city. search your in weather.com



       var isCelsius = true	 // change to false to display degrees in Farenheit



       var updateInterval = 10	 // minutes







	var French = false;	 // change to true to display weather and date in French



	var German = false;	 // change to true to display weather and date in German



	var Spanish = false;	 // change to true to display weather and date in Spanish



	var Dutch = false;	 // change to true to display weather and date in Dutch