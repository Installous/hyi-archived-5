  // start the slideshow!
  $(document).ready(function () {
    $(".slideshow .slide.next").attr("src", slide[0].image).addClass("zoomIn").css("-webkit-transform-origin", slide[0].origin);
    setTimeout("slideShow()", 1000);
  });

  var slideIndex = 1;

  function slideShow() {
    showSlide(slideIndex);
    slideIndex++;
    if (slideIndex == slide.length) slideIndex = 0;
    setTimeout("slideShow()", slideRotation * 60 * 1000);
  }

  function showSlide(index) {
    var $curr = $(".slideshow .slide.current");
    var $last = $(".slideshow .slide.last");
    var $next = $(".slideshow .slide.next");
    $curr.addClass("last").removeClass("current").removeClass("zoomOut");
    $last.addClass("next").removeClass("last").removeClass("zoomOut").addClass("zoomIn").attr("src", slide[index].image).css("-webkit-transform-origin", slide[index].origin);
    $next.addClass("current").removeClass("next").removeClass("zoomIn").addClass("zoomOut");
  }
