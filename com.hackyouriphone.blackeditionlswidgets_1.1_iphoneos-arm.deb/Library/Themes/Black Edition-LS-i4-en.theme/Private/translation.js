function ForecastDayNames(day){

switch (day)
  {
//Use these to translate if necessary.  Change the second values, leave the first alone.
    case "Mon": { return "Mon" }
    case "Tue": { return "Tue" }
    case "Wed": { return "Wed" }
    case "Thu": { return "Thu" }
    case "Fri": { return "Fri" }
    case "Sat": { return "Sat" }
    case "Sun": { return "Sun" }
    case "Today": { return "Today" }
    case "Tonight": { return "Tonight" }
  }

}

var Francais =



[
"Tornade",
"Orage Tropical",
"Ouragan",
"Orages",
"Orages",
"Pluie et Neige",
"Pluie et Verglas",
"Neige et Verglas",
"Brouillard VerglaÃ§ant",
"Brouillard",
"Pluie VerglaÃ§ante",
"Averses",
"Averses",
"Bourrasques de neige",
"Petites chutes de neige",
"Chutes de neige - Vent",
"Neige",
"grÃªle",
"Verglas",
"Non communiquÃ©",
"brumeux",
"Brume",
"Non communiquÃ©",
"Non communiquÃ©",
"Vent",
"Froid",
"Nuageux",
"Passages nuageux",
"Passages nuageux",
"Passages nuageux",
"Passages nuageux",
"Ciel Clair",
"EnsoleillÃ©",
"Clair",
"Beau Temps",
"Pluie et GrÃªle mÃ©langÃ©es",
"TrÃ¨s Chaud",
"Passages nuageux avec orages",
"Orage et Ã©claircies",
"Orage et Ã©claircies",
"Pluies et Ã©claircies",
"Chute de neige importante",
"Petite chutes de neige",
"Chute de neige importante",
"Partiellement couvert",
"Tonnerre",
"Chutes de neige",
"Tonnerre et Ã©claircies",
"Pas d'info",
]


var English = "English" //Leave Alone