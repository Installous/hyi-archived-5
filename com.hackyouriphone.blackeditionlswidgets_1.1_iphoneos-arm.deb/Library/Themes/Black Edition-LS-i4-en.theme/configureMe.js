// Use weather.com to find your weathercode
// For example searching for London, UK will get you this URL
// http://www.weather.com/weather/today/London+United+Kingdom+UKXX0085
// The last part UKXX0085 is the weathercode to use
var locale = "USCA0273" //Zipcode, Postalcode, or Weathercode
var isCelsius = false //true or false
var useRealFeel = false 
var updateInterval = 10  //Minutes
var showForecast = true

// If you would rather use your own Lockscreen Background
// set showBackground to true and overwrite the included
// LockBackground.png file 
var showBackground = true

var showWeatherAni = false