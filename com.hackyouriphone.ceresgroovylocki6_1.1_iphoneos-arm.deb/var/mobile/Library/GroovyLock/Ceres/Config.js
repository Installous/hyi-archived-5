var Lang = "en"; // (fr) for French, (de) for German, (es) for Spanish, (it) for Italian, (en) for English
var Clock = "12"; // 12 or 24
var locale = "USMA0143"; // Here your weather code,if have problem contact me
var Temp = "f"; // c for Celsius, f for Fahrenheit
var updateInterval = 30; // choose the minutes for refresh automatically
var iconSet = "StyleiOS7"; // if don't have others no touch here!
var iconExt = ".png"; // icon extension
var useRealFeel = false; // true or false
