var Clock = "12h";	       // choose between "12h" or "24h"
var lang = "en";	       // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) for english


var color = "red";        // red , yellow, green, blue, lavender, darkblue, Grey
var slideshow = false;   // Enable or Disable slideshow.


var gps = true; 	      // Requires MyLocation app
var locale = 1252431;		 // Yahoo Weather (used if gps set to false or myLocation.txt file not found)
var tempUnit = "c";	       // f for fahrenheit
var iconSet = "Clima_white"	      // add your own set
var updateInterval = 15;       // in minutes

/*
Options below are for specific situations.
*/

var UseCityGPS = true;	      // If your city is innacurate with Yahoo, you can try to use the GPS localization (if available).
var UseNeighborhood = false;	// If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).



