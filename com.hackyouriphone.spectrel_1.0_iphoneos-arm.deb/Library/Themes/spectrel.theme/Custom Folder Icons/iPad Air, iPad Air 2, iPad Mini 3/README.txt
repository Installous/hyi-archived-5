Thanks for purchasing spectrel!

If you have a pirated version of spectrel, I encourage you to buy spectrel instead (it's only $2!) . Pirating is bad for the jailbreak community, and buying it is just the right thing to do :)

Any issues with spectrel or icon requests should be submitted at the spectrel website, http://comp0cker.wordpress.com/spectrel/. If you have any questions, comments, or concerns about spectrel, email me at spectrel@outlook.com.

Happy theming!

- comp0cker
