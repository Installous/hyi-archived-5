//Set your Lockscreen HERE!!!!
//User

//Support thread 
//Instructions http://JunesiPhone.com

var sUnit = "s";  // m for celcius s for fareinheit
var TwentyFourHourClock = "true"; //Set to true for 24hr false to 12hr.
var sCityCodes = "38671"; //weather code. Find from weather.com look in url.
var StickForecast="yes"; // if you want forecast to show without shake set to yes.
var kph="no"; //if set to yes it will display kph, if set to no will display mph



var TODWall="yes"; // Dont change
var s = $(this).attr("sCityCodes").substr(0, 2);
//dont mess

var sCityNames = "";
var aCityNames = sCityNames.split('|');
var aCityCodes = sCityCodes.split('|');
var code = aCityCodes[0];
var language = window.navigator.language;


//localize languages


// get weather //
function GetXmlFeed() {
   var lang = (typeof language == "string")?language.replace(/-/g, "_"):language;

   //var lang="fr-fr"; //Remove the first two // infront of var to use french replace with any language below

   //french is fr-fr
   //Spanish is es-es
   //German is 





   var sc = document.createElement("script");
  sc.src='http://wxdata.weather.com/wxdata/mobile/mobagg/' + code + '.js?key=2227ef4c-dfa4-11e0-80d5-0022198344f4&units=' + sUnit + '&locale=' + lang + '&cb=XmlFeedCB';
   document.body.appendChild(sc);
//alert(sc.src);


}


var textstringlater="Later Today:";

function XmlFeedCB(going){
  json = going[0];    //json is XML
  ShowContent();

}


function Showdata() {

var imagelocation="weather/icon/"
var imageextention=".png"
var degrees="&deg;"

var dailyinfo=json.DailyForecasts; // daily forecast
var hourlyinfo=json.HourlyForecasts; // hourly forecast
var narrativeinfo=json.NarrativeForecasts; // Narrative forecast
var raininfo=json.WhenWillItRain;
var sunriseset=json.SunRiseSet;
var hirad=json.HiradObservation;



daily=JSON.stringify(dailyinfo[0]);
hourly=JSON.stringify(hourlyinfo[0]);
narrative=JSON.stringify(narrativeinfo[0]);


//alert(daily)
//alert(hourly);
//alert(narrative);
//alert(raininfo)
//alert(sunrise);

sunrise=JSON.stringify(sunriseset[0].rise);
sunset=JSON.stringify(sunriseset[0].set);
sunrise = sunrise.replace(/"/g, "");
sunset = sunset.replace(/"/g, "");


// convert sunrise from UNIX time
var timestamp1 = sunrise;
  UX2 = new Date(timestamp1 * 1000),
    hours = (UX2.getHours() < 10 ? '0' + UX2.getHours() : UX2.getHours()),
    minutes = (UX2.getMinutes() < 10 ? '0' + UX2.getMinutes() : UX2.getMinutes()),
    seconds = (UX2.getSeconds() < 10 ? '0' + UX2.getSeconds() : UX2.getSeconds()),
    sunrise = hours + ':' + minutes;

if(TwentyFourHourClock=="false"){
  hours = hours % 12;
    if(hours == 0){hours += 12;}
    sunrise = hours + ':' + minutes;
}


// convert sunset from UNIX time
var timestamp = sunset;
  UX1 = new Date(timestamp * 1000),
    hours = (UX1.getHours() < 10 ? '0' + UX1.getHours() : UX1.getHours()),
    minutes = (UX1.getMinutes() < 10 ? '0' + UX1.getMinutes() : UX1.getMinutes()),
    seconds = (UX1.getSeconds() < 10 ? '0' + UX1.getSeconds() : UX1.getSeconds()),
    sunset = hours + ':' + minutes;

if(TwentyFourHourClock=="false"){
  hours = hours % 12;
    if(hours == 0){hours += 12;}
    sunset = hours + ':' + minutes;
}

//alert(sunrise);
//alert(sunset);



if(daily.day==undefined){
  var tod=dailyinfo[0].night;
}
else{
  var tod=dailyinfo[0].day;
}


//begin forecast
daily1=JSON.stringify(dailyinfo[1]);
daily2=JSON.stringify(dailyinfo[2]);
daily3=JSON.stringify(dailyinfo[3]);
daily4=JSON.stringify(dailyinfo[4]);


if(daily1.day==undefined){var day1=dailyinfo[1].day;var night1=dailyinfo[1].night;}else{var day2=daily2[1].night;}

if(daily2.day==undefined){var day2=dailyinfo[2].day;var night2=dailyinfo[2].night;}else{var day2=daily2[2].night;}

if(daily3.day==undefined){var day3=dailyinfo[3].day;var night3=dailyinfo[3].night;}else{var day1=daily3[3].night;}

if(daily4.day==undefined){var day4=dailyinfo[4].day;var night4=dailyinfo[4].night;}else{var day4=daily4[4].night;}

var daysize="80"; //set forecast image size
var iconlocation="weather/icon/"; //what folder to pull from
var iconextention=".png" //image extentions

var day1=iconlocation+day1.icon+iconextention;
var day2=iconlocation+day2.icon+iconextention;
var day3=iconlocation+day3.icon+"_small"+iconextention;
var day4=iconlocation+day4.icon+"_small"+iconextention;

var night1=iconlocation+night1.icon+iconextention;
var night2=iconlocation+night2.icon+iconextention;
var night3=iconlocation+night3.icon+"_small"+iconextention;
var night4=iconlocation+night4.icon+"_small"+iconextention;


document.getElementById("Day1").innerHTML = '<img width='+daysize+' src='+day1+'>'
document.getElementById("Day2").innerHTML = '<img width='+daysize+' src='+day2+'>'
document.getElementById("Day3").innerHTML = '<img width='+daysize+' src='+day3+'>'
document.getElementById("Day4").innerHTML = '<img width='+daysize+' src='+day4+'>'



var hightemp1=dailyinfo[1].maxTemp;
var hightemp2=dailyinfo[2].maxTemp;
var hightemp3=dailyinfo[3].maxTemp;
var hightemp4=dailyinfo[4].maxTemp;

var lowtemp1=dailyinfo[1].minTemp;
var lowtemp2=dailyinfo[2].minTemp;
var lowtemp3=dailyinfo[3].minTemp;
var lowtemp4=dailyinfo[4].minTemp;

var day1date=JSON.stringify(dailyinfo[1].validDate);
var day2date=JSON.stringify(dailyinfo[2].validDate);
var day3date=JSON.stringify(dailyinfo[3].validDate);
var day4date=JSON.stringify(dailyinfo[4].validDate);

var dayname1 = new Date(day1date * 1000);
var dayname2 = new Date(day2date * 1000);
var dayname3 = new Date(day3date * 1000);
var dayname4 = new Date(day4date * 1000);

var currentday1 = dayname1.getDay();
var currentday2 = dayname2.getDay();
var currentday3 = dayname3.getDay();
var currentday4 = dayname4.getDay();

var daysofweek = new Array("Sun","Mon","Tues","Wed","Thurs","Fri","Sat")




if(language=="fr-fr"){
 var daysofweek = new Array("Dim","Lun","Mar","Mer","Jeu","Ven","Dim")
}
if(language=="es-es"){
 var daysofweek = new Array("Dom","Lun","Mar","Mie","Jeu","Vie","Sab")
}


var currentday1=daysofweek[currentday1];
var currentday2=daysofweek[currentday2];

document.getElementById("ForecastDay1").innerHTML = '<span>' + (currentday1) + '</span>'
document.getElementById("ForecastDay2").innerHTML = '<span>' + (currentday2) + '</span>'


document.getElementById("Day1High").innerHTML = '<span>' + (hightemp1+degrees + " / "+lowtemp1+degrees) + '</span>'
document.getElementById("Day1Low").innerHTML = '<span>' + ("&#8675;"+lowtemp1+degrees) + '</span>'
document.getElementById("Day2High").innerHTML = '<span>' + (hightemp2+degrees+" / "+lowtemp2+degrees) + '</span>'
document.getElementById("Day2Low").innerHTML = '<span>' + ("&#8675;"+lowtemp2+degrees) + '</span>'
document.getElementById("Day3High").innerHTML = '<span>' + ("&#8673;"+hightemp3+degrees) + '</span>'
document.getElementById("Day3Low").innerHTML = '<span>' + ("&#8675;"+lowtemp3+degrees) + '</span>'
document.getElementById("Day4High").innerHTML = '<span>' + ("&#8673;"+hightemp4+degrees) + '</span>'
document.getElementById("Day4Low").innerHTML = '<span>' + ("&#8675;"+lowtemp4+degrees) + '</span>'



//////////////////////////////////////////////////////////////////////////////////
var iconToday=JSON.stringify(tod.icon);
var iconToday=imagelocation+iconToday+imageextention;
document.getElementById("IconToday").innerHTML = '<img width="320" src='+iconToday+'>'



////////////////////////////////////////////////////////////////////////////////////
var hiToday=JSON.stringify(+dailyinfo[0].maxTemp+degrees); //Today hi
hiToday = hiToday.replace(/"/g, "");
if(hiToday=="NaN"+degrees){hiToday="&#8734;"}      //If afternoon show NA


//////////////////////////////////////////////////////////////////////////////////
var loToday=JSON.stringify("/ "+dailyinfo[0].minTemp+degrees); //Today lo
loToday = loToday.replace(/"/g, "");
document.getElementById("LowToday").innerHTML = '<span>' + (hiToday + loToday) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var descToday=JSON.stringify(tod.phrase); //Today weather description
descToday = descToday.replace(/"/g, "");
if(descToday==""){var descToday=JSON.stringify(dailyinfo[0].night.phrase)};
descToday = descToday.replace(/"/g, "");


document.getElementById("DescToday").innerHTML = '<span>' + ( textstringlater + descToday) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var tempNow=JSON.stringify(hourlyinfo[0].temp+degrees); //Current Temp
tempNow = tempNow.replace(/"/g, "");
//document.getElementById("TempNow").innerHTML = '<span>' + ('' + tempNow) + '</span>'

// New
document.getElementById("TempNow").innerHTML = '<span>' + ('' + json.StandardObservation.temp+degrees) + '</span>'

//document.getElementById("TempNow").innerHTML = '<span>' + ('' + hirad.feelsLike) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var realFeel=JSON.stringify(hourlyinfo[0].feelsLike+degrees); //Current Temp
realFeel = realFeel.replace(/"/g, "");
document.getElementById("RealFeel").innerHTML = '<span>' + ('Feels Like:' + hirad.feelsLike) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var Humidity=JSON.stringify("Humidity:"+hourlyinfo[0].humid); //Humidity
Humidity = Humidity.replace(/"/g, "");
document.getElementById("Humidity").innerHTML = '<span>' + ('' + Humidity) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var WindSpeed=JSON.stringify(""+hourlyinfo[0].wSpeed); //Wind Speed
WindSpeed = WindSpeed.replace(/"/g, "");
document.getElementById("WindSpeed").innerHTML = '<span>' + ('' + WindSpeed+"Mph") + '</span>'

if(kph=="yes"){
conversion = 1.609344
kph = WindSpeed * conversion; 
kph = Math.round(kph * 100) / 100;
kph = Math.round(kph)
document.getElementById("WindSpeed").innerHTML = '<span>' + ('' + kph+"Kph") + '</span>'

}

//////////////////////////////////////////////////////////////////////////////////
var WindDirection=JSON.stringify(hourlyinfo[0].wDirText); //Wind Direction
WindDirection = WindDirection.replace(/"/g, "");
document.getElementById("WindDirection").innerHTML = '<span>' + ('' + WindDirection) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var UV=JSON.stringify("UV:"+hourlyinfo[0].uv); //UV
UV = UV.replace(/"/g, "");
document.getElementById("UV").innerHTML = '<span>' + ('' + UV) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var dew=JSON.stringify(""+hourlyinfo[0].dew+"&#176"); //dew

dew = dew.replace(/"/g, "");
document.getElementById("dew").innerHTML = '<span>' + ('' + dew) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var City=JSON.stringify(json.Location.city); //City
City = City.replace(/"/g, "");
document.getElementById("City").innerHTML = '<span>' + ('' + City) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var HourlyDesc=JSON.stringify(hourlyinfo[0].wDesc);
HourlyDesc = HourlyDesc.replace(/"/g, "");
document.getElementById("HourlyDesc").innerHTML = '<span>' + (json.StandardObservation.text) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
//var HourlyIcon=JSON.stringify(hourlyinfo[0].icon);
//var HourlyIcon=imagelocation+HourlyIcon+imageextention;
//document.getElementById("HourlyIcon").innerHTML = '<img width="150" src='+HourlyIcon+'>'


//New
if(json.StandardObservation.wxIcon==""){json.StandardObservation.wxIcon="na"};
var HourlyIcon=imagelocation+json.StandardObservation.wxIcon+imageextention;
document.getElementById("HourlyIcon").innerHTML = '<img width="150" src='+HourlyIcon+'>'



//////////////////////////////////////////////////////////////////////////////////
document.getElementById("RainInfo").innerHTML = '<span>' + (raininfo.standardPhrase) + '</span>'


//////////////////////////////////////////////////////////////////////////////////
var Sunrise=sunrise; //Sunrise
document.getElementById("Sunrise").innerHTML = '<span>' + ('Sunrise: ' + Sunrise) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var Sunset=sunset; //Sunset
document.getElementById("Sunset").innerHTML = '<span>' + ('Sunset: ' + Sunset) + '</span>'



  var currentTime = new Date ();
  var currentHours = currentTime.getHours ();
  var sunrise = sunrise.substr(1, sunrise.length-4);
  var sunset = sunset.substr(0, sunset.length-3);

  if(currentHours> sunset || currentHours<sunrise){
    var wallsizes="320";
    var imagesrc="Night.png"
    document.getElementById("TODWall").innerHTML = '<img width='+wallsizes+' src='+imagesrc+'>'
  }

  else{
    var wallsizes="320";
    var imagesrc="Day.png"
    document.getElementById("TODWall").innerHTML = '<img width='+wallsizes+' src='+imagesrc+'>'
  }




};



////////Date/Time////////////



function amPm()
{
  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );
}


function updateClock ()
{

  var currentTime = new Date ( );
  var currentHours = currentTime.getHours ( );
  var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( );
 currentHours = ( currentHours < 10 ? "0" : "") + currentHours;
 currentHours = ( currentHours == 0 ) ? 12 : currentHours;
 currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;



if (TwentyFourHourClock == "true"){var timeOfDay = "";}
  else{
  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM"
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;

  }





  var currentTimeString = currentHours + ":" + currentMinutes + timeOfDay;


    var this_date_name_array = new Array("00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31")
  var this_weekday_name_array = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
  var this_month_name_array = new Array("January","February","March","April","May","June","July","August","September","October","November","December")  //predefine month names
  var this_date_timestamp = new Date()
  var this_weekday = this_date_timestamp.getDay()
  var this_date = this_date_timestamp.getDate()
  var this_month = this_date_timestamp.getMonth()




//////////////////////
if(language=="fr-fr"){
 var this_month_name_array = new Array("Janvier","Févirer","Mar","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre")  //predefine month names
var this_weekday_name_array = new Array("Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi")
  
}

if(language=="es-es"){
 var this_month_name_array = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre")  //predefine month names
var this_weekday_name_array = new Array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado")
  
}

  var currentTimeString = currentHours + ":" + currentMinutes + timeOfDay+" / "+this_weekday_name_array[this_weekday]+", "+this_date_name_array[this_date]+" "+this_month_name_array[this_month];

  document.getElementById("time").firstChild.nodeValue = currentTimeString;


}



function ShowContent() {
  Showdata();
}

(function($){
$.fn.weather = function(options){
      GetXmlFeed(true);}

})($);




