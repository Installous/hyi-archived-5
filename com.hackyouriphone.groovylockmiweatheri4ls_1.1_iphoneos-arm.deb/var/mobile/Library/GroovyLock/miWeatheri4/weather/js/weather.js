//Set your Lockscreen HERE!!!!
//User

//Support thread http://modmyi.com/forums/iphone-5-new-skins-themes-launches/833804-miweather-groovylock.html
//Instructions http://JunesiPhone.com

var sUnit = "s";  // m for celcius s for fareinheit
var TwentyFourHourClock = "false"; //Set to true for 24hr false to 12hr.
var sCityCodes = "38671"; //weather code. Find from weather.com look in url.
var StickForecast="no"; // if you want forecast to show without shake set to yes.
var ShowNight="no"; // if you don't want night set to no, if you want night set to yes.
var UserWall="no"; // change if you want your own wallpaper set in user/library/GroovyLock/miWeather




var s = $(this).attr("sCityCodes").substr(0, 2);
//dont mess

var sCityNames = "";
var aCityNames = sCityNames.split('|');
var aCityCodes = sCityCodes.split('|');
var code = aCityCodes[0];
var language = window.navigator.language;

//localize languages


// get weather //
function GetXmlFeed() {
   var lang = (typeof language == "string")?language.replace(/-/g, "_"):language;
   var sc = document.createElement("script");
  sc.src='http://wxdata.weather.com/wxdata/mobile/mobagg/' + code + '.js?key=2227ef4c-dfa4-11e0-80d5-0022198344f4&units=' + sUnit + '&locale=' + lang + '&cb=XmlFeedCB';
	 document.body.appendChild(sc);
//alert(sc.src);
}


var textstringlater="Later Today:";

function XmlFeedCB(going){
	json = going[0];    //json is XML
  ShowContent();

}


function Showdata() {

var imagelocation="weather/icon/"
var imageextention=".jpg"
var degrees="&deg;"

var dailyinfo=json.DailyForecasts; // daily forecast
var hourlyinfo=json.HourlyForecasts; // hourly forecast
var narrativeinfo=json.NarrativeForecasts; // Narrative forecast
var raininfo=json.WhenWillItRain;
var sunriseset=json.SunRiseSet;


daily=JSON.stringify(dailyinfo[0]);
hourly=JSON.stringify(hourlyinfo[0]);
narrative=JSON.stringify(narrativeinfo[0]);

//alert(daily)
//alert(hourly);
//alert(narrative);
//alert(raininfo)
//alert(sunrise);

sunrise=JSON.stringify(sunriseset[0].rise);
sunset=JSON.stringify(sunriseset[0].set);
sunrise = sunrise.replace(/"/g, "");
sunset = sunset.replace(/"/g, "");


// convert sunrise from UNIX time
var timestamp1 = sunrise;
	UX2 = new Date(timestamp1 * 1000),
    hours = (UX2.getHours() < 10 ? '0' + UX2.getHours() : UX2.getHours()),
    minutes = (UX2.getMinutes() < 10 ? '0' + UX2.getMinutes() : UX2.getMinutes()),
    seconds = (UX2.getSeconds() < 10 ? '0' + UX2.getSeconds() : UX2.getSeconds()),
    sunrise = hours + ':' + minutes;

if(TwentyFourHourClock=="false"){
        hours = hours % 12;
    if(hours == 0){hours += 12;}
    sunrise = hours + ':' + minutes;
}


// convert sunset from UNIX time
var timestamp = sunset;
	UX1 = new Date(timestamp * 1000),
    hours = (UX1.getHours() < 10 ? '0' + UX1.getHours() : UX1.getHours()),
    minutes = (UX1.getMinutes() < 10 ? '0' + UX1.getMinutes() : UX1.getMinutes()),
    seconds = (UX1.getSeconds() < 10 ? '0' + UX1.getSeconds() : UX1.getSeconds()),
    sunset = hours + ':' + minutes;

if(TwentyFourHourClock=="false"){
        hours = hours % 12;
    if(hours == 0){hours += 12;}
    sunset = hours + ':' + minutes;
}

//alert(sunrise);
//alert(sunset);



if(daily.day==undefined){
	var tod=dailyinfo[0].night;
}
else{
	var tod=dailyinfo[0].day;
}


//begin forecast
daily1=JSON.stringify(dailyinfo[1]);
daily2=JSON.stringify(dailyinfo[2]);
daily3=JSON.stringify(dailyinfo[3]);
daily4=JSON.stringify(dailyinfo[4]);


if(daily1.day==undefined){var day1=dailyinfo[1].day;var night1=dailyinfo[1].night;}else{var day2=daily2[1].night;}

if(daily2.day==undefined){var day2=dailyinfo[2].day;var night2=dailyinfo[2].night;}else{var day2=daily2[2].night;}

if(daily3.day==undefined){var day3=dailyinfo[3].day;var night3=dailyinfo[3].night;}else{var day1=daily3[3].night;}

if(daily4.day==undefined){var day4=dailyinfo[4].day;var night4=dailyinfo[4].night;}else{var day4=daily4[4].night;}

var daysize="80"; //set forecast image size
var iconlocation="weather/icon/small/"; //what folder to pull from
var iconextention=".png" //image extentions

var day1=iconlocation+day1.icon+"_small"+iconextention;
var day2=iconlocation+day2.icon+"_small"+iconextention;
var day3=iconlocation+day3.icon+"_small"+iconextention;
var day4=iconlocation+day4.icon+"_small"+iconextention;

var night1=iconlocation+night1.icon+"_small"+iconextention;
var night2=iconlocation+night2.icon+"_small"+iconextention;
var night3=iconlocation+night3.icon+"_small"+iconextention;
var night4=iconlocation+night4.icon+"_small"+iconextention;


document.getElementById("Day1").innerHTML = '<img width='+daysize+' src='+day1+'>'
document.getElementById("Day2").innerHTML = '<img width='+daysize+' src='+day2+'>'
document.getElementById("Day3").innerHTML = '<img width='+daysize+' src='+day3+'>'
document.getElementById("Day4").innerHTML = '<img width='+daysize+' src='+day4+'>'

document.getElementById("Night1").innerHTML = '<img width='+daysize+' src='+night1+'>'
document.getElementById("Night2").innerHTML = '<img width='+daysize+' src='+night2+'>'
document.getElementById("Night3").innerHTML = '<img width='+daysize+' src='+night3+'>'
document.getElementById("Night4").innerHTML = '<img width='+daysize+' src='+night4+'>'

var hightemp1=dailyinfo[1].maxTemp;
var hightemp2=dailyinfo[2].maxTemp;
var hightemp3=dailyinfo[3].maxTemp;
var hightemp4=dailyinfo[4].maxTemp;

var lowtemp1=dailyinfo[1].minTemp;
var lowtemp2=dailyinfo[2].minTemp;
var lowtemp3=dailyinfo[3].minTemp;
var lowtemp4=dailyinfo[4].minTemp;

document.getElementById("Day1High").innerHTML = '<span>' + ("&#8673;"+hightemp1+degrees) + '</span>'
document.getElementById("Day1Low").innerHTML = '<span>' + ("&#8675;"+lowtemp1+degrees) + '</span>'
document.getElementById("Day2High").innerHTML = '<span>' + ("&#8673;"+hightemp2+degrees) + '</span>'
document.getElementById("Day2Low").innerHTML = '<span>' + ("&#8675;"+lowtemp2+degrees) + '</span>'
document.getElementById("Day3High").innerHTML = '<span>' + ("&#8673;"+hightemp3+degrees) + '</span>'
document.getElementById("Day3Low").innerHTML = '<span>' + ("&#8675;"+lowtemp3+degrees) + '</span>'
document.getElementById("Day4High").innerHTML = '<span>' + ("&#8673;"+hightemp4+degrees) + '</span>'
document.getElementById("Day4Low").innerHTML = '<span>' + ("&#8675;"+lowtemp4+degrees) + '</span>'



//////////////////////////////////////////////////////////////////////////////////
var iconToday=JSON.stringify(tod.icon);
var iconToday=imagelocation+iconToday+imageextention;
document.getElementById("IconToday").innerHTML = '<img width="320" src='+iconToday+'>'



////////////////////////////////////////////////////////////////////////////////////
var hiToday=JSON.stringify("Hi:"+dailyinfo[0].maxTemp+degrees); //Today hi
hiToday = hiToday.replace(/"/g, "");
if(hiToday=="Hi:"+undefined+degrees){hiToday="Hi:NA"}              //If afternoon show NA
document.getElementById("HighToday").innerHTML = '<span>' + ('' + hiToday) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var loToday=JSON.stringify("Lo:"+dailyinfo[0].minTemp+degrees); //Today lo
loToday = loToday.replace(/"/g, "");
document.getElementById("LowToday").innerHTML = '<span>' + ('' + loToday) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var descToday=JSON.stringify(tod.phrase); //Today weather description
descToday = descToday.replace(/"/g, "");
if(descToday==""){var descToday=JSON.stringify(dailyinfo[0].night.phrase)};
descToday = descToday.replace(/"/g, "");


document.getElementById("DescToday").innerHTML = '<span>' + ( textstringlater + descToday) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var tempNow=JSON.stringify(hourlyinfo[0].temp+degrees); //Current Temp
tempNow = tempNow.replace(/"/g, "");
document.getElementById("TempNow").innerHTML = '<span>' + ('' + tempNow) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var realFeel=JSON.stringify(hourlyinfo[0].feelsLike+degrees); //Current Temp
realFeel = realFeel.replace(/"/g, "");
document.getElementById("RealFeel").innerHTML = '<span>' + ('Feels Like:' + realFeel) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var Humidity=JSON.stringify("Humidity:"+hourlyinfo[0].humid); //Humidity
Humidity = Humidity.replace(/"/g, "");
document.getElementById("Humidity").innerHTML = '<span>' + ('' + Humidity) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var WindSpeed=JSON.stringify("Wind:"+hourlyinfo[0].wSpeed); //Wind Speed
WindSpeed = WindSpeed.replace(/"/g, "");
document.getElementById("WindSpeed").innerHTML = '<span>' + ('' + WindSpeed+":") + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var WindDirection=JSON.stringify(hourlyinfo[0].wDirText); //Wind Direction
WindDirection = WindDirection.replace(/"/g, "");
document.getElementById("WindDirection").innerHTML = '<span>' + ('' + WindDirection) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var UV=JSON.stringify("UV:"+hourlyinfo[0].uv); //UV
UV = UV.replace(/"/g, "");
document.getElementById("UV").innerHTML = '<span>' + ('' + UV) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var dew=JSON.stringify("dew:"+hourlyinfo[0].dew); //dew

dew = dew.replace(/"/g, "");
document.getElementById("dew").innerHTML = '<span>' + ('' + dew) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var City=JSON.stringify(json.Location.city); //City
City = City.replace(/"/g, "");
document.getElementById("City").innerHTML = '<span>' + ('' + City) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var HourlyDesc=JSON.stringify(hourlyinfo[0].wDesc);
HourlyDesc = HourlyDesc.replace(/"/g, "");
document.getElementById("HourlyDesc").innerHTML = '<span>' + (HourlyDesc) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var HourlyIcon=JSON.stringify(hourlyinfo[0].icon);
var HourlyIcon=imagelocation+HourlyIcon+imageextention;
document.getElementById("HourlyIcon").innerHTML = '<img width="320" src='+HourlyIcon+'>'

//////////////////////////////////////////////////////////////////////////////////
document.getElementById("RainInfo").innerHTML = '<span>' + (raininfo.standardPhrase) + '</span>'


//////////////////////////////////////////////////////////////////////////////////
var Sunrise=sunrise; //Sunrise
document.getElementById("Sunrise").innerHTML = '<span>' + ('Sunrise: ' + Sunrise) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var Sunset=sunset; //Sunset
document.getElementById("Sunset").innerHTML = '<span>' + ('Sunset: ' + Sunset) + '</span>'


};



function ShowContent() {
  Showdata();
}

(function($){
$.fn.weather = function(options){
			GetXmlFeed(true);}

})($);