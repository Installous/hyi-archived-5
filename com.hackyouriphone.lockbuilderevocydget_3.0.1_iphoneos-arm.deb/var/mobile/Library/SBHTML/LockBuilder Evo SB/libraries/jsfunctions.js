saveLocal=function(name,value){
  localStorage.setItem(name,value);
}
loadLocal=function(name){
  return localStorage.getItem(name);
}
getEL = function(element){
  return document.getElementById(element);
}
hazClass = function(element, cls) {
    return (' ' + element.className + ' ').indexOf(' ' + cls + ' ') > -1;
}

closemenu = function(){
	var menuLdivs = ['overlay','background','newitems','weatherelements','animationcontainer','iwidgetcontainer'];
	var menuDdivs = ['premenu','movemenu','lsmenu','iconmenu','moveiwidgetsmenu','widgetmenu','weathermenu'];
  getEL('selectwalls').style.left = "400px";
	for(md=0; md < menuLdivs.length; md++){
		if(getEL(menuLdivs[md])){
			if(getEL(menuLdivs[md]).style.left < "0px"){
				getEL(menuLdivs[md]).style.left = "0px";
			}
		}
	}
	for(mn=0; mn < menuDdivs.length; mn++){
		if(getEL(menuDdivs[mn])){
			if(getEL(menuDdivs[mn]).style.display == "block"){
				getEL(menuDdivs[mn]).style.display = "none";
			}
		}
	}
	getEL('menubackg').style.left = "350px";
	[].forEach.call( document.querySelectorAll('.icons'), function(elmt) {
		if(elmt.style.left == "-66px"){
			elmt.style.left = '0px';
		}
    });
}
openmenu = function(){
	var menuLdivs = ['overlay','background','newitems','weatherelements','animationcontainer','iwidgetcontainer'];
	var menuDdivs = ['premenu','movemenu'];
	for(md=0; md < menuLdivs.length; md++){
		if(getEL(menuLdivs[md])){
				getEL(menuLdivs[md]).style.left = "-66px";
		}
	}
	for(mn=0; mn < menuDdivs.length; mn++){
		if(getEL(menuDdivs[mn])){
				getEL(menuDdivs[mn]).style.display = "block";
		}
	}
	getEL('menubackg').style.left = "254px";
	[].forEach.call( document.querySelectorAll('.icons'), function(elmt) {
			elmt.style.left = '-66px';
    });
}


var sCityCodes,sUnit,gpstime,TwentyFourHourClock,statusbar,dimmer,curlanguage,cameragrab,ccgrab,ncgrab,overrideunlock,kph,plisttxt,SMStxt,MAILtxt,PHONEtxt,TWITTERtxt,TWEETBOTtxt,WHATSAPPtxt,slider;
    var settings = readDict('/var/mobile/Library/Preferences/com.JunesiPhone.LockBuilderEvo.plist');
  if (settings != null) {
    if(settings.sCityCodes!=null){sCityCodes = settings.sCityCodes}else{sCityCodes="72301";}
    if(settings.sUnit!=null){isCelsius = settings.sUnit}else{isCelsius=0;}
    if(settings.gpsint!=null){gpstime = settings.gpsint;}else{gpstime=15;}
    if(settings.TwentyFour!=null){TwentyFourHourClock = settings.TwentyFour}else{TwentyFourHourClock=false;}
    if(settings.statusbarswitch!=null){statusbar = settings.statusbarswitch;}else{statusbar=0;}
    if(settings.dimmer!=null){dimmer = settings.dimmer;}else{dimmer="6000";} 
    if(settings.languages!=null){var curlanguage = settings.languages;}else{var curlanguage="en";} 
    if(settings.cameragrab!=null){cameragrab = settings.cameragrab;}else{cameragrab=0;} 
    if(settings.ccgrab!=null){ccgrab = settings.ccgrab;}else{ccgrab=0;} 
    if(settings.ncgrab!=null){ncgrab = settings.ncgrab;}else{ncgrab=0;} 
    if(settings.overrideunlock!=null){overrideunlock=settings.overrideunlock;}else{overrideunlock="false";} 
    if(settings.kph!=null){kph=settings.kph;}else{kph=0;} 
    if(settings.plisttxt!=null){plisttxt=settings.plisttxt;}else{plisttxt=0;} 
    if(settings.SMS!=null){SMStxt=settings.SMS;}else{SMStxt="SMS: ";} 
    if(settings.MAIL!=null){MAILtxt=settings.MAIL;}else{MAILtxt="Mail: ";} 
    if(settings.PHONE!=null){PHONEtxt=settings.PHONE;}else{PHONEtxt="Phone: ";} 
    if(settings.TWITTER!=null){TWITTERtxt=settings.TWITTER;}else{TWITTERtxt="Twitter: ";} 
    if(settings.TWEETBOT!=null){TWEETBOTtxt=settings.TWEETBOT;}else{TWEETBOTtxt="Tweetbot: ";} 
    if(settings.WHATSAPP!=null){WHATSAPPtxt=settings.WHATSAPP;}else{WHATSAPPtxt="Whatsapp: ";} 
    if(settings.slider!=null){slider = settings.slider;}else{slider="Unlock";};
    if (settings.slideto != null){var slideto = settings.slideto;} else {var slideto = 0;}
 }
  else{
    alert("LBEvo is using default settings, to set your settings click the logo in the settings.app. To use gps turn on location services");
    var sCityCodes="38671";
    var TwentyFourHourClock="false";
    var sUnit="s";
  }


if (overrideunlock == 1) { var sliderdiv = document.getElementById('unlock'); sliderdiv.innerHTML = slider;
}else{}

if (isCelsius == 1) { var sUnit = "m";
} else { var sUnit = "s";}

if (kph == 1) { var kph = "yes";
} else { var kph = "no"; }

if (TwentyFourHourClock == 1) { TwentyFourHourClock = "false";
} else { TwentyFourHourClock = "true"; }

if (statusbar == 1) { hidestatusbar();
  window.setTimeout("hidestatusbar();", 2400);
} else {}

window.setTimeout("dimlockscreen();", dimmer);

canceltimer();
if (cameragrab == 1) { hidecameragrabber(); window.setTimeout("hidecameragrabber();", 2400); 
}else{}
if (ccgrab == 1) { hideccgrabber(); 
}else{}
if (ncgrab == 1) { hidencgrabber(); 
}else{}
if (slideto == 1) { hideslidetounlock();
}else{}


//Music
var firststart="0";
function updatesong(){
  window.songName=getSongDetails('nowPlayingTitle');
  window.songArtist=getSongDetails('nowPlayingArtist');
  window.songAlbum=getSongDetails('nowPlayingAlbum');
  var image=getSongDetails('artwork');
  var imageData = getUIRep(image);
  window.albumCover=getBase64(imageData);
//var playing=[[SBMediaController sharedInstance] isPlaying];
}

function playmusic(){
  firststart++
  if(firststart=="1"){ 
    hideMediaControls();
    playMusic();
    checkstatusbar(); // see if user has statusbar set to hide.
    setTimeout(function(){ updatesong() }, 1000); //let the song start playing first
  }
  else{
    playMusic();
    checkstatusbar();
    setTimeout(function(){ checkmediacontrols() }, 500);
    setTimeout(function(){ updatesong() }, 1000);
      }
}
function nexttrack(){
  changeNextTrack();
  checkstatusbar();
  checkmediacontrols();
  setTimeout(function(){ updatesong() }, 1000);
}
function previoustrack(){
  checkstatusbar();
  checkmediacontrols();
  changePrevTrack();
  setTimeout(function(){ updatesong() }, 1000);
}

window.songName="No Details"; //set global for iWidget
window.songArtist="No Details";
window.songAlbum="No Details";
window.albumCover="No Images";

window.stillPlaying=musicPlaying();

if(window.stillPlaying){
  updatesong();
  checkmediacontrols();
}


function checkstatusbar(){
  if (statusbar == 1) {
      setTimeout(function () {
    hidestatusbar();
      }, 2400);
  } else {}
}

function checkmediacontrols(){
    if(isshowingMediaCtrls()){
      hideMediaControls();
    }
}

function getthemebg(theme){
  var themeplist = readDict('/var/mobile/Library/LBEvoThemes/'+theme);
  if(themeplist!=null){
  var img=themeplist.Background;
  return img;
  }
}

function loading(name){
  try {
    var themeplist = readDict("/var/mobile/Library/LBEvoThemes/"+name);
    loadpickedtheme(themeplist,name);
  } 
  catch(err){
    alert("Themes2"+err);
  }
}
function iconalert(){return window.NowIcon;}





