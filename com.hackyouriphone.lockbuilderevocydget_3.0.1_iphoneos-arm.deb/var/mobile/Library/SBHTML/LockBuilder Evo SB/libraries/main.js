/////////////////////////////////


var bgDIV = getEL('background');
var overlayDIV = getEL('overlay');
var savedhideobj=loadLocal('hideOBJ'); //objects that are shown/hidden
var menuloaded=0;

if (loadLocal('overlaySB') !== null) {
  if(loadLocal('overlaySB')!=='null'){
    getEL('overlay').src = "/var/mobile/Library/LBEvoOverlays/" + loadLocal('overlaySB');
    getEL('overlay').style.display="block";
  }
}

var getitems = loadLocal('userbgSB');
if (getitems !== null) {
    if (getitems.length >= 100) {
        getEL('background').style.backgroundImage = "url(" + getitems + ")";
    }
}

checkKey = function(key){
    if($('#' + key).length){return true;} 
}



function openoverlay(overlay) {
    var docoverlay;
    saveLocal('overlay', overlay);
    overlayDIV.style.display = "block";
    overlayDIV.src = "/var/mobile/Library/LBEvoOverlays/" + overlay;
    $('.overlays').remove();
}




function loadanimations() {
    closemenu();
    getEL('animations').style.display = "block";
    localStorage.removeItem('hiddenbg');
    bgDIV.style.visibility = "visible";
    alert("Animations with password set may cause safemode. Recommended to use without passcode.");
    var allfiles = readplist('/var/mobile/Library/LBEvoAnimations/');
    for (var i = 0; i < allfiles.length; i++) {
        ids = allfiles[i];
        classname = "animations";
        d1 = document.createElement('div');
        $(d1).addClass(classname).html("" + ids).appendTo($('#animations')).click(function() {
            thisname = this.innerHTML;
            openanimations(thisname);
        });
    }
    d2 = document.createElement('div');
    $(d2).addClass(classname).html("Remove current animation").appendTo($('#animations')).click(function() {
        thisname = this.innerHTML;
        stopanimations();
    });
}

//groovylock
function loadGL() {
    var Gallfiles=readplist('/var/mobile/Library/GroovyLock/');
    for (var w = 0; w < Gallfiles.length; w++) {
      Gids = Gallfiles[w];
      Gclassname = "lockscreen";
      Gd = document.createElement('div');
      $(Gd).addClass(Gclassname).html("" + Gids).appendTo($('#lockscreens')).click(function () {thisname = this.innerHTML;openlock(thisname);});
    }
}




if (loadLocal('overlaySB') !== null) {
    if(loadLocal('overlaySB'!=='null')){
    getEL('overlay').src = "/var/mobile/Library/LBEvoOverlays/" + loadLocal('overlaySB');
    getEL('overlay').style.display="block";
}
}





if(loadLocal('hiddenbg')){bgDIV.style.visibility="hidden";}else{}



function loadiwidgets(widget, width, height) {
    var widgetname, objiwidget, savedwidget, name, preparedwidget, container, swipecontain, link, widgetframe, widgetdiv, moverdiv, isLocked;
    widgetname = widget.replace(/\s+/g, '');
    widgetname = widgetname.replace(/[^\w\s]/g, '');

    objiwidget = {};
    savedwidget = loadLocal('objiwidgetsSB');
    if (savedwidget !== null) {
        objiwidget = JSON.parse(savedwidget);
    }
    name = widgetname;
    objiwidget[name] = widget + ',' + width + ',' + height;
    preparedwidget = JSON.stringify(objiwidget);
    saveLocal('objiwidgetsSB', preparedwidget);


    container = getEL('iwidgetcontainer');
    $('<div id="' + widgetname + '" style="position:absolute;" class="noswipe" class="iwidgetclass"></div>').appendTo(container);
    swipecontain = getEL(widgetname);
    $('<div id="iwidgetswipe' + widgetname + '" style="position:absolute; "></div>').appendTo(swipecontain);

    link = "file:///var/mobile/Library/iWidgets/" + widget + "/Widget.html";
    widgetframe = document.createElement('iframe');
    widgetframe.frameBorder = 0;
    widgetframe.style.left = "0px";
    widgetframe.style.position = "absolute";
    widgetframe.style.width = width + "px";
    widgetframe.style.height = height + "px";
    widgetframe.style.backgroundColor = "transparent";
    widgetframe.id = widgetname + "iframes";
    widgetframe.setAttribute("src", link);
    widgetframe.setAttribute("class", "iwidgetclass");
    getEL("iwidgetswipe" + widgetname).appendChild(widgetframe);

    $('#iwidgetswipe' + widgetname).css({
        'height': '' + height + 'px',
        'width': '' + width + 'px',
        'background-color': 'rgba(255,255,255,0.0)', //woo! set background color to size widgetframe
        'overflow': 'hidden'
    });

    widgetdiv = getEL(widgetname);
    moverdiv = document.createElement("div");
    moverdiv.style.zIndex = "10";
    moverdiv.style.width = width + "px";
    moverdiv.style.height = height + "px";
    moverdiv.style.backgroundColor = "transparent";
    moverdiv.id = widgetname + "mover";
    widgetdiv.appendChild(moverdiv);

    $("#" + widgetname + "mover").css({
        'z-index': '100',
        'height': '50px',
        'top': '10px',
        'position': 'absolute',
        'background-color': 'transparent'
    });

    $("#" + widgetname + "mover").css("width", width);

    $("#" + widgetname).css({
        'z-index': '4',
        'position': 'absolute',
        'top': '100px',
        'padding-bottom': '40px',
        'left': '0px',
        'background-color': 'transparent'
    });
    $("#" + widgetname).addClass(' widget');

    isLocked = loadLocal('locked');
    
}


function getwidgetvalues(wkey, valueiw) {
    var wname, wwidth, wheight;
    valueiw = valueiw.split(',');
    wname = valueiw[0];
    wwidth = valueiw[1];
    wheight = valueiw[2];
    loadiwidgets(wname, wwidth, wheight);
}

function deletewidget() {
    var wcurel, savedwwidget, newsaves, objiwidget;
    wcurel = loadLocal('curel');
    $('#' + wcurel).remove();
    savedwwidget = loadLocal('objiwidgetsSB');
    if (savedwwidget !== null) {
        objiwidget = {};
        objiwidget = JSON.parse(savedwwidget);
    }
    delete objiwidget[wcurel];
    newsaves = JSON.stringify(objiwidget);
    saveLocal('objiwidgetsSB', newsaves);
    closehelper();
}

//////////////////////////

//Drag Elements
function dragobj(name, myTransform) {
    var dragmatrix, dragvalues, draga, dragb, dragangle, dragOBJ, myDragObject, dragsavedobj;
    dragmatrix = $('#' + name).css('-webkit-transform');
    if (dragmatrix !== "none") {
        dragvalues = dragmatrix.split('(')[1].split(')')[0].split(',');
        draga = dragvalues[0];
        dragb = dragvalues[1];
        dragangle = Math.round(Math.atan2(dragb, draga) * (180 / Math.PI));
        saveLocal(name + 'defaultrotation', dragangle);
    }
    dragOBJ = {};
    dragsavedobj = loadLocal('dragOBJ');
    if (dragsavedobj !== null) {
        dragOBJ = JSON.parse(dragsavedobj);
    }
    dragOBJ[name] = [myTransform];
    myDragObject = JSON.stringify(dragOBJ);
    saveLocal('dragOBJ', myDragObject);
}





//load lockscreen on top of wallpaper

function openlock(lockscreen){
  //  localStorage.removeItem("userbgSB");
  $('#movelocksmenu').css('display','none');
    saveLocal('lockscreenchosen', lockscreen);
    setTimeout(function(){ window.location = window.location.href; }, 300);
}

var ls = loadLocal("lockscreenchosen");
if (ls != "null") {
  if(ls!=null){
    var container=getEL('iwidgetcontainer');
    $("<div></div>").attr("id", "lockscreen").appendTo(container);
    $("<div></div>").attr("id", "locksa").appendTo(container);
    $("#lockscreen").css("position", "absolute");
    $("#lockscreen").css("width", "320px");
    $("#lockscreen").css("height", "160px");
    $("#lockscreen").css("left", "0px");
    $("#lockscreen").css("top", "410px");
    $("#lockscreen").css("background-color", "transparent");
    $("#lockscreen").css("z-index", "4");
    $("#locksa").css("z-index", "3");
    $("#locksa").css("position", "absolute");
    $("#locksa").css("background-color", "transparent");
    $("#locksa").css("width", "320px");
    $("#locksa").css("top", "0px");
    $("#locksa").css("left", "0px");
    loadlock(ls)
}
}

function loadlock(ls) {
    var iframea, iframea2, gld;
    iframea = document.createElement("iframe");
    iframea.id = "lockscreen";
    iframea2 = document.createElement("lockscreen");
    iframea2.frameBorder = "0";
    iframea.src = "file:///var/mobile/Library/GroovyLock/" + ls + "/LockBackground.html";
    iframea.style.backgroundColor = "transparent";
    iframea.frameBorder = "0";
    iframea.allowTransparency = "true";
    gld = getEL("locksa");
    gld.frameBorder = "0";
    gld.appendChild(iframea);
    iframea = null;
    gld = null;
}



function openanimations(name){
    saveLocal('animations', name);
    setTimeout(function(){ window.location = window.location.href; }, 300);
}

var animat = loadLocal("animationsSB");
if (animat != "null") {
  if(animat!=null){
    var container=getEL('animationcontainer');
    $("<div></div>").attr("id", "anisc").appendTo(container);
    $("#anisc").css("z-index", "1");
    $("#anisc").css("position", "absolute");
    $("#anisc").css("background-color", "transparent");
    $("#anisc").css("width", "320px");
    $("#anisc").css("top", "0px");
    $("#anisc").css("left", "0px");
     $("#anisc").css("pointer-events", "none");
    loadanimation(animat);
}
}


function loadanimation(ani) {
    var iframea, iframea2, gld;
    iframea = document.createElement("iframe");
    iframea.id = "lockscreen";
    iframea.src = "file:///var/mobile/Library/LBEvoAnimations/" + ani + "/index.html";
    iframea.style.backgroundColor = "transparent";
    iframea.frameBorder = "0";
    iframea.allowTransparency = "true";
    gld = getEL("anisc");
    gld.frameBorder = "0";
    gld.appendChild(iframea);
    iframea = null;
    gld = null;
}



function startani() {
    var widgetan;
    $('#widgetmenu').css('display', 'none');
    $('#background,#weather,.icons,#locksa').css('left', '0px');
    widgetan = loadLocal('widget');
    if (widgetan !== null) {
        localStorage.removeItem('widget');
        setTimeout(function () {
            window.location.reload()
        }, 10);
    } else {
        widgetan = "animated";
        saveLocal('widget', widgetan);
        setTimeout(function () {
            window.location.reload()
        }, 10);
    }
}
//////////////////


function imageExists(url, callback) { //function to check if images exists works 90% which is amazing.
  var img = new Image();
  img.onload = function() { callback(true); };
  img.onerror = function() { callback(false); };
  img.src = url;
}

    


//caps Elements
function capsobj(name, myTransform) {
    capsOBJ = {};
    capssavedobj = loadLocal('capsOBJ');
    if (capssavedobj !== null) {
      if(capssavedobj=="undefined"){}
      else{capsOBJ = JSON.parse(capssavedobj);}
    }
    capsOBJ[name] = [myTransform];
    mycapsObject = JSON.stringify(capsOBJ);
    saveLocal('capsOBJ', mycapsObject);
}



var mainbg=loadLocal("userbgSB");
if(mainbg==null){
getBase64FromImageUrl("images/wallpaperinst.png");

}
function getBase64FromImageUrl(URL) {
    var img = new Image();
    img.src = URL;
    img.onload = function () {
    var canvas = document.createElement("canvas");
    canvas.width =this.width;
    canvas.height =this.height;
    var ctx = canvas.getContext("2d");
    ctx.drawImage(this, 0, 0);
    var dataURL = canvas.toDataURL("image/png");
    canvas=null;
    saveLocal('userbgSB',dataURL);
    if(URL=="images/wallpaperinst.png"){
      wall=loadLocal('userbgSB');
      cw=getEL("background");cw.style.backgroundImage="url("+wall+")";
  }

    }
}

function weatherwalls(){
 var issaved=loadLocal('weatherwalls');
  if(issaved =='yes'){localStorage.removeItem('weatherwalls');}
  else{saveLocal('weatherwalls','yes');}
  location.reload();
}



var weatherwallpapers=loadLocal('weatherwalls');
if(weatherwallpapers!=null){
  weatherwall="yes";
  getBase64FromImageUrl("images/wallpaper.jpg");
}





function hidebg(){getEL('background').style.visibility="hidden";}


loadObject = function(savobj,type){
  if(savobj!=null){
    if(savobj!='null'){
    if(savobj.length>=2){
        if(savobj!='undefined'){
    var parsed = JSON.parse(savobj);
    Object.keys(parsed).forEach(function (key) {
        var value = parsed[key];
            if(type == 'hide'){$('#'+key).css('display',value);}
                else if(type == 'opacity'){ $('#'+key).css('opacity',value);  }
                    else if(type == 'icon'){
                            $(".icons").append('<div class="iconcan" name="'+value+'" id=' + key + '></div>');
                               
                    }
                    else if(type == 'iconimg'){
                        if(checkKey(key)){
                            var bundle = getEL(key).getAttribute('name');
                            linkFuncts = "closethisapp('" + key + "')";

                            getEL(key).innerHTML = getEL(key).innerHTML+'<center><div class="iconcan" id="b' + key + '"><img ontouchend="openapp(' + bundle + ') " id="icon' + key + '" class="iconimages" src="' + value + '"></div></center><span id="closer' + key + '" class="closer" >X</span>';
                            closer = getEL("closer" + key);
                            closer.setAttribute('onTouchEnd', linkFuncts);
                         }   
                    }
                    else if(type == 'newiconimg'){
                        if (checkKey(key)) {
                            $('#b' + key + ' .iconimages').attr('src', value);
                        } else {}
                    }
                    else if(type == 'scale'){
                        if(checkKey(key)){
                            if (key === "line" || key === "thickline" || key === "mediumline") {
                                getEL(key).style.height = value+"px";
                            }
                             if (key === "icon") {
                                getEL(key+'img').style.width = value+'px';
                            }
                            if (key === "day1icon" || key === "day2icon" || key === "day3icon" || key === "day4icon") {
                                getEL(key+'i').style.width = value+'px';
                            }
                                
                             if (hazClass(getEL(key),'iconcan')) {
                                getEL('icon'+key).style.width = value+'px';
                            }
                             if (hazClass(getEL(key),'widget')) {
                                if (value >= 2) {
                                    alert("widgets can only be scaled from 0.0 to 1.9")
                                } else {
                                    getEL(key).style.webkitTransform = "scale(" + value + ")";
                                }
                            }
                            getEL(key).style.fontSize = value + 'px';
                        }
                    }
                    else if(type == 'color'){
                        if(checkKey(key)){
                            if (key === "line" || key === "thickline" || key === "mediumline") {
                                getEL(key).style.backgroundColor = value;
                            }
                             var creatitem = $("#" + key).hasClass("createditem");
                            if (creatitem === true) {
                                getEL(key).style.backgroundColor = value;
                            } else {
                                getEL(key).style.color = value;
                            }
                        }
                    }
                    else if(type == 'shadow'){
                        if(checkKey(key)){
                            if (key === "line" || key === "thickline" || key === "mediumline") {
                                getEL(key).style.webkitBoxShadow = value;
                            } else {
                                getEL(key).style.textShadow = value;
                            }
                        }
                    }
                    else if(type == 'align'){
                        getEL(key).style.textAlign = value;
                    }
                    else if(type =='iwidgets'){
                        getwidgetvalues(key, value);
                    }
                    else if(type == 'dragposition'){
                         if(checkKey(key)){
                            if(key == 'weathericonsmenu'){}
                                else{
                                getEL(key).style.webkitTransform = value;
                                }
                        }
                    }
                    else if(type == 'fonts'){
                        //alert('font'+key+value);
                        $('#'+key).css('font-family',value);
                        //getEL(key).style.fontFamily = value;
                    }
                    else if(type == 'caps'){
                        if(checkKey(key)){
                            $('#'+key).css('text-transform',value);
                            //getEL(key).style.textTransform = value;
                        }
                    }
                

                });
            }
        }
    }
}
}

setTimeout(function(){
//loadObject(loadLocal('iconOBJSB'),'icon');
loadObject(loadLocal('hideOBJSB'),'hide');
loadObject(loadLocal('objiwidgetsSB'),'iwidgets');
loadObject(loadLocal('fontOBJSB'),'fonts');
//loadObject(loadLocal('iconimgOBJSB'),'iconimg');
//loadObject(loadLocal('newiconimgOBJSB'),'newiconimg');
loadObject(loadLocal('colorOBJSB'),'color');
loadObject(loadLocal('shadowOBJSB'),'shadow');
loadObject(loadLocal('alignOBSB'),'align');
loadObject(loadLocal('capsOBJSB'),'caps');
loadObject(loadLocal('opacityOBSB'),'opacity');
loadObject(loadLocal('scaleOBJSB'),'scale');
loadObject(loadLocal('dragOBJSB'),'dragposition');

},0);


function formatSizeUnits(bytes){
    if  (bytes>=1000000000) {bytes=(bytes/1000000000).toFixed(2)+' GB';}
    else if (bytes>=1000000)    {bytes=(bytes/1000000).toFixed(2)+' MB';}
    else if (bytes>=1000)       {bytes=(bytes/1000).toFixed(2)+' KB';}
    else if (bytes>1)       {bytes=bytes+' bytes';}
    else if (bytes==1)      {bytes=bytes+' byte';}
    else                {bytes='0 byte';}
    return bytes;
}


