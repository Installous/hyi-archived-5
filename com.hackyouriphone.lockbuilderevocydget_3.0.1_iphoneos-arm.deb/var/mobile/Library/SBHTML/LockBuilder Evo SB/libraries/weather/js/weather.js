// http://JunesiPhone.com

var StickForecast="yes"; // if you want forecast to show without shake set to yes.
var imgcolor="white";
var language = window.navigator.language;
//localize languages

var locale=localStorage.getItem('apiLocale')
var sUnit=localStorage.getItem('apiCelsius');
var TwentyFourHourClock = localStorage.getItem('api24hr');
var curlanguage = localStorage.getItem('currentlang');

if(locale==null){
  var locale="38671";
  var sUnit="s";
  var TwentyFourHourClock="true";
}

var kph="no";
var refreshrate=600000; //900000 15 minutes

GetXmlFeed(locale);
setInterval(function(){GetXmlFeed(locale);},refreshrate);
// get weather //
function GetXmlFeed(code) {
  console.log("getxml");
   var lang = (typeof language == "string")?language.replace(/-/g, "_"):language;

   //var lang="fr-fr"; //Remove the first two // infront of var to use french replace with any language below
   //french is fr-fr
   //Spanish is es-es
   //German is
notavalue=code.length;

if(notavalue==undefined){
  code=sCityCodes;
}
reload_js(mainsc);

var code=localStorage.getItem('apiLocale');

var sUnit=localStorage.getItem('apiCelsius');
var TwentyFourHourClock = localStorage.getItem('api24hr');

if(code==null){
 
  var code="72301";
  var sUnit="s";
  var TwentyFourHourClock="true";

}

   var sc = document.createElement("script");
   var mainsc='http://wxdata.weather.com/wxdata/mobile/mobagg/' + code + '.js?key=2227ef4c-dfa4-11e0-80d5-0022198344f4&units=' + sUnit + '&locale=' + lang + '&cb=XmlFeedCB';
  sc.src=mainsc;
   document.body.appendChild(sc);


function reload_js(src) {
        $('script[src="' + src + '"]').remove();
        $('<script>').attr('src', src).appendTo('head');
    }
}


var textstringlater="Later Today:";

function XmlFeedCB(going){
  json = going[0];    //json is XML
  ShowContent();

}


function Showdata(warning2) { //passing warning from touch.js


var imageextention=".png"
var degrees="&deg;"

var dailyinfo=json.DailyForecasts; // daily forecast
var hourlyinfo=json.HourlyForecasts; // hourly forecast
var narrativeinfo=json.NarrativeForecasts; // Narrative forecast
var raininfo=json.WhenWillItRain;
var sunriseset=json.SunRiseSet;
var hirad=json.HiradObservation;

sunrise=JSON.stringify(sunriseset[0].rise);
sunset=JSON.stringify(sunriseset[0].set);
sunrise = sunrise.replace(/"/g, "");
sunset = sunset.replace(/"/g, "");

// convert sunrise from UNIX time
var timestamp1 = sunrise;
  UX2 = new Date(timestamp1 * 1000),
    hours = (UX2.getHours() < 10 ? '0' + UX2.getHours() : UX2.getHours()),
    minutes = (UX2.getMinutes() < 10 ? '0' + UX2.getMinutes() : UX2.getMinutes()),
    seconds = (UX2.getSeconds() < 10 ? '0' + UX2.getSeconds() : UX2.getSeconds()),
    sunrise = hours + ':' + minutes;

if(TwentyFourHourClock=="true"){
  hours = hours % 12;
    if(hours == 0){hours += 12;}
    sunrise = hours + ':' + minutes;
}


// convert sunset from UNIX time
var timestamp = sunset;
  UX1 = new Date(timestamp * 1000),
    hours = (UX1.getHours() < 10 ? '0' + UX1.getHours() : UX1.getHours()),
    minutes = (UX1.getMinutes() < 10 ? '0' + UX1.getMinutes() : UX1.getMinutes()),
    seconds = (UX1.getSeconds() < 10 ? '0' + UX1.getSeconds() : UX1.getSeconds()),
    sunset = hours + ':' + minutes;

if(TwentyFourHourClock=="true"){
  hours = hours % 12;
    if(hours == 0){hours += 12;}
    sunset = hours + ':' + minutes;
}



daily=JSON.stringify(dailyinfo[0]);
hourly=JSON.stringify(hourlyinfo[0]);
narrative=JSON.stringify(narrativeinfo[0].dayPart);


if(daily.day==undefined){
  var tod=dailyinfo[0].night;
}
else{
  var tod=dailyinfo[0].day;
}


//begin forecast
daily1=JSON.stringify(dailyinfo[1]);
daily2=JSON.stringify(dailyinfo[2]);
daily3=JSON.stringify(dailyinfo[3]);
daily4=JSON.stringify(dailyinfo[4]);



if(daily1.day==undefined){var day1=dailyinfo[1].day;var night1=dailyinfo[1].night;}else{var day2=daily2[1].night;}

if(daily2.day==undefined){var day2=dailyinfo[2].day;var night2=dailyinfo[2].night;}else{var day2=daily2[2].night;}

if(daily3.day==undefined){var day3=dailyinfo[3].day;var night3=dailyinfo[3].night;}else{var day1=daily3[3].night;}

if(daily4.day==undefined){var day4=dailyinfo[4].day;var night4=dailyinfo[4].night;}else{var day4=daily4[4].night;}

var daysize="40"; //set forecast image size
 //what folder to pull from

////////////////////////////////////////////////////////////////////////////////////
var hiToday=JSON.stringify(+dailyinfo[0].maxTemp+degrees); //Today hi
hiToday = hiToday.replace(/"/g, "");
if(hiToday=="NaN"+degrees){hiToday=json.StandardObservation.temp+degrees;}      //If afternoon show NA
document.getElementById("hi").innerHTML = '<span>' + (hiToday) + '</span>'


//////////////////////////////////////////////////////////////////////////////////
var loToday=JSON.stringify(""+dailyinfo[0].minTemp+degrees); //Today lo
loToday = loToday.replace(/"/g, "");
document.getElementById("low").innerHTML = '<span>' + (loToday) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var descToday=JSON.stringify(tod.phrase); //Today weather description
descToday = descToday.replace(/"/g, "");
if(descToday==""){var descToday=JSON.stringify(dailyinfo[0].night.phrase)};
descToday = descToday.replace(/"/g, "");


document.getElementById("later").innerHTML = '<span>' + ( textstringlater + descToday) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var tempNow=JSON.stringify(hourlyinfo[0].temp+degrees); //Current Temp
tempNow = tempNow.replace(/"/g, "");
//document.getElementById("TempNow").innerHTML = '<span>' + ('' + tempNow) + '</span>'

// New
document.getElementById("temp").innerHTML = '<span>' + ('' + json.StandardObservation.temp+degrees) + '</span>'

if(sUnit=="s"){
  tUnits="F";
}
else{tUnits="C";}
document.getElementById("tempFC").innerHTML = '<span>' + ('' + json.StandardObservation.temp+degrees+tUnits) + '</span>'

//document.getElementById("TempNow").innerHTML = '<span>' + ('' + hirad.feelsLike) + '</span>'


try{
var realFeel=JSON.stringify(hourlyinfo[0].feelsLike+degrees); //Current Temp
}
catch(err){
  var realFeel=hirad.feelsLike;
}
realFeel = realFeel.replace(/"/g, "");
document.getElementById("feeltemp").innerHTML = '<span>' + ('Feels Like:' + realFeel) + '</span>';


//////////////////////////////////////////////////////////////////////////////////
var Humidity=JSON.stringify("Humidity:"+hourlyinfo[0].humid); //Humidity
Humidity = Humidity.replace(/"/g, "");
document.getElementById("humidity").innerHTML = '<span>' + ('' + Humidity) + '</span>'


//////////////////////////////////////////////////////////////////////////////////
var WindSpeed=JSON.stringify(""+hourlyinfo[0].wSpeed); //Wind Speed
WindSpeed = WindSpeed.replace(/"/g, "");
document.getElementById("windsp").innerHTML = '<span>' + (''+WindSpeed+" Mph") + '</span>'



if(kph=="yes"){
conversion = 1.609344
kph = WindSpeed * conversion; 
kph = Math.round(kph * 100) / 100;
kph = Math.round(kph)
document.getElementById("windsp").innerHTML = '<span>' + ('' + kph+" Kph") + '</span>'

}




//////////////////////////////////////////////////////////////////////////////////
var WindDirection=JSON.stringify(hourlyinfo[0].wDirText); //Wind Direction
WindDirection = WindDirection.replace(/"/g, "");

//arrow=document.getElementById('windcompass');

 //setTimeout(function () {animatecompass();}, 1500);



function animatecompass(){
if(WindDirection=="ENE"){arrow.classList.remove('on');arrow.className = arrow.className + " ene"}
if(WindDirection=="ESE"){arrow.classList.remove('on');arrow.className = arrow.className + " ese"}
if(WindDirection=="NE"){arrow.classList.remove('on');arrow.className = arrow.className + " ne"}
if(WindDirection=="NNE"){arrow.classList.remove('on');arrow.className = arrow.className + " nne"}
if(WindDirection=="NNW"){arrow.classList.remove('on');arrow.className = arrow.className + " nnw"}
if(WindDirection=="NW"){arrow.classList.remove('on');arrow.className = arrow.className + " nw"}
if(WindDirection=="SE"){arrow.classList.remove('on');arrow.className = arrow.className + " se"}
if(WindDirection=="SSE"){arrow.classList.remove('on');arrow.className = arrow.className + " sse"}
if(WindDirection=="SSW"){arrow.classList.remove('on');arrow.className = arrow.className + " ssw"}
if(WindDirection=="SW"){arrow.classList.remove('on');arrow.className = arrow.className + " sw"}
if(WindDirection=="WNW"){arrow.classList.remove('on');arrow.className = arrow.className + " wnw"}
if(WindDirection=="WSW"){arrow.classList.remove('on');arrow.className = arrow.className + " wsw"}
}

document.getElementById("windir").innerHTML = '<span>' + ('' + WindDirection) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var UV=JSON.stringify("UV:"+hourlyinfo[0].uv); //UV
UV = UV.replace(/"/g, "");
document.getElementById("uv").innerHTML = '<span>' + ('' + UV) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var dew=JSON.stringify(""+hourlyinfo[0].dew+"&#176"); //dew

dew = dew.replace(/"/g, "");
document.getElementById("dew").innerHTML = '<span>' + ('Dew: ' + dew) + '</span>'

//////////////////////////////////////////////////////////////////////////////////
var City=JSON.stringify(json.Location.city); //City
City = City.replace(/"/g, "");
document.getElementById("city").innerHTML = '<span>' + ('' + City) + '</span>'


var State=JSON.stringify(json.Location.state); 
State = State.replace(/"/g, "");
document.getElementById("state").innerHTML = '<span>' + ('' + State) + '</span>'

var Statename=JSON.stringify(json.Location.stateName); 
Statename = Statename.replace(/"/g, "");
document.getElementById("statenm").innerHTML = '<span>' + ('' + Statename) + '</span>'

var Country=JSON.stringify(json.Location.country); 
Country = Country.replace(/"/g, "");
document.getElementById("country").innerHTML = '<span>' + ('' + Country) + '</span>'

var Elevation=JSON.stringify(json.Location.elv); 
Elevation = Elevation.replace(/"/g, "");
Elevation = "Elevation: "+Elevation
document.getElementById("elevation").innerHTML = '<span>' + ('' + Elevation) + '</span>'

var Lat=JSON.stringify(json.Location.lat);


Lat = Lat.replace(/"/g, "");


//Lat =Lat.slice(0, -4); 
Lat = Number(Lat);
Lat = +Lat.toFixed(2);
document.getElementById("lat").innerHTML = '<span>' + ('Lat: ' + Lat) + '</span>'

var Long=JSON.stringify(json.Location.lng); 
Long = Long.replace(/"/g, "");

//Long =Long.slice(0, -4); 
Long = Number(Long);
Long = +Long.toFixed(2);
document.getElementById("long").innerHTML = '<span>' + ('Long: ' + Long) + '</span>'



try{
  document.getElementById("condition").innerHTML = '<span>' + (json.HiradObservation.text) + '</span>';
}
catch(err){
  document.getElementById("condition").innerHTML = '<span>' + (json.StandardObservation.text) + '</span>';
}

try{
  document.getElementById("rainfall").innerHTML = '<span>' + ('Precip: '+json.HiradObservation.precipHourly+'\"') + '</span>'
  document.getElementById("tdesc").innerHTML = '<span>' + (json.HiradObservation.blunt_phrase) + '</span>'
  document.getElementById("visible").innerHTML = '<span>' + ('Visibility: '+json.HiradObservation.visibility) + '</span>'

}
catch(err){
  document.getElementById("rainfall").innerHTML = '<span>' + ('Not available') + '</span>'
  document.getElementById("tdesc").innerHTML = '<span>' + (json.StandardObservation.blunt_phrase) + '</span>'
  document.getElementById("visible").innerHTML = '<span>'+ ('Not available') +'</span>'
}




try {
var warning=json.WeatherAlerts[0].headline;
} catch(err){
  warning="No Warnings";
}

  document.getElementById("warning").innerHTML = '<span>' + ('Warnings: '+warning) + '</span>'


if(warning2!=null){ //activate with touch. Need to send parameter to activate
  try { //use try because we don't know if it exists.
var warning=json.WeatherAlerts[0].text;
document.getElementById("warning").innerHTML = '<span>' + ('Warnings: '+warning) + '</span>'

} catch(err){
  warning="No Warnings";
  document.getElementById("warning").innerHTML = '<span>' + ('Warnings: '+warning) + '</span>'

}

}

//////////////////////////////////////////////////////////////////////////////////
document.getElementById("raininfo").innerHTML = '<span>' + (raininfo.standardPhrase) + '</span>'


var exday=JSON.stringify(narrativeinfo[0].dayPart);
exday = exday.replace(/"/g, "");
var exstuff=JSON.stringify(narrativeinfo[0].phrase);
exstuff = exstuff.replace(/"/g, "");
document.getElementById("desc1").innerHTML = '<span>' + (exday+": "+exstuff) + '</span>'

var exday2=JSON.stringify(narrativeinfo[1].dayPart);
exday2 = exday2.replace(/"/g, "");
var exstuff2=JSON.stringify(narrativeinfo[1].phrase);
exstuff2 = exstuff2.replace(/"/g, "");
document.getElementById("desc2").innerHTML = '<span>' + (exday2+": "+exstuff2) + '</span>'

var exday3=JSON.stringify(narrativeinfo[2].dayPart);
exday3 = exday3.replace(/"/g, "");
var exstuff3=JSON.stringify(narrativeinfo[2].phrase);
exstuff3 = exstuff3.replace(/"/g, "");
document.getElementById("desc3").innerHTML = '<span>' + (exday3+": "+exstuff3) + '</span>'

var exday4=JSON.stringify(narrativeinfo[4].dayPart);
exday4 = exday4.replace(/"/g, "");
var exstuff4=JSON.stringify(narrativeinfo[4].phrase);
exstuff4 = exstuff4.replace(/"/g, "");
document.getElementById("desc4").innerHTML = '<span>' + (exday4+": "+exstuff4) + '</span>'

var exday5=JSON.stringify(narrativeinfo[5].dayPart);
exday5 = exday5.replace(/"/g, "");
var exstuff5=JSON.stringify(narrativeinfo[5].phrase);
exstuff5 = exstuff5.replace(/"/g, "");
document.getElementById("desc5").innerHTML = '<span>' + (exday5+": "+exstuff5) + '</span>'


//////////////////////////////////////////////////////////////////////////////////
var Sunrise=sunrise; //Sunrise

document.getElementById("sunrise").innerHTML = '<span>' + ('Sunrise: ' + Sunrise) + "am"+ '</span>'

//////////////////////////////////////////////////////////////////////////////////
var Sunset=sunset; //Sunset

document.getElementById("sunset").innerHTML = '<span>' + ('Sunset: ' + Sunset) + "pm"+'</span>'


///weather icon


var iconlocation="libraries/weather/white/icon/";
var imagelocation="libraries/weather/white/icon/";


var iconextention=".png" //image extentions


var newicos=localStorage.getItem('iconsetSB');


if(newicos!=null){
    if(newicos!=='null'){
      var imagelocation="http://JunesiPhone.com/weather/IconSets/"+newicos+"/";
      var iconlocation="http://JunesiPhone.com/weather/IconSets/"+newicos+"/";
      var iconextention=".png" //image extentions
    }
}



var day1=iconlocation+day1.icon+iconextention;
var day2=iconlocation+day2.icon+iconextention;
var day3=iconlocation+day3.icon+iconextention;
var day4=iconlocation+day4.icon+iconextention;


document.getElementById("Day1").innerHTML = '<img width='+daysize+' src='+day1+'>'
document.getElementById("Day2").innerHTML = '<img width='+daysize+' src='+day2+'>'
document.getElementById("Day3").innerHTML = '<img width='+daysize+' src='+day3+'>'
document.getElementById("Day4").innerHTML = '<img width='+daysize+' src='+day4+'>'



var hightemp1=dailyinfo[1].maxTemp;
var hightemp2=dailyinfo[2].maxTemp;
var hightemp3=dailyinfo[3].maxTemp;
var hightemp4=dailyinfo[4].maxTemp;

var iconf1=dailyinfo[1].day.icon;
var iconf2=dailyinfo[2].day.icon;
var iconf3=dailyinfo[3].day.icon;
var iconf4=dailyinfo[4].day.icon;


var lowtemp1=dailyinfo[1].minTemp;
var lowtemp2=dailyinfo[2].minTemp;
var lowtemp3=dailyinfo[3].minTemp;
var lowtemp4=dailyinfo[4].minTemp;

var day1date=JSON.stringify(dailyinfo[1].validDate);
var day2date=JSON.stringify(dailyinfo[2].validDate);
var day3date=JSON.stringify(dailyinfo[3].validDate);
var day4date=JSON.stringify(dailyinfo[4].validDate);

var dayname1 = new Date(day1date * 1000);
var dayname2 = new Date(day2date * 1000);
var dayname3 = new Date(day3date * 1000);
var dayname4 = new Date(day4date * 1000);

var currentday1 = dayname1.getDay();
var currentday2 = dayname2.getDay();
var currentday3 = dayname3.getDay();
var currentday4 = dayname4.getDay();

var daysofweek = new Array("Sun","Mon","Tues","Wed","Thurs","Fri","Sat");

 if(curlanguage=="it"||language=="it-it"){
var daysofweek = new Array("Sun", "Mon", "Mar", "Mer", "Gio", "Ven", "Sat");
}
else if(curlanguage=="sp"||language=="es-es"){
var daysofweek = new Array("Sol","Mon","Mar","Mie","Jue","Vie","Sat");
}
else if(curlanguage=="de"||language=="de-de"){
var daysofweek = new Array("Son","Mon","Die","Mit","Don","Fre","Sam");
}
else if(curlanguage=="fr"||language=="fr-fr"){
var daysofweek = new Array("Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam");
}
else{
  var daysofweek = new Array("Sun","Mon","Tues","Wed","Thurs","Fri","Sat");

}



var currentday1=daysofweek[currentday1];
var currentday2=daysofweek[currentday2];
var currentday3=daysofweek[currentday3];
var currentday4=daysofweek[currentday4];

document.getElementById("ForecastDay1").innerHTML = '<span>' + (currentday1) + '</span>'
document.getElementById("ForecastDay2").innerHTML = '<span>' + (currentday2) + '</span>'
document.getElementById("ForecastDay3").innerHTML = '<span>' + (currentday3) + '</span>'
document.getElementById("ForecastDay4").innerHTML = '<span>' + (currentday4) + '</span>'


document.getElementById("Day1High").innerHTML = '<span>' + (hightemp1+degrees + "/"+lowtemp1+degrees) + '</span>'

document.getElementById("Day2High").innerHTML = '<span>' + (hightemp2+degrees + "/"+lowtemp2+degrees) + '</span>'

document.getElementById("Day3High").innerHTML = '<span>' + (hightemp3+degrees + "/"+lowtemp3+degrees) + '</span>'

document.getElementById("Day4High").innerHTML = '<span>' + (hightemp4+degrees + "/"+lowtemp4+degrees) + '</span>'



try{
   var icon=json.HiradObservation.wxIcon;
   var currentIcon=json.HiradObservation.wxIcon;
}
catch(err){
  var icon=json.StandardObservation.wxIcon;
  var currentIcon=json.StandardObservation.wxIcon;
}



if(json.StandardObservation.wxIcon==""){json.StandardObservation.wxIcon="na"};
if(icon.length==0){
  icon="dunno";
}
var HourlyIcon=imagelocation+icon+imageextention;



iconimg=document.getElementById("iconimg"); 
iconimg.src=HourlyIcon;

window.NowIcon=icon;


  if(curlanguage=="it"){
 var Fcondition = [
"Tornado",
"Tempesta Tropicale",
"Uragano",
"Temporali Forti",
"Temporali",
"Pioggia mista a Neve",
"Nevischio",
"Nevischio",
"Pioggia Gelata",
"Pioggerella",
"Pioggia Ghiacciata",
"Pioggia",
"Pioggia",
"Neve a Raffiche",
"Neve Leggera",
"Tempesta di Neve",
"Neve",
"Grandine",
"Nevischio",
"Irregolare",
"Nebbia",
"Foschia",
"Fumoso",
"Raffiche di Vento",
"Ventoso",
"Freddo",
"Nuvoloso",
"Molto Nuvoloso",
"Molto Nuvoloso",
"Nuvoloso",
"Nuvoloso",
"Sereno",
"Sereno",
"Bel Tempo",
"Bel Tempo",
"Pioggia e Grandine",
"Caldo",
"Temporali Isolati",
"Temporali Sparsi",
"Temporali Sparsi",
"Rovesci Sparsi",
"Neve Forte",
"Nevicate Sparse",
"Neve Forte",
"Nuvoloso",
"Rovesci Temporaleschi",
"Rovesci di Neve",
"Temporali isolati",
"Non Disponibile"
 ];
  }
  else if(curlanguage=="sp"){
    var Fcondition=[
      "Tornado",
      "Tormenta Tropical",
      "Huracan",
      "Tormentas Electricas Severas",
      "Tormentas Electricas",
      "Mezcla de Lluvia y Nieve",
      "Mezcla de lluvia y aguanieve",
      "Mezcla de nieve y aguaniev",
      "Llovizna helada",
      "Llovizna",
      "Lluvia bajo cero",
      "Chubascos",
      "Chubascos",
      "Rafagas de nieve",
      "Ligeras precipitaciones de nieve",
      "Viento y nieve",
      "Nieve",
      "Granizo",
      "Aguanieve",
      "Polvareda",
      "Neblina",
      "Bruma",
      "Humeado",
      "Tempestuoso",
      "Vientoso",
      "Frio",
      "Nublado ",
      "Mayormente nublado",
      "Mayormente nublado",
      "despejado",
      "despejado",
      "Despejado",
      "Soleado",
      "Lindo",
      "Lindo",
      "Mezcla de lluvia y granizo",
      "Caluroso",
      "Tormentas electricas aisladas",
      "Tormentas electricas dispersas",
      "Tormentas electricas dispersas",
      "Chubascos dispersos",
      "Nieve fuerte",
      "Precipitaciones de nieve dispersas",
      "Nieve fuerte",
      "despejado",
      "Lluvia con truenos y relampagos",
      "Precipitaciones de nieve",
      "Tormentas aisladas",
      "No disponible"];
  }

  else if(curlanguage=="fr"){
    var Fcondition=[
      "Tornade",
      "Tropical",
      "Ouragan",
      "Orages Violents",
      "Orages",
      "Pluie",
      "Pluie",
      "Neige",
      "Bruine",
      "Bruine",
      "Pluie",
      "Averses",
      "Averses",
      "Quelques Flocons",
      "Faibles Chutes de Neige",
      "Rafales de Neige",
      "Neige",
      "GrÃªle",
      "Neige Fondue",
      "PoussiÃ©reux",
      "Brouillard",
      "Brume",
      "Brumeux",
      "TempÃªte",
      "Vent",
      "Temps Froid",
      "Temps Nuageux ",
      "TrÃ¨s Nuageux",
      "TrÃ¨s Nuageux",
      "Nuageux",
      "Nuageux",
      "Temps Clair",
      "Ensoleille",
      "Beau Temps",
      "Beau Temps",
      "Pluie et GrÃªles",
      "Temps Chaud",
      "Orages IsolÃ©s",
      "Orages Eparses",
      "Orages Eparses",
      "Averses Eparses",
      "Fortes Chutes de Neige",
      "Chutes de Neige Eparses",
      "Fortes Chutes de Neige",
      "Nuageux",
      "Orages",
      "Chute de Neige",
      "Orages IsolÃ©s",
      "Non Disponible"];
  }
else if(curlanguage=="de"){
    var Fcondition=[
      "Tornado",
      "Tropischer Sturm",
      "Wirbelsturm",
      "Schwere Gewitter",
      "Gewitter",
      "Regen und Schnee",
      "Graupelschauer",
      "Schneeregen",
      "Gefrierender Nieselregen",
      "Nieselregen",
      "Gefrierender Regen",
      "Schauer",
      "Schauer",
      "Schneegest&ouml;ber",
      "Leichte Schneeschauer",
      "Schneetreiben",
      "Schnee",
      "Hagel",
      "Schneeregen",
      "Staubig",
      "Nebelig",
      "Dunstschleier",
      "Dunstig",
      "St&uuml;rmisch",
      "Windig",
      "Kalt",
      "Bew&ouml;lkt ",
      "Meist Bew&ouml;lkt",
      "Meist Bew&ouml;lkt",
      "Bew&ouml;lkt",
      "Bew&ouml;lkt",
      "Klar",
      "Sonnig",
      "Heiter",
      "Heiter",
      "Regen und Hagel",
      "Heiss",
      "&Ouml;rtliche Gewitter",
      "Vereinzelte Gewitte",
      "Vereinzelte Gewitte",
      "Vereinzelte Schauer",
      "Starker Schneefall",
      "Vereinzelte Schneeschauer",
      "Starker Schneefall",
      "Bew&ouml;lkt",
      "Gewitter",
      "Scheeschauer",
      "Ouml;rtliche Gewitterschauer",
      "Nicht Verfuegbar"];
  }
  else if (curlanguage=="en"){
     var Fcondition = [
  "Tornado","Tropical Storm","Hurricane","Thunderstorm","Thunderstorm","Snow","Sleet",
  "Sleet",
  "Freezing Drizzle",
  "Drizzle",
  "Freezing Rain",
  "Showers",
  "Showers",
  "Flurries",
  "Snow",
  "Snow",
  "Snow",
  "Hail",
  "Sleet",
  "Dust",
  "Fog",
  "Haze",
  "Smoky",
  "Blustery",
  "Windy",
  "Cold",
  "Cloudy",
  "Cloudy",
  "Cloudy",
  "Cloudy",
  "Cloudy",
  "Clear",
  "Sunny",
  "Fair",
  "Fair",
  "Sleet",
  "Hot",
  "Thunderstorms",
  "Thunderstorms",
  "Thunderstorms",
  "Showers",
  "Heavy Snow",
  "Light Snow",
  "Heavy Snow",
  "Partly Cloudy",
  "Thunderstorm",
  "Snow",
  "Thunderstorm",
  "blank"];
  }

var Rcondition = [
  "Oh shit a tornado",
  "Damn tropical storm",
  "Run its a hurricane",
  "Fucking thunderstorm",
  "Fuck its a thunderstorm",
  "Fuck its snowing",
  "Fucking sleet",
  "Fucking sleet",
  "Fuck it's drizzling",
  "Fuck it's drizzling",
  "Fucking freezing rain",
  "Fuck it's raining",
  "Fuck it's raining",
  "Fucking flurries",
  "Fucking light snow",
  "Fuck it's snowing",
  "Fuck it's snowing",
  "Fucking hailing",
  "Fuck it's sleeting",
  "Fucking dusty out here",
  "Fucking foggy",
  "Fucking hazy",
  "Fucking smoky",
  "WTF it's blustery",
  "Windy as fuck",
  "Cold as fuck",
  "It's fucking cloudy",
  "It's fucking mostly cloudy",
  "It's fucking mostly cloudy",
  "It's fucking partly cloudy",
  "It's fucking partly cloudy",
  "It's fucking clear",
  "It's fucking sunny outside",
  "Fucking fair",
  "Fucking fair",
  "Fucking sleeting",
  "Fuck it's hot",
  "Isolated fucking thunderstorms",
  "Scattered fucking thunderstorms",
  "Scattered fucking thunderstorms",
  "Scattered fucking showers",
  "Heavy fucking snow",
  "Light fucking snow",
  "Heavy fucking snow",
  "Partly fucking cloudy",
  "Fucking thunderstorm",
  "It's fucking snowing",
  "It's a fucking thunderstorm",
  "blank"];

   var rweatherdesc=Rcondition[icon];
   var f1=Fcondition[iconf1];
   var f2=Fcondition[iconf2];
   var f3=Fcondition[iconf3];
   var f4=Fcondition[iconf4];


    document.getElementById("rude").innerHTML = '<span>' + (rweatherdesc) + '</span>';
    document.getElementById("fcast1").innerHTML = '<span><img style="position:relative;top:10px;" width="40" src='+day1+'>' + (currentday1+", "+f1+" - "+hightemp1+degrees + "/"+lowtemp1+degrees) + '</span>';
    document.getElementById("fcast2").innerHTML = '<span><img style="position:relative;top:10px;" width="40" src='+day2+'>' + (currentday2+", "+f2+" - "+hightemp2+degrees + "/"+lowtemp2+degrees) + '</span>';
    document.getElementById("fcast3").innerHTML = '<span><img style="position:relative;top:10px;" width="40" src='+day3+'>' + (currentday3+", "+f3+" - "+hightemp3+degrees + "/"+lowtemp3+degrees) + '</span>';
    document.getElementById("fcast4").innerHTML = '<span><img style="position:relative;top:10px;" width="40" src='+day4+'>' + (currentday4+", "+f4+" - "+hightemp4+degrees + "/"+lowtemp4+degrees) + '</span>';

    iconimg=document.getElementById("day1iconi"); 
    iconimg.src=day1;
    iconimg2=document.getElementById("day2iconi"); 
    iconimg2.src=day2;
    iconimg3=document.getElementById("day3iconi"); 
    iconimg3.src=day3;
    iconimg4=document.getElementById("day4iconi"); 
    iconimg4.src=day4;

    document.getElementById("day1hi").innerHTML = '<span>' + (hightemp1+degrees) + '</span>';
    document.getElementById("day1lo").innerHTML = '<span>' + (lowtemp1+degrees) + '</span>';
    document.getElementById("day1des").innerHTML = '<span>' + (f1) + '</span>';
    document.getElementById("day2hi").innerHTML = '<span>' + (hightemp2+degrees) + '</span>';
    document.getElementById("day2lo").innerHTML = '<span>' + (lowtemp2+degrees) + '</span>';
    document.getElementById("day2des").innerHTML = '<span>' + (f2) + '</span>';
    document.getElementById("day3hi").innerHTML = '<span>' + (hightemp3+degrees) + '</span>';
    document.getElementById("day3lo").innerHTML = '<span>' + (lowtemp3+degrees) + '</span>';
    document.getElementById("day3des").innerHTML = '<span>' + (f3) + '</span>';
    document.getElementById("day4hi").innerHTML = '<span>' + (hightemp4+degrees) + '</span>';
    document.getElementById("day4lo").innerHTML = '<span>' + (lowtemp4+degrees) + '</span>';
    document.getElementById("day4des").innerHTML = '<span>' + (f4) + '</span>';
    
//end weathericon

var weatherwall=localStorage.getItem('weatherwallsSB');
if(weatherwall=="yes"){
  var backwall=document.getElementById('background');
  var newimage="http://JunesiPhone.com/weather/IconSets/Icons/"+currentIcon+".jpg";
   backwall.style.backgroundImage = 'url('+newimage+')';
}


};







function ShowContent() {
  Showdata();
}


function getdates(){
  var date = new Date();
  var day = date.getDay();
  var datetoday=date.getDate();
  var year=date.getFullYear();
  var monthnum=date.getMonth();
  var textdate=["First","Second","Third","Fourth","Fifth","Sixth","Seventh","Eighth","Ninth","Tenth","Eleventh","Twelfth","Thirteenth","Fourteenth","Fifteenth","Sixteenth","Seventeenth","Eightheenth","Nineteenth","Twentieth","TwentyFirst","TwentySecond","TwentyThird",'TwentyFourth',"TwentyFifth","TwentySixth","TwentySeventh","TwentyEight","TwentyNinth"," Thirtieth","ThirtyFirst"][datetoday-1];

  if(curlanguage=="en"){
  var name = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][day];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"][monthnum];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][monthnum];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][day];
  }
  else if(curlanguage=="it"){
  var name = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"][day];
  var month=["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"][monthnum];
  var smonth=["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"][monthnum];
  var sday=["Sun", "Mon", "Mar", "Mer", "Gio", "Ven", "Sat"][day];
  }
  else if(curlanguage=="sp"){
  var name = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"][day];
  var month=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"][monthnum];
  var smonth=["Ene","Feb","Mar","Abr","Mayo","Jun","Jul","Aug","Sep","Oct","Nov","Dic"][monthnum];
  var sday=["Sol","Mon","Mar","Mie","Jue","Vie","Sat"][day];
  }
  else if(curlanguage=="de"){
  var name = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"][day];
  var month=["Januari","Februari","Maart","April","Kunnen","Juni","Juli","Augustus","September","Oktober","November","Dezember"][monthnum];
  var smonth=["Jan", "Feb", "Maa", "Apr", "Kun", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez "][monthnum];
  var sday=["Son","Mon","Die","Mit","Don","Fre","Sam"][day];
  }
  else if(curlanguage=="fr"){
  var name = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"][day];
  var month=["Janvie","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"][monthnum];
  var smonth=["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"][monthnum];
  var sday=["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"][day];
  }
  else{
  var name = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][day];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"][monthnum];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][monthnum];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][day];
  }




  document.getElementById("DMD").innerHTML = '<span>' + name + ", "+month+" "+datetoday+'</span>';
  document.getElementById("MD").innerHTML = '<span>'+month+" "+datetoday+'</span>';
  document.getElementById("DM").innerHTML = '<span>'+datetoday+" "+month+'</span>';
  document.getElementById("DSM").innerHTML = '<span>'+datetoday+" "+smonth+'</span>';
  document.getElementById("day").innerHTML = '<span>' + name +'</span>';
  document.getElementById("sday").innerHTML = '<span>' + sday +'</span>';
  document.getElementById("date").innerHTML = '<span>' + datetoday +'</span>';
  document.getElementById("tdate").innerHTML = '<span>' + textdate +'</span>';
  document.getElementById("month").innerHTML = '<span>' + month +'</span>';
  document.getElementById("smonth").innerHTML = '<span>' + smonth +'</span>';
  document.getElementById("year").innerHTML = '<span>' + year +'</span>';
}
setInterval(function(){updateClock()},30000);
setInterval(function(){getdates()},1800000);
getdates();
updateClock();

function updateClock(){
    // var TwentyFourHourClock = localStorage.getItem('time'); 
     
 
if (TwentyFourHourClock == "false"){
  

  var currentTime = new Date ( );
   var currentHours = currentTime.getHours ( );
   var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( ); currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  var currentTimeString = currentHours + ":" + currentMinutes;
  document.getElementById("zhour").innerHTML = '<span>' + currentHours + '</span>';
  document.getElementById("hour").innerHTML = '<span>' + currentHours + '</span>';
  document.getElementById("minute").innerHTML = '<span>' + currentMinutes + '</span>';
  document.getElementById("time").innerHTML = '<span>' + currentTimeString + '</span>';
  document.getElementById("ztime").innerHTML = '<span>' + currentzHours +":"+ currentMinutes + '</span>';
  

  var t = currentTime;
        var n = t.getHours();
        var r = t.getMinutes();
        var i = t.getSeconds();
        n = (n < 10 ? "0" : "") + n;
        r = (r < 10 ? "0" : "") + r;
        var o = n + ":" + r;
        var u = new Array("Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "TwentyOne", "TwentyTwo", "TwentyThree", "TwetyFour");
        var a = new Array("o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty");
        var f = new Array("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "");
        var t = new Date;
        var n = t.getHours();
        var r = t.getMinutes();
        var l = t.getMinutes();
        var i = t.getSeconds();
        var o = u[n];
        var c = a[r];
        var h = f[l];
        document.getElementById("ttext").innerHTML = o + "\n" + c + "\n" + h;
        document.getElementById("htext").innerHTML = o;
        document.getElementById("mtext").innerHTML = c + "\n" + h;

}

if (TwentyFourHourClock == "true"){

   var currentTime = new Date ( );
   var currentHours = currentTime.getHours ( );
   var currentMinutes = currentTime.getMinutes ( );
   var currentSeconds = currentTime.getSeconds ( );
   currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
   currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
   var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
   currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
   currentHours = ( currentHours == 0 ) ? 12 : currentHours;
   var currentzHours=( currentHours < 10 ? "0" : "" ) + currentHours;
   var currentTimeString = currentHours + ":" + currentMinutes;
 document.getElementById("hour").innerHTML = '<span>' + currentHours + '</span>';
 document.getElementById("zhour").innerHTML = '<span>' + currentzHours + '</span>';
 document.getElementById("minute").innerHTML = '<span>' + currentMinutes + '</span>';
 document.getElementById("time").innerHTML = '<span>' + currentTimeString + '</span>';
 document.getElementById("ztime").innerHTML = '<span>' + currentzHours +":"+ currentMinutes + '</span>';
   
  var t = currentTime;
        var n = t.getHours();
        var r = t.getMinutes();
        var i = t.getSeconds();
        r = (r < 10 ? "0" : "") + r;
        i = (i < 10 ? "0" : "") + i;
        var s = n < 12 ? "AM" : "PM";
        n = n > 12 ? n - 12 : n;
        n = n == 0 ? 12 : n;
        var o = n + ":" + r;
        var u = new Array("Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve");
        var a = new Array("o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty");
        var f = new Array("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "");
        var t = new Date;
        var n = t.getHours();
        var r = t.getMinutes();
        var l = t.getMinutes();
        var i = t.getSeconds();
        var o = u[n];
        var c = a[r];
        var h = f[l];
        document.getElementById("ttext").innerHTML = o + "\n" + c + "\n" + h;
        document.getElementById("htext").innerHTML = o;
        document.getElementById("mtext").innerHTML = c + "\n" + h;
}

var todayDate=new Date();
var hours=todayDate.getHours();
var format ="AM";
if(hours>11){format="PM";
}
document.getElementById("pm").innerHTML = '<span>' + format + '</span>'



}//end updateclock

//GetXmlFeed(true); Turned off controlled by GPS cydget




