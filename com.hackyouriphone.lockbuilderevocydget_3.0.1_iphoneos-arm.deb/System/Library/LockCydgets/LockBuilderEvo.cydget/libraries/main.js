/////////////////////////////////


var bgDIV = getEL('background');
var overlayDIV = getEL('overlay');
var selwallDIV = getEL('selectwalls');
var topmenuDIV = getEL('topmenus');
var savedhideobj=loadLocal('hideOBJ'); //objects that are shown/hidden
var menuloaded=0;

function toggleiconEl(ele){
    if(ele.css('display')==="none"){
        ele.css('display','block');
    }
    else{
        ele.css('display','none');
    }
}

function setalignments(alignm){
    var caldiv;
    caldiv = loadLocal('helperel');
    $('#' + caldiv).css('text-align', alignm);
    alignobj(caldiv, alignm);
}

getEL('fontmenuicon').addEventListener('click', function (event) {
    toggleiconEl($('.fontelements'));
 });

getEL('opacitymenuicon').addEventListener('click', function (event) {
    toggleiconEl($('#opacity'));
 });

getEL('colormenuicon').addEventListener('click', function (event) {
    opencolor();
 });


getEL('rotatemenuicon').addEventListener('click', function (event) {
    toggleiconEl($('.rotateelements'));
 });
getEL('scalemenuicon').addEventListener('click', function (event) {
    toggleiconEl($('.scaleelements'));
 });
getEL('shadowmenuicon').addEventListener('click', function (event) {
    opendropmenu();
 });
getEL('alignmenuicon').addEventListener('click', function (event) {
     toggleiconEl($('.alignoptions'));
 });

getEL('Aleft').addEventListener('click', function (event) {
     setalignments('left');
 });

getEL('Acenter').addEventListener('click', function (event) {
     setalignments('center');
 });

getEL('Aright').addEventListener('click', function (event) {
     setalignments('right');
 });


getEL('movemenuicon').addEventListener('click', function (event) {
     opencontrols();
    closehelper();
    $('#dpad').css('display','block');
    $('#dpad').touch();
 });


var getitems, currentwall;
getitems = loadLocal('userbg');
if (getitems !== null) {
    if (getitems.length >= 100) {
        bgDIV.style.backgroundImage = "url(" + getitems + ")";
    }
}

function addappdoubleclick(key){
    $('#'+key).on('doubletap', function() { //add double tap to each element
        var dblelement=$(this).attr("id");
        localStorage.setItem('helperel',dblelement);
        //var posel=$('#'+key).css('-webkit-transform');
        //alert(posel);
        //var style = window.getComputedStyle($('#'+key).get(0));  // Need the DOM object
        //var matrix = new WebKitCSSMatrix(style.webkitTransform);
        //var str=JSON.stringify(matrix);
        //alert(str);
        //alert(matrix.f);
        //$('#helper').css('top',matrix.f-30+"px"); 
        //var tp2=$('#helper').css('top');
        //tp2=tp2.slice(0,-2);
        //if(tp2<=60){
          $('#helper').css('top',"0px"); 
          $('#helper').css('display',"block"); 
        //}
        $('#helper').css('opacity','1');
    });
}



checkKey = function(key){
    if($('#' + key).length){return true;} 
}


function blurbackground(){bgDIV.style.zIndex="30";bgDIV.className = "blurred";}
function unblurbackground(){bgDIV.style.zIndex="1";bgDIV.className = "";}
function openoverlay(overlay) {
    var docoverlay;
    saveLocal('overlay', overlay);
    overlayDIV.style.display = "block";
    overlayDIV.src = "/var/mobile/Library/LBEvoOverlays/" + overlay;
    $('.overlays').remove();
}



function getiwidgetsize(widget) {
  try {
    var iwidgetsettings = readDict('/var/mobile/Library/iWidgets/' + widget + '/Widget.plist');
    if (iwidgetsettings != null) {
        iwidgetwidth = iwidgetsettings.size.width;
        iwidgetheight = iwidgetsettings.size.height;
    }   
  } catch (err) {
         alert("iWidget"+err);
  }
  try {
    var documentsPath = "/var/mobile/Library/iWidgets/" + widget +"/Options.plist";
    var wfileExists = fileExists(documentsPath);
    if (wfileExists == true) {
        alert("This iWidget has options.plist where settings are set through iWidget. It may not work in LBEvo.");
        loadiwidgetnow();
    }
    else if (wfileExists == false) {
        loadiwidgetnow();
    }
    function loadiwidgetnow() {
        loadiwidgets(widget, iwidgetwidth, iwidgetheight);
    }
  } catch (err) {
    alert("iWidget2"+err);
  }
}

function loadanimations() {
    closemenu();
    getEL('animations').style.display = "block";
    localStorage.removeItem('hiddenbg');
    bgDIV.style.visibility = "visible";
    alert("Animations with password set may cause safemode. Recommended to use without passcode.");
    var allfiles = readplist('/var/mobile/Library/LBEvoAnimations/');
    for (var i = 0; i < allfiles.length; i++) {
        ids = allfiles[i];
        classname = "animations";
        d1 = document.createElement('div');
        $(d1).addClass(classname).html("" + ids).appendTo($('#animations')).click(function() {
            thisname = this.innerHTML;
            openanimations(thisname);
        });
    }
    d2 = document.createElement('div');
    $(d2).addClass(classname).html("Remove current animation").appendTo($('#animations')).click(function() {
        thisname = this.innerHTML;
        stopanimations();
    });
    blurbackground();
}

//groovylock
function loadGL() {
    blurbackground();
    closemenu();
    var Gallfiles=readplist('/var/mobile/Library/GroovyLock/');
    for (var w = 0; w < Gallfiles.length; w++) {
      Gids = Gallfiles[w];
      Gclassname = "lockscreen";
      Gd = document.createElement('div');
      $(Gd).addClass(Gclassname).html("" + Gids).appendTo($('#lockscreens')).click(function () {thisname = this.innerHTML;openlock(thisname);unblurbackground();});
    }
}
//springboard
  function saveSBtheme(){
    var sbstore = ['dragOBJ','capsOBJ','hideOBJ','iconimgOBJ','iconOBJ','colorOBJ','fontOBJ','opacityOB','scaleOBJ','userbg','shadowOBJ','lockscreenchosen','newiconimgOBJ','iconset','objiwidgets','animations','weatherwalls','createdobjcreate','alignOB','widget'];
    var randomsave=Math.floor(Math.random()*101);
        for(sa=0; sa < sbstore.length; sa++){
                saveLocal(sbstore[sa]+"SB",loadLocal(sbstore[sa]));
        }
    if(loadLocal('overlay')!=null||loadLocal('overlay')!="null"){saveLocal('overlaySB',loadLocal('overlay'));}
    saveLocal('randomsave',randomsave);
    alert("Saved to Springboard, enable LockBuilder Evo SB in SBHTML.");
    window.location = window.location.href;
}

function loadoverlay() {
    blurbackground();
    closemenu();
    var dirOverlays=readplist('/var/mobile/Library/LBEvoOverlays/');
    for (var v = 0; v < dirOverlays.length; v++) {
        var Lids = dirOverlays[v];
        Lclassname = "overlays";
        Ld = document.createElement('div');
        $(Ld).addClass(Lclassname).html("" + Lids).appendTo($('#overlays')).click(function () {thisname = this.innerHTML;openoverlay(thisname);unblurbackground();});
      }
}

function iWidget() {
  blurbackground();
  closemenu();
  var Wallfiles=readplist('/var/mobile/Library/iWidgets/');
    for (var u = 0; u < Wallfiles.length; u++) {
        Wids = Wallfiles[u];
        Wclassname = "iwidget";
        Wd = document.createElement('div');
        $(Wd).addClass(Wclassname).html("" + Wids).appendTo($('#iwidget')).click(function () {unblurbackground();thisname = this.innerHTML;openiwidget(thisname);});
    }
}

if (loadLocal('overlay') !== null) {
    getEL('overlay').src = "/var/mobile/Library/LBEvoOverlays/" + loadLocal('overlay');
    getEL('overlay').style.display="block";
}

function handleFileSelect(e) {
    var tw, ncount, rd, us;
    tw = e.target.files;
    for (ncount = 0, us; us = tw[ncount]; ncount++) {
        rd = new FileReader;
        rd.onload = function(e) {
            return function(e) {
                saveLocal("userbg", e.target.result);
                getEL('background').style.backgroundImage = "url(" + loadLocal('userbg') + ")";
                setLSWall(e.target.result);
                closemenu();
            }
        }(us);
        rd.readAsDataURL(us);
    }
}

getEL("files").addEventListener("change", handleFileSelect, false);
//show items

function createweathermenu() { //show weather menu
    createweatherEL();
    getEL('weathermenu').style.display="block";
    getEL('premenu').style.display="none";
    $('#weathermenu').touch();
}




function createweatherEL() { //create element menu
    menuloaded++
    if (menuloaded == 1) {
        var weatherel, weatherel2;
        $("ul li").children("div").each(function() {
            weatherel = $(this).attr('id');
            createliMenu(weatherel);
        });
        $("ul li").children("p").each(function() {
            weatherel2 = $(this).attr('id');
            createliMenu(weatherel2);
        });
        if(savedhideobj!=null){
    hideOBJ=JSON.parse(savedhideobj);
    objH=hideOBJ;

    $.each(objH, function(key, value) {
        //$('#'+key).css('display', value);
        if (value != "none") {
            $('#menu'+key).css('color','rgba(255,255,255,1)');
            $('#menu'+key).css('text-shadow','0px 1px rgba(0,0,0,0.2)');
        }
        else{
            $('#menu'+key).css('color','#1d1d1d'); 

        }
    });
  }
    } else {}
}

$('#Design').click(function(){
    if(getEL('create').style.display==="none"){
        getEL('create').style.display="block";
    }
    else{
        getEL('create').style.display="none"; 
    }
})

function loopsubmenu(array,display){
    for (var We = 0; We < array.length; We += 1) {
                 getEL("menu"+array[We]).style.display=display;
            }
}

function expandapps(app) {
    var WeatherEl = ['icon', 'temp','tempFC','windsp','windir','elevation','feeltemp','condition','rude','later','hi','low','uv','raininfo','desc1','desc2','desc3','desc4','desc5','fcast1','fcast2','fcast3','fcast4','day1icon','day1des','day1lo','day1hi','day2icon','day3des','day3lo','day3hi','day4icon','day4des','day4lo','day4hi','dew','humidity','rainfall','tdesc','visible','warning','forecast'];
    var ClocksEl = ['ztime','time','zhour','hour','minute','pm','ttext','htext','mtext','DMD','MD','DM','DSM','day','date','tdate','month','sday','smonth','year','sunrise','sunset','events'];
    var TextsEl = ['slash','slash2','Dlocked','comma','colon','min','max','L2','H2','L','H'];
    var LocalEl = ['city','nhood','street','addr','county','lat','long','latext','longext','state','statenm','county'];
    var NotifyEl = ['sms','mail','phone','twitter','tweetbot','whatapp'];
    var SystemEl = ['dsize','dfree','msize','CPU','firm','uptime','battery','unlock','name','speak'];
    if (app === "Weather") {
        if (getEL('menuicon').style.display === "none") {
            loopsubmenu(WeatherEl,"block");
        }
        else{
            loopsubmenu(WeatherEl,"none");
        }
    }
    else if(app==="Clocks"){
        if(getEL('menuztime').style.display==="none"){
            loopsubmenu(ClocksEl,"block");
        }
        else{
            loopsubmenu(ClocksEl,"none");
        }
    }
    else if(app==="Texts"){
        if(getEL('menuslash').style.display==="none"){
            loopsubmenu(TextsEl,"block");
        }
        else{
            loopsubmenu(TextsEl,"none");
        }
    }
    else if(app==="Local"){
        if(getEL('menucity').style.display==="none"){
            loopsubmenu(LocalEl,"block");
        }
        else{
            loopsubmenu(LocalEl,"none");
        }
    }
    else if(app==="Notify"){
        if(getEL('menusms').style.display==="none"){
            loopsubmenu(NotifyEl,"block");
        }
        else{
            loopsubmenu(NotifyEl,"none");
        }
    }
    else if(app==="System"){
        if(getEL('menudsize').style.display==="none"){
            loopsubmenu(SystemEl,"block");
        }
        else{
            loopsubmenu(SystemEl,"none");
        }
    }


}

var amenu, limenu, ulmenu, linkFunction;

function createliMenu(app) { //check if menu item is spacer/category/element
    amenu = document.createElement("a");
    if (app == "Weather" || app == "Clocks" || app == "Texts" || app == "Local" || app == "System" || app == "Notify") {
        amenu.setAttribute('class', 'spacers');
        menuFunction = "expandapps('"+app+"')";
        amenu.setAttribute('onClick',menuFunction);
        amenu.appendChild(document.createTextNode(app));
    } else if (app == "lspace" || app == "lspace2" || app == "lspace3" || app == "lspace4" || app == "lspace5" || app == "lspace6") {
        amenu.setAttribute('class', 'space');
        amenu.appendChild(document.createTextNode(app));
    } else {
        amenu.id = "menu" + app;
        amenu.style.display = "none";
        amenu.appendChild(document.createTextNode(app));
    }
    limenu = document.createElement("li");
    limenu.appendChild(amenu);
    if (app == "Weather" || app == "Clocks" || app == "Texts" || app == "Local" || app == "System" || app == "Notify") {} else if (app == "lspace" || app == "lspace2" || app == "lspace3" || app == "lspace4" || app == "lspace5" || app == "lspace6") {} else {
        linkFunction = "addapps('" + app + "')";
        limenu.setAttribute('onClick', linkFunction);
        limenu.setAttribute('class', 'needsclick');
    }
    ulmenu = getEL("weathermenu");
    ulmenu.insertBefore(limenu, getEL("close"));
}

function saveweatherdisplay(app) { //save element to localStorage
    var currentdisplay, savedhideobj, hidemainOBJ, myhideObject;
    currentdisplay = $('#'+app).css('display');
    hideOBJ = {};
    savedhideobj = loadLocal('hideOBJ');
    if (savedhideobj !== null) {
        hideOBJ = JSON.parse(savedhideobj);
    }
    hideOBJ[app] = [currentdisplay];
    myhideObject = JSON.stringify(hideOBJ);
    saveLocal('hideOBJ', myhideObject);
    addappdoubleclick(app);
}

function addapps(app) { //shade element in menu when placed
   if(getEL(app).style.display){
        if (getEL(app).style.display === "none") {
            getEL(app).style.display = "block";
            $('#menu'+app).css('color','rgba(255,255,255,1)');
            $('#menu'+app).css('text-shadow','0px 1px rgba(0,0,0,0.2)');
        } else {
            getEL(app).style.display="none";
            getEL('menu'+app).style.color = "#1d1d1d";
            $('#menu'+app).css('text-shadow','0px 1px rgba(255,255,255,0.2)');
        }
    }else{
        getEL(app).style.display = "block";
         $('#menu'+app).css('color','rgba(255,255,255,1)');
            $('#menu'+app).css('text-shadow','0px 1px rgba(0,0,0,0.2)'); 
    }
    saveweatherdisplay(app); 
}


$('#newitems').on('doubletap',function(){ //double tap screen to unlock
        unlockphone();
    });


  function showValueopacity(value){ //save opacity of item to localStorage
    var cdiv=loadLocal('helperel');
    getEL(cdiv).style.opacity=value;
    opacityobj(cdiv,value);
  }

  function iconmenu(){ //hide/show icon menu
    getEL('premenu').style.display = "none";
    getEL('iconmenu').style.display = "block";
  }


$('#premenu').touch();


function firefiles() {selwallDIV.style.left = "180px";selwallDIV.style.top = "0px";}
function hideme(){selwallDIV.style.left = "400px";}
function showtm(){topmenuDIV.style.display = "block";}
function hidetm(){topmenuDIV.style.display = "none";}
if (screen.height > 500) {var iPhoneType = "iPh5";}else {var iPhoneType = "iPh4";}
if(loadLocal('hiddenbg')){bgDIV.style.visibility="hidden";}else{}
if (loadLocal('overlay') !== null) {
    getEL('overlay').src = "/var/mobile/Library/LBEvoOverlays/" + loadLocal('overlay');
    getEL('overlay').style.display="block";
}
getEL('maskedbg').style.backgroundImage = "url(" + loadLocal('userbg') + ")";
localStorage.removeItem('iconox');
localStorage.removeItem('iconoy');

///////////////////////////////////

//icons
function iconimgobj(iconimgname, iconimgs) { //when icon is selected
    var iconimgOBJ, savediconimg, iconimgOBJ, myimgObject;
    iconimgOBJ = {};
    savediconimg = loadLocal('iconimgOBJ');
    if (savediconimg !== null) {
        iconimgOBJ = JSON.parse(savediconimg);
    }
    iconimgOBJ[iconimgname] = [iconimgs];
    myimgObject = JSON.stringify(iconimgOBJ);
    saveLocal('iconimgOBJ', myimgObject);
}

function newiconimgOBJ(newiconname, newiconimg) {
    var newiconimgOBJs, savediconimg, myimgObject;
    newiconimgOBJs = {};
    savediconimg = loadLocal('newiconimgOBJ');
    if (savediconimg !== null) {
        newiconimgOBJs = JSON.parse(savediconimg);
    }
    newiconimgOBJs[newiconname] = [newiconimg];
    myimgObject = JSON.stringify(newiconimgOBJs);
    saveLocal('newiconimgOBJ', myimgObject);
}


function iconobj(iconobjname, myTransform) {
    var matrix, values, aiconM, biconM, iconangle, iconOBJ, savediconobj, myObject;
    matrix = $('#' + iconobjname).css('-webkit-transform');
    if (matrix !== "none") {
        values = matrix.split('(')[1].split(')')[0].split(',');
        aiconM = values[0];
        biconM = values[1];
        iconangle = Math.round(Math.atan2(biconM, aiconM) * (180 / Math.PI));
        saveLocal(iconobjname + 'defaultrotation', iconangle);
    }
    iconOBJ = {};
    savediconobj = loadLocal('iconOBJ');
    if (savediconobj !== null) {
        iconOBJ = JSON.parse(savediconobj);
    }
    iconOBJ[iconobjname] = [myTransform];
    myObject = JSON.stringify(iconOBJ);
    saveLocal('iconOBJ', myObject);
}

function deleteFromObject(keyToDelete, mobj) {

    var myObject;
    $.each(mobj, function (delkey, delvalue) {
        if (delkey === keyToDelete) {
            delete mobj[delkey];
        }
    });
    myObject = JSON.stringify(mobj);
    saveLocal('iconOBJ', myObject);
}


function closethisapp(appdelkey) {
    iconOBJ = JSON.parse(loadLocal('iconOBJ'));
    $('#' + appdelkey).remove();
    //closehelper(); //keep open to delete more apps
    deleteFromObject(appdelkey, iconOBJ);
}



//////////////////////////////////////

function scaleobj(sce, sct) {
    var scn, scr, sci;
    scn = {};
    scr = loadLocal("scaleOBJ");
    if (scr !== null) {
        scn = JSON.parse(scr);
    }
    scn[sce] = [sct];
    sci = JSON.stringify(scn);
    saveLocal("scaleOBJ", sci);
}


////////////////////////
function colorobj(colorkey, colorvalue) {
    var mcolorobj, scolorobj, pcolorobj, strcolorobj;
    mcolorobj = {};
    scolorobj = loadLocal("colorOBJ");
    if (scolorobj !== null) {
        pcolorobj = JSON.parse(scolorobj);
        mcolorobj = pcolorobj;
    }
    mcolorobj[colorkey] = [colorvalue];
    strcolorobj = JSON.stringify(mcolorobj);
    saveLocal("colorOBJ", strcolorobj);
}

function shadowobj(shadowkey, shadowvalue) {
    var shobj, savesobj, pshadowobj, strshadowobj;
    shobj = {};
    savesobj = loadLocal("shadowOBJ");
    if (savesobj !== null) {
        pshadowobj = JSON.parse(savesobj);
        shobj = pshadowobj;
    }
    shobj[shadowkey] = [shadowvalue];
    strshadowobj = JSON.stringify(shobj);
    saveLocal("shadowOBJ", strshadowobj);
}



/////////////////////
function opacityobj(elopacityobj, elopacityname) {
    var sopacityobj, svdopacityobj, prsdopacityobj, opacityobjstring;
    sopacityobj = {};
    svdopacityobj = loadLocal("opacityOB");
    if (svdopacityobj !== null) {
        prsdopacityobj = JSON.parse(svdopacityobj);
        sopacityobj = prsdopacityobj;
    }
    sopacityobj[elopacityobj] = [elopacityname];
    opacityobjstring = JSON.stringify(sopacityobj);
    saveLocal("opacityOB", opacityobjstring);
}

/////////////////////
function alignobj(elalignname, elalignval) {
    var storedalignobj, prsedalignobj, mainalignobj, mainalignstring;
    mainalignobj = {};
    storedalignobj = loadLocal("alignOB");
    if (storedalignobj !== null) {
        prsedalignobj = JSON.parse(storedalignobj);
        mainalignobj = prsedalignobj;
    }
    mainalignobj[elalignname] = [elalignval];
    mainalignstring = JSON.stringify(mainalignobj);
    saveLocal("alignOB", mainalignstring);
}


////////////////////

//iWidget
function openiwidget(iwidgetscreen){
    getiwidgetsize(iwidgetscreen);
   closemenupressed();
}

function loadiwidgets(widget, width, height) {
    var widgetname, objiwidget, savedwidget, name, preparedwidget, container, swipecontain, link, widgetframe, widgetdiv, moverdiv, isLocked;
    widgetname = widget.replace(/\s+/g, '');
    widgetname = widgetname.replace(/[^\w\s]/g, '');

    objiwidget = {};
    savedwidget = loadLocal('objiwidgets');
    if (savedwidget !== null) {
        objiwidget = JSON.parse(savedwidget);
    }
    name = widgetname;
    objiwidget[name] = widget + ',' + width + ',' + height;
    preparedwidget = JSON.stringify(objiwidget);
    saveLocal('objiwidgets', preparedwidget);


    container = getEL('iwidgetcontainer');
    $('<div id="' + widgetname + '" style="position:absolute;" class="noswipe" class="iwidgetclass"></div>').appendTo(container);
    swipecontain = getEL(widgetname);
    $('<div id="iwidgetswipe' + widgetname + '" style="position:absolute; "></div>').appendTo(swipecontain);

    link = "file:///var/mobile/Library/iWidgets/" + widget + "/Widget.html";
    widgetframe = document.createElement('iframe');
    widgetframe.frameBorder = 0;
    widgetframe.style.left = "0px";
    widgetframe.style.position = "absolute";
    widgetframe.style.width = width + "px";
    widgetframe.style.height = height + "px";
    widgetframe.style.backgroundColor = "transparent";
    widgetframe.id = widgetname + "iframes";
    widgetframe.setAttribute("src", link);
    widgetframe.setAttribute("class", "iwidgetclass");
    getEL("iwidgetswipe" + widgetname).appendChild(widgetframe);

    $('#iwidgetswipe' + widgetname).css({
        'height': '' + height + 'px',
        'width': '' + width + 'px',
        'background-color': 'rgba(255,255,255,0.0)', //woo! set background color to size widgetframe
        'overflow': 'hidden'
    });

    widgetdiv = getEL(widgetname);
    moverdiv = document.createElement("div");
    moverdiv.style.zIndex = "10";
    moverdiv.style.width = width + "px";
    moverdiv.style.height = height + "px";
    moverdiv.style.backgroundColor = "transparent";
    moverdiv.id = widgetname + "mover";
    widgetdiv.appendChild(moverdiv);

    $("#" + widgetname + "mover").css({
        'z-index': '100',
        'height': '50px',
        'top': '10px',
        'position': 'absolute',
        'background-color': 'transparent'
    });

    $("#" + widgetname + "mover").css("width", width);

    $("#" + widgetname).css({
        'z-index': '4',
        'position': 'absolute',
        'top': '100px',
        'padding-bottom': '40px',
        'left': '0px',
        'background-color': 'red'
    });
    $("#" + widgetname).addClass(' widget');

    isLocked = loadLocal('locked');
    if (isLocked !== null) {} else {
        $("#" + widgetname).touch();
    }
}


function getwidgetvalues(wkey, valueiw) {
    var wname, wwidth, wheight;
    valueiw = valueiw.split(',');
    wname = valueiw[0];
    wwidth = valueiw[1];
    wheight = valueiw[2];
    loadiwidgets(wname, wwidth, wheight);
}

function deletewidget() {
    var wcurel, savedwwidget, newsaves, objiwidget;
    wcurel = loadLocal('curel');
    $('#' + wcurel).remove();
    savedwwidget = loadLocal('objiwidgets');
    if (savedwwidget !== null) {
        objiwidget = {};
        objiwidget = JSON.parse(savedwwidget);
    }
    delete objiwidget[wcurel];
    newsaves = JSON.stringify(objiwidget);
    saveLocal('objiwidgets', newsaves);
    closehelper();
}

//////////////////////////

//Drag Elements
function dragobj(name, myTransform) {
    var dragmatrix, dragvalues, draga, dragb, dragangle, dragOBJ, myDragObject, dragsavedobj;
    dragmatrix = $('#' + name).css('-webkit-transform');
    if (dragmatrix !== "none") {
        dragvalues = dragmatrix.split('(')[1].split(')')[0].split(',');
        draga = dragvalues[0];
        dragb = dragvalues[1];
        dragangle = Math.round(Math.atan2(dragb, draga) * (180 / Math.PI));
        saveLocal(name + 'defaultrotation', dragangle);
    }
    dragOBJ = {};
    dragsavedobj = loadLocal('dragOBJ');
    if (dragsavedobj !== null) {
        dragOBJ = JSON.parse(dragsavedobj);
    }
    dragOBJ[name] = [myTransform];
    myDragObject = JSON.stringify(dragOBJ);
    saveLocal('dragOBJ', myDragObject);
}



function taphold(elemt) {
    var dblelement, tapwidgetornot, curelt, tapiconsornot, tstyle, tmatrix, tp, helperDiv;
    dblelement = elemt;
    helperDiv = getEL('helper');

    if (hazClass(getEL(elemt),'createditem')) {
        getEL('delete').style.display = 'block';
    } else {
        getEL('delete').style.display = 'none';
    }
     if (hazClass(getEL(elemt),'widget')) {
        getEL('delete2').style.display = 'block';
    } else {
        getEL('delete2').style.display = 'none';
    }

    if (elemt === "icon") {
        getEL('changeweatherico').style.display = 'block';
    } else {
        getEL('changeweatherico').style.display = 'none';
    }
    if(elemt == "dpad"){

    }

    else if (elemt === "iconlist") { //close list for icon select
        getEL(elemt).style.display='none';
        window.location = window.location.href;
    } 
     else if (elemt === "iwidget") { 
        $('.iwidget').css('display', 'none');
        unblurbackground();
    }
    else if (elemt === "overlays") {
        $('.overlays').css('display', 'none');
        unblurbackground();
    }
    else if (elemt === "filemenus"||elemt === "filemenus2"||elemt === "filemenus3"||elemt === "filemenus4") {
        getEL(elemt).style.display = 'none';
        unblurbackground();
    }
    else if (elemt === "fontmenuone") {
        fontpage('close');
        $('#fontmenuone').empty();
    }
    else if (elemt === "lockscreens") { //GL
        [].forEach.call( document.querySelectorAll('.lockscreen'), function(elmt) {
            elmt.style.display = 'none';
        });
        unblurbackground();
    } else if (elemt === "weathericonsmenu") {
        getEL(elemt).style.display = 'none';
        unblurbackground();
        $('#weathericonsmenu').empty();
    } else if (elemt === "loadthemes") {
        window.location = window.location.href;

    }else if (elemt === "animations") {
        getEL(elemt).style.display = 'none';
        unblurbackground();
        $("#animations").empty();
        $(".animations").empty();

    } else {
        curelt = localStorage.getItem('curel');
        localStorage.setItem('curicon',curelt);
        if (hazClass(getEL(curelt),'iconcan')) {
            $('.closer').css('display', 'block');
            getEL('changeico').style.display = 'block';
        }
        else{}
        saveLocal('helperel', dblelement);
        //tstyle = window.getComputedStyle(getEL(dblelement));
        //tmatrix = new WebKitCSSMatrix(tstyle.webkitTransform);
        //helperDiv.style.top = tmatrix.f - 30 + "px"
     
        //if (hazClass(curelt,'widget')) {
          //  helperDiv.style.top = tmatrix.f - 80 + "px"
        //}
        //tp = helperDiv.style.top;
        //tp = tp.slice(0, -2);
        //if (tp <= 60) {
          //  helperDiv.style.top = '30px';
        //}
        //if (hazClass(getEL(curelt),'iconcan')) {
           //helperDiv.style.top = '150px';
        //}
        helperDiv.style.top = '0px';
         helperDiv.style.opacity = '1';
         helperDiv.style.display="block";
     dragging = true;
     }
}

//Start if Item is held for 1000 ms show helper
var myVar;
function starttimer(id) {
    myVar = setTimeout(function () {
        taphold(id);
    }, 1000);

}

function endtimer() {
    clearTimeout(myVar);
}

//load lockscreen on top of wallpaper

function openlock(lockscreen){
  //  localStorage.removeItem("userbg");
  $('#movelocksmenu').css('display','none');
    saveLocal('lockscreenchosen', lockscreen);
    setTimeout(function(){ window.location = window.location.href; }, 300);
}

var ls = loadLocal("lockscreenchosen");
if (ls != "null") {
  if(ls!=null){
    var container=getEL('iwidgetcontainer');
    $("<div></div>").attr("id", "lockscreen").appendTo(container);
    $("<div></div>").attr("id", "locksa").appendTo(container);
    $("#lockscreen").css("position", "absolute");
    $("#lockscreen").css("width", "320px");
    $("#lockscreen").css("height", "160px");
    $("#lockscreen").css("left", "0px");
    $("#lockscreen").css("top", "410px");
    $("#lockscreen").css("background-color", "transparent");
    $("#lockscreen").css("z-index", "4");
    $("#locksa").css("z-index", "3");
    $("#locksa").css("position", "absolute");
    $("#locksa").css("background-color", "transparent");
    $("#locksa").css("width", "320px");
    $("#locksa").css("top", "0px");
    $("#locksa").css("left", "0px");
    loadlock(ls)
}
}

function loadlock(ls) {
    var iframea, iframea2, gld;
    iframea = document.createElement("iframe");
    iframea.id = "lockscreen";
    iframea2 = document.createElement("lockscreen");
    iframea2.frameBorder = "0";
    iframea.src = "file:///var/mobile/Library/GroovyLock/" + ls + "/LockBackground.html";
    iframea.style.backgroundColor = "transparent";
    iframea.frameBorder = "0";
    iframea.allowTransparency = "true";
    gld = getEL("locksa");
    gld.frameBorder = "0";
    gld.appendChild(iframea);
    iframea = null;
    gld = null;
}

//lock elements and set elements to be touch/draggable
function lock() {
    var isLocked;
    isLocked = loadLocal('locked');
    if (isLocked !== null) {
        localStorage.removeItem('locked');
        $('#body').addClass('scaleup');
        setTimeout(function () {
            window.location = window.location.href;
        }, 100);
    } else {
        saveLocal('locked', 'yes');
        $('#body').addClass('scale');
        setTimeout(function () {
            window.location = window.location.href;
        }, 100);

    }
}

function openanimations(name){
    saveLocal('animations', name);
    setTimeout(function(){ window.location = window.location.href; }, 300);
}

var animat = loadLocal("animations");
if (animat != "null") {
  if(animat!=null){
    var container=getEL('animationcontainer');
    $("<div></div>").attr("id", "anisc").appendTo(container);
    $("#anisc").css("z-index", "1");
    $("#anisc").css("position", "absolute");
    $("#anisc").css("background-color", "transparent");
    $("#anisc").css("width", "320px");
    $("#anisc").css("top", "0px");
    $("#anisc").css("left", "0px");
     $("#anisc").css("pointer-events", "none");
    loadanimation(animat);
}
}

function stopanimations(){
    localStorage.removeItem('animations');
    localStorage.removeItem('hiddenbg');
    getEL('background').style.visibility="visible";
    setTimeout(function(){ window.location = window.location.href; }, 500);

}

function loadanimation(ani) {
    var iframea, iframea2, gld;
    iframea = document.createElement("iframe");
    iframea.id = "lockscreen";
    iframea.src = "file:///var/mobile/Library/LBEvoAnimations/" + ani + "/index.html";
    iframea.style.backgroundColor = "transparent";
    iframea.frameBorder = "0";
    iframea.allowTransparency = "true";
    gld = getEL("anisc");
    gld.frameBorder = "0";
    gld.appendChild(iframea);
    iframea = null;
    gld = null;
}




var isLocked, weathers;
isLocked = loadLocal('locked');
if (isLocked !== null) {
    getEL('lscreen').innerHTML = "Unlock";
    var unlockdiv=getEL('unlock');
    unlockdiv.setAttribute('onclick','unlockphone()');
    $('#weatherelements div').css('pointer-events','none');
   // getEL('weatherelements').style.pointerEvents = "none";
} else {
    getEL('lscreen').innerHTML = "Lock";
    weathers = $('#city,#state,#statenm,#country,#desc1,#desc2,#desc3,#desc4,#desc5,#elevation,#lat,#long,#rainfall,#tdesc,#visible,#warning,#temp,#feeltemp,#condition,#later,#time,#day,#comma,#date,#year,#uv,#raininfo,#dew,#sunrise,#sunset,#icon,#battery,#forecast,#sms,#mail,#phone,#pm,#ttext,#htext,#mtext,#humidity,#month,#hi,#low,#slash,#slash2,#windsp,#windir,#speak,#unlock,#name,#dsize,#dfree,#tempFC,#min,#max,#hour,#minute,#colon,#nhood,#street,#addr,#county,#DMD,#MD,#DM,#twitter,#tweetbot,#whatapp,#events,#smonth,#latext,#longext,#sday,#L,#H,#L2,#H2,#msize,#CPU,#firm,#uptime,#zhour,#Dlocked,#rude,#fcast1,#fcast2,#fcast3,#fcast4,#day1icon,#day2icon,#day3icon,#day4icon,#day1hi,#day1lo,#day2hi,#day2lo,#day3hi,#day3lo,#day4hi,#day4lo,#day1des,#day2des,#day3des,#day4des,#tdate,#animations,#lockscreens,#fontmenuone,#overlays,#iwidget,#iconlist,#DSM,#ztime').touch();
}

$('#movelocksmenu,#moveicondir,#iwidgetscrollbar,#themes').touch();

//clear entire screen
function clearls() {
    var answer = confirm("Clear all Stored info? Press cancel to choose between clearing LockScreen or Springboard.")
    if (answer){
        localStorage.clear();
        window.location = window.location.href;
    }
    else{
        var secondanswer = confirm('Press ok to clear Lockscreen, press cancel to clear Springboard. If your theme isnt saved it will be lost');
    }
    if(secondanswer){
        var lsarray = ["access","locked","animations","hiddenbg","movemenudefaultrotation","loadthemesdefaultrotation","newsave","curel","opacityOB","daydefaultrotation","fontOBJ","randomsave","iconOBJ","hideOBJ","userbg","themesdefaultrotation","alignOB","dragOBJ","createdobjcreate","overlay","shadowOBJ","iwidgetscrollbardefaultrotation","datedefaultrotation","colorOBJ","scaleOBJ","iconimgOBJ","newsave","objiwidgets","newiconimgOBJ","iconset","lockscreenchosen","helperel","capsOBJ"];
        var lsarrayLength = lsarray.length;
        for (var ew = 0; ew < lsarrayLength; ew+=1) {
              localStorage.removeItem(lsarray[ew]);
        }
        for (var key in localStorage){
          var rotationkey=key.slice(-15);
          if(rotationkey=="defaultrotation"){
            localStorage.removeItem(key);
          }
        }
             //for (var key in localStorage){
                //alert(key);
            //}
        window.location = window.location.href;
    }
    else{
        var sbarray = ["newiconimgOBJSB","opacityOBSB","fontOBJSB","userbgSB","objiwidgetsSB","alignOBSB","dragOBJSB","widgetSB","overlaySB","lockscreenchosenSB","iconOBJSB","iconimgOBJSB","iconsetSB","scaleOBJSB","createdobjcreateSB","colorOBJSB","shadowOBJSB","hideOBJSB","iconsetSB"];
        var sbarrayLength = sbarray.length;
        for (var i = 0; i < sbarrayLength; i++) {
            localStorage.removeItem(sbarray[i]); 
        }
        reloadSB();
    }
}


function reloadSB(){
    randomsave=Math.floor(Math.random()*101);
    saveLocal('randomsave',randomsave);
    window.location = window.location.href;
}


function speakomightyone(foo) {
    window.speechSynthesis.speak(foo);
}

var speaker = 0;
function speaknow() {
    var pitchRange, rateRange, volRange, langRadio, foo, sptxt, extended, valuesp;
    speaker += 1;
    if (speaker === 2) {
        window.speechSynthesis.cancel();
        speaker = 0;
    }
    if (speaker === 1) {
        pitchRange = getEL('pitch');
        rateRange = getEL('rate');
        volRange = getEL('volume');
        if (json.StandardObservation.text.value === undefined) {
            extended = json.HiradObservation.text;
        } else {
            extended = json.StandardObservation.text;
        }
        valuesp = "Hello, It is currently " + json.StandardObservation.temp + "degrees" + "in" + json.Location.city + "       " + "Conditions are  " + extended;
        $('input[name=textco]').val('' + valuesp);
        langRadio = document.querySelector('input[type=radio]:checked');
        sptxt = getEL('sayit').value;
        foo = new SpeechSynthesisUtterance(sptxt);
        foo.lang = langRadio.value;
        foo.pitch = pitchRange.value;
        foo.rate = rateRange.value;
        foo.volume = volRange.value;
        speakomightyone(foo);
    }
}


function openweathericon() {
    blurbackground();
    $('#weathericonsmenu').touch();
    $('#weathericonsmenu').css('display', 'block');
    var weathericonarray=["lines", "shadow", "deep", "nude","simply","playful","realicons","reddock", "clima","swhite", "GlowWhite","MNMLBW","MNMLB","Sk37ch","primusweather","plastic","mw","stardock","june","round","simple","#1d1d1d","weathercom","toon","toon2","yahoo","round2","topaz","blue","smash","#1d1d1dy","mauri","mauri2","shiny","#1d1d1dOrange","six","sixtynine","Flex","wetter"];

    for (i = 0; i < weathericonarray.length; i++) { 
      $("#weathericonsmenu").append('<div id='+weathericonarray[i]+' onclick="seticonss(\''+weathericonarray[i]+'\')"><img src="images/weather/'+weathericonarray[i]+'.png"width="40"></div>  ');
    }
    closehelper();

}

function seticonss(eicons) {
    $('#weathericonsmenu').css('display', 'none');
    unblurbackground();
    $('#weathericonsmenu').empty();
    saveLocal("iconset", eicons);
    Showdata();
}

function killls() {
    localStorage.removeItem('lockscreenchosen');
    $('#body').addClass('downout');
    setTimeout(function () {
        window.location.reload();
    }, 500);
}



function closeoverlay() {
    localStorage.removeItem('overlay');
    $('#overlay').css('display', 'none');
}

function showwidgetmenu() {
    $('#premenu').css('display', 'none');
    $('#widgetmenu').css('display', 'block');
}

function startani() {
    var widgetan;
    $('#widgetmenu').css('display', 'none');
    $('#background,#weather,.icons,#locksa').css('left', '0px');
    widgetan = loadLocal('widget');
    if (widgetan !== null) {
        localStorage.removeItem('widget');
        setTimeout(function () {
            window.location.reload()
        }, 10);
    } else {
        widgetan = "animated";
        saveLocal('widget', widgetan);
        setTimeout(function () {
            window.location.reload()
        }, 10);
    }
}
//////////////////

function openfonts() {
    var fm;
    fm = $("#fontmenuone").css("display");
    if (fm === "none") {
        $("#fontmenuone").css("display", "block");
    } else {
        $("#fontmenuone").css("display", "none");
    }
    closehelper();
    var fontarray=["-apple-system-font","AcademyEngraved","Chalkduster","CourierNews","LCD","Deep","Bebas","Signa","Karn","DigitalLCD","Ozone","Urban","WildPrint","PeachCream","Tragic","Cubos","Doodle","Trench","Seriously","Comic","Dripping","XtreemThick","XtreemThin","Nero", "HeitiLight","HeitiThin","HelveticaNeue","PartyLet","Snell","Noteworthy","Chalkboard","BradleyHand","Geosans","OStrich","Roboto","Steelfish","BootsF","BootsS","Codystar","Give You Glory","Poiret One","Tulpen One","Metrophobic","Bubbler One","Orbitron","Voltaire","Dosis","Righteous","Permanent Marker","Londrina Shadow","Nothing You Could Do","Nosifer","Shojumaru","Swanky and Moo Moo","Trade Winds","Keania One","Pompiere","Josefin Slab","Sniglet","Pathway Gothic One","Raleway","Jockey One","Amatic SC","Marcellus SC","Syncopate","Questrial","Frijole","Atomic Age","Montserrat Alternates","Crushed","Annie Use Your Telescope","Bigelow Rules","Monoton","Fascinate","Indie Flower","Gloria Hallelujah","Comfortaa","anton","hammersmith","changa","megrim","meta","game","bowlby","rdots","joti","rubik","neuropol","bgothic","close"];

    for (i = 0; i < fontarray.length; i++) {  
            getEL('fontmenuone').innerHTML= getEL('fontmenuone').innerHTML+'<li onclick="appendfont(\''+fontarray[i]+'\')" style="font-family:'+fontarray[i]+';">'+fontarray[i]+'</li>';
    }


}

function fontobj(fontname, fontvalue) {
    var fontmainobj, fontsavedobj, fontprsdobj, fontstringobj;
    fontmainobj = {};
    fontsavedobj = loadLocal("fontOBJ");
    if (fontsavedobj !== null) {
        fontprsdobj = JSON.parse(fontsavedobj);
        fontmainobj = fontprsdobj;
    }
    fontmainobj[fontname] = [fontvalue];
    fontstringobj = JSON.stringify(fontmainobj);
    saveLocal("fontOBJ", fontstringobj);
}

function loadfont(fvalue) {
    var curfontel;
    curfontel = loadLocal("helperel");
    $("#" + curfontel).css("font-family", fvalue);
    fontobj(curfontel, fvalue);
}

function applyfonts() {
    var namefont;
    namefont = $("#font").val();
    if (namefont !== "Font") {
        loadfont(namefont);
    }
}

function appendfont(appendft) {
    if(appendft==="close"){
        fontpage("close");
    }
    else{
    $("#font").val(appendft);
    loadfont(appendft);
    }
}

function fontpage(closeval) {
    if (closeval === "close") {
        $("#fontmenuone").css("display", "none");
        $("#fontmenuone").empty();

    }
}




/////////////////////////
function createli(app,bundle,icon,appkind){
  //manual fixes
       if (bundle == "com.google.ios.youtube") {
                app = "YouTube";
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/YouTube.app/Icon-72.png"
            }
            if (bundle == "com.directed.viper") {
                app = "Viper";
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Viper SmartStart.app/Icon@2x.png"
            }
            if (bundle == "com.apple.iBooks") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/iBooks.app/80.png"
            }
            if (bundle == "net.swiftkey.swiftever") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/SwiftKeyNote.app/SK_icon_100px.png"
            }
            if (bundle == "com.checkpoints.v1") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/CheckPoints.app/icon@2x.png"
            }
            if (bundle == "com.tang.ivideofree") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/PerfectVideoLite.app/Icon72.png"
            }
            if (bundle == "com.photobucket.iphone") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/photobucket.app/icon-iphone@2x.png"
            }
            if (bundle == "com.plusblog.smpro") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/smpro.app/appicon-120.png"
            }
            if (bundle == "com.mojang.minecraftpe") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/minecraftpe.app/Icon-120.png"
            }
            if (bundle == "com.google.hangouts") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Hangouts.app/Icon-120.png"
            }
            if (bundle == "com.skype.skype") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Skype.app/ApplicationIcon_120x120.png"
            }
            if (bundle == "com.tang.ivideofree") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Perfect Video Lite.app/Icon-72.png"
            }
            if (bundle == "com.toyopagroup.picaboo") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Snapchat.app/Icon-120.png"
            }
            if (bundle == "com.google.GooglePlus") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/EmSea.app/icon-76.png"
            }
            if (bundle == "com.discoverfinancial.mobile") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/DiscoverMobile.app/120x120.png"
            }
            if (bundle == "com.att.osd.myWireless") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/myATTThin.app/AppIcon60x60@2x.png"
            }
            if (bundle == "com.microsoft.skydrive") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/OneDrive.app/Icon-60@2x.png"
            }
            if (bundle == "com.lexwarelabs.goodmorning") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/GoodMorning.app/icon_120.png"
            }
            if (bundle == "com.cvs.cvspharmacy") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/CVS.app/Icon-120.png"
            }
            if (bundle == "com.getdropbox.Dropbox") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Dropbox.app/iphone@2x-120.png"
            }
            if (bundle == "com.wunderground.weather") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Weather Underground.app/icon_120.png"
            }
            if (bundle == "com.ideashower.ReadItLaterPro") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/ReadItLaterPro.app/120_iphone_ios7.png"
            }
            if (bundle == "com.apple.weirdo") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Keeper.app/icon_120.png"
            }
            if (bundle == "com.apple.chase") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Chase.app/app_icon_iphone_chase_120x120.png"
            }
            if (bundle == "com.ifttt.ifttt") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/IFTTT.app/logo@2x.png"
            }
            if (bundle == "com.adaptiveblue.GlueMobile") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/tvtage.app/AppIcon120x120.png"
            }
            if (bundle == "com.apple.podcasts") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Podcasts.app/Podcasts120.png"
            }
            if (bundle == "com.apple.remote") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Remote.app/Remote120.png"
            }
            if (bundle == "com.mileskabal.appinfo") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/appinfo.app/Icon@2x.png"
            }
            if (bundle == "org.herf.iflux") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/iflux.app/Icon@2x.png"
            }
            if (bundle == "com.ouraigua.safaridownloaderplus") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/SafariDownloader.app/AppIcon60x60.png"
            }
            if (bundle == "com.pragmatixconsulting.packagebackup") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/PkgBackup.app/AppIcon60x60@2x.png"
            }
            if (bundle == "com.itaysoft.icaughtuproapp") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/iCaughtUPro.app/Icon-60@2x.png"
            }
            if (bundle == "com.getdropbox.Dropbox") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Dropbox.app/icon-60@2x.png"
            }
            if (bundle == "com.vbmc.amc") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/AMCTheatres.app/Icon@2x.png"
            }
            if (bundle == "com.jeffreygrossman.moviesapp") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Flixster.app/Icon@2x.png"
            }
            if (bundle == "com.netgear.GenieiPhoneiPod") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/GenieiPhoneiPod.app/Icon@2x.png"
            }
            if (bundle == "com.piehome.piehomev2") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/NetHero.app/Icon-120.png"
            }
            if (bundle == "com.apple.Remote") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Remote.app/Remote120.png"
            }
            if (bundle == "com.udemy") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/udemy-mobile-ios.app/app_icon_120.png"
            }
            if (bundle == "com.walmart.electronics") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/Walmart.app/Icon-120.png"
            }
            if (bundle == "com.yahoo.weather") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/com.yahoo.weather-34126-distribution.app/yweather_120.png";
            }
            if (bundle == "com.xcj.blur") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/blur.app/icon_120.png"
            }

            if (bundle == "com.digitalruby.youdoodle") {
                icon = JSON.stringify(icon).split('/');
                icon = "/private/var/mobile/Applications/" + icon[5] + "/YouDoodle.app/YouDoodleIcon-120.png"
            }

  if(icon!="null"){
    iconsp=icon.slice(-4);    
  if(iconsp!=".png"){
    icon=icon+"@2x.png";
  }

var imageUrl = icon;
imageExists(imageUrl, function(exists) {
  if(exists==false){
    iconsp3=icon.slice(-7);
    if(iconsp3=="@2x.png"){firstcut=icon.slice(0, -7);icon=firstcut+".png";}
    iconsp2=icon.slice(-4);
    if(iconsp2==".png"){secondcut=icon.slice(0, -4);icon=secondcut+"@2x.png";}
    checkagain(app,bundle,icon,appkind);
  }
  if(exists==true){
    checkagain(app,bundle,icon,appkind);
  }
  closemenupressed();
});

function checkagain(app,bundle,icon,kind){
  var imageUrl = icon;
  imageExists(imageUrl, function(exists) {
      if(exists==false){
        var str = icon;
        var splitted = str.split("/");
        var first = "";
        for (var i=0; i<splitted.length-1; i++) {
            first += splitted[i] + "/";
        }

        var second = "";
        if (splitted.length > 0) {
            second = splitted[splitted.length-1];
        }

        icon=first+"icon@2x~iphone.png"; //Used to fix icons that dont theme correctly alert icon to see the bundle then
        //just name the icon correctly

        
        if(icon=="/Applications/FaceTime.app/icon@2x~iphone.png"){
          icon="/Applications/FaceTime.app/Icon-FaceTime@2x~iphone.png";
        }
        if(icon=="/Applications/BytaFont2.app/icon@2x~iphone.png"){
          icon="/Applications/BytaFont2.app/120x120.png";
        }
        if(icon=="/Applications/kcleanmaster.app/icon@2x~iphone.png"){
          icon="/Applications/kcleanmaster.app/icon@2x.png";
        }

loadli(app,bundle,icon,kind);
}
  else{
    if(app=="MailCompositionService"||icon=="null"||app=="Social"||app=="mobilephone"||app=="CompassCalibrationViewService"||app=="ios"||app=="quicklook"||app=="QuickLook"||app=="iad"||app=="MusicUIService"||app=="WebContentFilter"||app=="Mobilesms"||app=="Mobileslideshow"||app=="purplebuddy"||app=="AccountAuthenticationDialog"||app=="AdSheetPhone"||app=="uikit"||app=="fieldtest"||app=="iosdiagnostics"||app=="FacebookAccountMigrationDialog"||app=="appleaccount"||app=="WebSheet"||app=="TrustMe"||app=="datadetectors"||app=="PassbookUIService"||app=="undefined"||app=="Undefined"||app=="gamecenter"||app=="Copilot"||app=="SiriViewService"||app=="DemoApp"||app=="WebViewService"){}
    else{
      loadli(app,bundle,icon,kind);
      }

   



    }
});
}
}
}

function imageExists(url, callback) { //function to check if images exists works 90% which is amazing.
  var img = new Image();
  img.onload = function() { callback(true); };
  img.onerror = function() { callback(false); };
  img.src = url;
}

function loadli(app,bundle,icon,appkind){
if(appkind=="system"){
saveLocal('system',appkind);
localStorage.removeItem('user');
$('.user').remove();
}
if(appkind=="user"){
  localStorage.removeItem('system');
  saveLocal('user',appkind);
  $('.system').remove();
}
 
$('#iconlist').css('display','inline-block');
  blurbackground();
  
  if(app=="MailCompositionService"||icon=="null"||app=="Social"||app=="mobilephone"||app=="CompassCalibrationViewService"||app=="ios"||app=="quicklook"||app=="QuickLook"||app=="iad"||app=="MusicUIService"||app=="WebContentFilter"||app=="Mobilesms"||app=="Mobileslideshow"||app=="purplebuddy"||app=="AccountAuthenticationDialog"||app=="AdSheetPhone"||app=="uikit"||app=="fieldtest"||app=="iosdiagnostics"||app=="FacebookAccountMigrationDialog"||app=="appleaccount"||app=="WebSheet"||app=="TrustMe"||app=="datadetectors"||app=="PassbookUIService"||app=="undefined"||app=="Undefined"||app=="gamecenter"||app=="Copilot"||app=="SiriViewService"||app=="DemoApp"||app=="WebViewService"){}
    else{

      if(bundle=="com.saurik.WinterBoard"){
        icon="/Applications/WinterBoard.app/icon7@2x~ipad.png";}
        if(bundle=="com.apple.Music"){
        icon="/Applications/Music.app/Icon-120.png";}
        if(bundle=="com.apple.MobileStore"){
        icon="/Applications/MobileStore.app/iTunesStore120.png";}
        if(bundle=="com.apple.AppStore"){
        icon="/Applications/AppStore.app/Appstore120.png";}
        if(bundle=="com.saurik.Cydia"){
        icon="/Applications/Cydia.app/Icon-76~ipad.png";}
        if(bundle=="com.apple.videos"){
        icon="/Applications/Videos.app/Videos60@2x~iphone.png";}
        if(bundle=="eu.heinelt.ifile"){
        icon="/Applications/iFile.app/AppIcon76x76@2x.png";}
          if(bundle=="com.apple.mobilecal"){
          icon="/Applications/MobileCal.app/icon-about@2x.png";}
          if(bundle=="org.herf.iflux"){
        icon="/Applications/iflux.app/Icon@2x.png";}
        if(bundle=="com.harrisonapps.Pandora-Downloader"){
        icon="/Applications/Pandora Downloader.app/Icon@2x.png";}
        if(bundle=="com.pragmatixconsulting.packagebackup"){
        icon="/Applications/PKGBackup.app/AppIcon60x60@2x.png";}

        


          
imageExists(icon, function(exists) { // if image doesn't exist apple no image icon.
    if (exists == false) {
        icon = "/System/Library/LockCydgets/LockBuilderEvo.cydget/libraries/img/icon.png";
        var classname = "pickicons";
        d = document.createElement('div');
        $(d).addClass(classname).html('</br><img class="' + appkind + '" id="' + app + 'img" style="margin-left:15px;border-radius: 5px;" width="60" height="60" src="' + icon + '" /></br>').appendTo($('#iconlist')) //main div
            .click(function() {
                setapp(bundle, icon);
                $('#' + app + 'img').css('opacity', '0.5');
                //unblurbackground();

            });
    } else {
        var classname = "pickicons";
        d = document.createElement('div');
        $(d).addClass(classname).html('</br><img class="' + appkind + '" id="' + app + 'img" style="margin-left:15px;border-radius: 5px;" width="60" height="60" src="' + icon + '" /></br>').appendTo($('#iconlist')) //main div
            .click(function() {
                setapp(bundle, icon);
                $('#' + app + 'img').css('opacity', '0.5');
                //unblurbackground();
            });

    }
});      

        






   /* a = document.createElement("a");
    a.href = "#";
    var element = document.createElement("img");
    element.setAttribute("src", icon);
    a.appendChild(element);
    a.setAttribute("id", app+"img");
    a.setAttribute('onclick', 'setapp('+bundle+');');
    a.appendChild(document.createTextNode(app));
    li = document.createElement("li");
    li.appendChild(a);
    li.setAttribute('ontouchend', 'setapp("'+bundle+'");');
    ul = getEL("iconlist");
    ul.insertBefore(li, getEL("iconclose"));
    */
  }

  }

function closeicons(){ //close icon list when press hold on scroller
  $('#iconlist').css('display','none');
  $('#scrollbar').css('display','none');
  unblurbackground();

}



function setapp(bundle,iconimg){
  $('#background').css('left','0px');
                $('#newitems').css('left','0px');
                $('#iwidgetcontainer').css('left','0px');
                $('#weatherelements').css('left','0px');
                $('#locksa').css('left','0px');
                $('.icons').css('left','0px');
                $('#premenu').css('display','none');
           
                $('#lsmenu').css('display','none');
                $('#iconmenu').css('display','none');
                $('#overlay').css('left','0px');

    //$('#iconlist').css('display','none');
    //unblurbackground();

    if (bundle == "libactivator") {
  bundle = "com.apple.activator"
    };
    if (bundle == "com.pandora") {
  bundle = "com.apple.pandora"
    };
    if (bundle == "com.in-notes") {
  bundle = "com.apple.innotes"
    };

    var idname=bundle.split('.');//split to get app name

    //imgsrc= $('#'+idname[2]+'img').children("img").attr("src");
    var imgsrc=iconimg;
//add custom icons images
    if(bundle=="com.apple.mobilephone"){
      imgsrc="/Applications/MobilePhone.app/icon@2x~iphone.png";
    }


    if(bundle=="com.saurik.WinterBoard"){
        imgsrc="/Applications/WinterBoard.app/icon7@2x~ipad.png";}
        if(bundle=="com.apple.Music"){
        imgsrc="/Applications/Music.app/Icon-120.png";}
        if(bundle=="com.apple.MobileStore"){
        imgsrc="/Applications/MobileStore.app/iTunesStore120.png";}
        if(bundle=="com.apple.AppStore"){
        imgsrc="/Applications/AppStore.app/Appstore120.png";}
        if(bundle=="com.saurik.Cydia"){
        imgsrc="/Applications/Cydia.app/Icon-76~ipad.png";}
        if(bundle=="com.apple.videos"){
        icon="/Applications/Videos.app/Videos60@2x~iphone.png";}
        if(bundle=="eu.heinelt.ifile"){
        icon="/Applications/iFile.app/AppIcon76x76@2x.png";}
        if(bundle=="org.herf.iflux"){
        icon="/Applications/iflux.app/Icon@2x.png";}
        if(bundle=="com.harrisonapps.Pandora-Downloader"){
        icon="/Applications/Pandora Downloader.app/Icon@2x.png";}
        if(bundle=="com.pragmatixconsulting.packagebackup"){
        icon="/Applications/PKGBackup.app/AppIcon60x60@2x.png";}
    
    if(idname[2]=="Telegraph"){
      idname[2]="Telegram";
    }
    if(idname[2]==undefined){
      idname[2]="whoknows";
    }

    if ($('#'+idname[2]).length > 0) {
      $('#'+idname[2]).remove(); //remove from html
      deleteFromObject(idname[2],iconOBJ); //remove from object
    }
      else{


imageExists(icon, function(exists) {
  if(exists==false){
    icon="/System/Library/LockCydgets/LockBuilderEvo.cydget/libraries/img/icon.png";
  }
  if(exists==true){
    icon=icon;
  }
});

    var openbundle="'"+bundle+"'";
    linkFuncts = "closethisapp('" + idname[2] + "')";
   $(".icons").append('<div class="iconcan" id='+idname[2]+'></div>');
   $('#'+idname[2]).append('<center><div class="iconcan" id="b'+idname[2]+'"><img width="60" id="icon'+idname[2]+'" ontouchend="openapp('+openbundle+')"  class="iconimages" src="' + imgsrc + '"></div></center><span id="closer' + idname[2] + '" class="closer">X</span>');
   closer=getEL("closer" + idname[2]);
    closer.setAttribute('onTouchEnd', linkFuncts);

isLocked=loadLocal('locked');
if(isLocked!=null){}
else{
 $('#'+idname[2]).touch();
}


iconname=idname[2];
iconobj(iconname,openbundle);
iconimgobj(iconname,imgsrc);
}
}



/////////////////////////
//controls
function closehelper() {
    $('#helper').css('top', '-300px');
    $('#helper').css('opacity', '0');
    $('#helper').css('display', 'none');
    $('#changeweatherico,#changeico,#colorpick').css('display', 'none');
    $('.closer').css('display', 'none');
}

function opencolor() {
    var linktocolor, colorpickerframe;
    $('#colorpick').css('display', 'block');
     $('#colorpick').load('libraries/color/cp.html');
}

function changeval(which, color) {
    var curdiv, currentval, creatitems;
    if (which === "color") {
        curdiv = loadLocal('helperel');
        currentval = color;
        $('#colorpick').css('display', 'none');
        if (curdiv === "line" || curdiv === "thickline" || curdiv === "mediumline") {
            $('#' + curdiv).css('background-color', currentval);
            colorobj(curdiv, currentval);
        }
        creatitems = $("#" + curdiv).hasClass("createditem");
        if (creatitems === true) {
            $('#' + curdiv).css('background-color', currentval);
            colorobj(curdiv, currentval);
        } else {
            $('#' + curdiv).css('color', currentval);
            colorobj(curdiv, currentval);
        }
        $('#' + which).val(currentval);

    } else {
        currentval = prompt('Enter value', '');
        $('#' + which).val(currentval);
        if (which === "angle") {
            $('#rotate').click();
        } else {
            $('#scale').click();
        }
    }

}



$('#rotate').click(function () {
    var crtdiv, art, trt, crt, nrt, cssrt, divsrt, matrixrt, typert, nameofrt;
    crtdiv = loadLocal('helperel');
        art = +$('#angle')[0].value + ".001",
        trt = _T.rotate(art),
        crt = _T.fromString($('#' + crtdiv).css('transform')),
        nrt = crt.x(trt),
        cssrt = _T.toString(nrt);

    $('#' + crtdiv).css({
        transform: cssrt
    });
    divsrt = $('#' + crtdiv);
    matrixrt = $('#' + crtdiv).css('-webkit-transform');
    typert = "touch";
    nameofrt = crtdiv;
    dragobj(nameofrt, matrixrt);

});

$('#scale').click(function () {
    var csdiv, scle, iconsornot, widgetornot;
    csdiv = loadLocal('helperel');
    scle = $('#size')[0].value;

    if (csdiv === "line" || csdiv === "thickline" || csdiv === "mediumline") {
        $('#' + csdiv).css('height', scle + "px");
    }
    if (csdiv === "icon") {
        $('#' + csdiv + 'img').css('width', scle + "px");
    } else {
        $('#' + csdiv).css('font-size', scle + "px");
    }
    if(csdiv==="day1icon"||csdiv==="day2icon"||csdiv==="day3icon"||csdiv==="day4icon"){
        $('#' + csdiv + 'i').css('width', scle + "px");
    }

    iconsornot = $("#" + csdiv).hasClass("iconcan"); //if icon move to 150
    if (iconsornot === true) {
        $('#icon' + csdiv).css('width', scle + 'px');
    }

    widgetornot = $("#" + csdiv).hasClass("widget");
    if (widgetornot === true) {
        if (scle >= 2) {
            alert("widgets can only be scaled from 0.0 to 1.9");
        } else {
            $('#' + csdiv).css({
                '-webkit-transform': 'scale(' + scle + ')'
            });
        }

    }
    scaleobj(csdiv, scle);
});


function opencontrols(){
    $('#dpad').load('libraries/control/control.html');
}

$('#reset').click(function () {
    opencontrols();
    closehelper();
    $('#dpad').css('display','block');
    $('#dpad').touch();
    //var cdiv = loadLocal('helperel');
    //$('#' + cdiv).css({
      //  transform: ''
    //});
    //localStorage.removeItem(cdiv + 'defaultrotation');
});






function closeshtml(){
    $('#shadowpicker').remove();
    $('#shadowpick').css('display','none');
    cdiv = loadLocal('helperel');
    shadow = loadLocal('fullblur');
    shadowobj(cdiv, shadow);

}

function changesdows(){
    colorvar = loadLocal('scolor');
    if(colorvar==null){
        colorvar="#1d1d1d";
        saveLocal('scolor','#1d1d1d');
    }
    cdiv = loadLocal('helperel');
    h=loadLocal("horizontal");
    v=loadLocal("vertical");
    b=loadLocal("blurs");
    if(h==null){h=0};
    if(v==null){v=0};
    if(b==null){b=0};
    h=h+"px";
    v=v+"px";
    b=b+"px";
    shadow1=loadLocal('shadow1');
    shadow2=loadLocal('shadow2');
    shadow3=loadLocal('shadow3');
    shadow4=loadLocal('shadow4');
    if(shadow1!=null&&shadow2==null){
        shadow=shadow1+","+h + " " + v + " " + b + " " + colorvar;
    }
    else if(shadow2!=null&&shadow3==null){
        shadow=shadow1+","+shadow2+","+h + " " + v + " " + b + " " + colorvar;
    }
    else if(shadow3!=null&&shadow4==null){
        shadow=shadow1+","+shadow2+","+shadow3+","+h + " " + v + " " + b + " " + colorvar;
    }
    else if(shadow4!=null){
        shadow=shadow1+","+shadow2+","+shadow3+","+shadow4+","+h + " " + v + " " + b + " " + colorvar;
    }
    else{
    shadow=h + " " + v + " " + b + " " + colorvar;
}
    saveLocal('fullblur',shadow);
    saveLocal('redoshadow',shadow);
    $('#' + cdiv).css('text-shadow', shadow);

}



function redoshadow(){
    cdiv1 = loadLocal('helperel');
     shadow1=loadLocal('redoshadow');
     $('#' + cdiv1).css('text-shadow', shadow1);

}

function opendropmenu() {
   var linktoframe, miframes;
    $('#shadowpick').css('display', 'block');
    $('#shadowpick').load('libraries/shadows/shadows.html');
    closehelper();
}

function scolor() {
    var scolors = prompt('Type color', '');
    saveLocal('scolor', scolors);
    $('#shadowcolor').css('color', scolors);
}

var smcolor = loadLocal('scolor');
if (smcolor !== null) {
    $('#shadowcolor').css('color', smcolor);
}







function closedropshadow() {
 
    $('#shadowcolor').css('display', 'none');
    
}


function changecaps(){

  var curdiv = loadLocal('helperel');
  var capvalue=$("#"+curdiv).css('text-transform');
  if(capvalue=="uppercase"){
    var change ="capitalize";
    $("#"+curdiv).css('text-transform',change);
    capsobj(curdiv,change);
  }
  else if (capvalue == 'none'){
  var change = "uppercase"; 
  $("#"+curdiv).css('text-transform',change);
  capsobj(curdiv,change);
  }
  else if(capvalue == 'capitalize'){
    var change = "uppercase"; 
  $("#"+curdiv).css('text-transform',change);
  capsobj(curdiv,change);
  }
  else{
     var change ="capitalize";
    $("#"+curdiv).css('text-transform',change);
    capsobj(curdiv,change);
  }
}



//caps Elements
function capsobj(name, myTransform) {
    capsOBJ = {};
    capssavedobj = loadLocal('capsOBJ');
    if (capssavedobj !== null) {
      if(capssavedobj=="undefined"){}
      else{capsOBJ = JSON.parse(capssavedobj);}
    }
    capsOBJ[name] = [myTransform];
    mycapsObject = JSON.stringify(capsOBJ);
    saveLocal('capsOBJ', mycapsObject);
}




//Opacity input
$(function () {
    var el, newPoint, newPlace, offset, width;
    $("input[type='range']").change(function () {
        el = $(this);
        width = el.width();
        newPoint = (el.val() - el.attr("min")) / (el.attr("max") - el.attr("min"));
        offset = 15;
        if (newPoint < 0) {
            newPlace = 0;
        } else if (newPoint > 1) {
            newPlace = width;
        } else {
            newPlace = width * newPoint + offset;
            offset -= newPoint;
        }
        el
            .next("output")
            .css({
                left: newPlace,
                marginLeft: offset + "%"
            })
            .text(el.val());
    });
});


var mainbg=loadLocal("userbg");
if(mainbg==null){
getBase64FromImageUrl("images/wallpaperinst.png");

}
function getBase64FromImageUrl(URL) {
    var img = new Image();
    img.src = URL;
    img.onload = function () {
    var canvas = document.createElement("canvas");
    canvas.width =this.width;
    canvas.height =this.height;
    var ctx = canvas.getContext("2d");
    ctx.drawImage(this, 0, 0);
    var dataURL = canvas.toDataURL("image/png");
    canvas=null;
    saveLocal('userbg',dataURL);
    if(URL=="images/wallpaperinst.png"){
      wall=loadLocal('userbg');
      cw=getEL("background");cw.style.backgroundImage="url("+wall+")";
  }

    }
}

function weatherwalls(){
 var issaved=loadLocal('weatherwalls');
  if(issaved =='yes'){localStorage.removeItem('weatherwalls');}
  else{saveLocal('weatherwalls','yes');}
  location.reload();
}



var weatherwallpapers=loadLocal('weatherwalls');
if(weatherwallpapers!=null){
  weatherwall="yes";
  getBase64FromImageUrl("images/wallpaper.jpg");
}



function opensite(){
    var ntim = new Date().getTime();
  closemenu();
  blurbackground();
  hidestatusbar();
  getEL('background').style.display="block";
  getEL('site').style.display = "block";
$('#site').load('http://junesiphone.com/LBEVO.html?cache='+ntim);
}

function hidebg(){getEL('background').style.visibility="hidden";}



localStorage.removeItem('system');
localStorage.removeItem('user');
function findicons(kind) {
    var systemsaved = loadLocal('system');
    var usersaved = loadLocal('user');
    var applist = getinstall();
    if (systemsaved == kind) {
        closemenu();
        getEL('Iconlist').style.display = "block";

    } else if (usersaved == kind) {
        closemenu();
        getEL('Iconlist').style.display = "block";

    } else {
        closemenu();
        var system = applist.System;
        var user = applist.User;
        if (kind == "user") {
            systembundle = getuser(user);
        } else {
            systembundle = getuser(system);
            last = getvalue(system,systembundle,51); //mail app
        }
        var allapps = systembundle;
        for (var i = 0; i < allapps.length; i++) {
            try {
                checkapps(i);
            } catch (err) {}
        }

        function checkapps(i) {
            if (kind == "user") {
                var kindofapp = "user";
                var appbundle = getvalue(user,systembundle,i);
                var apppath = appbundle.Path; //icon path
                if (appbundle.CFBundleIconFiles) {
                    appicon = appbundle.CFBundleIconFiles;
                } else {
                    if (appbundle.CFBundleIcons) {
                        appicon = appbundle.CFBundleIcons.CFBundlePrimaryIcon.CFBundleIconFiles;
                    } else {
                        appicon = "null";
                    }
                }
                if (appicon.value >= 2) {
                   if(appbundle.CFBundleIdentifier =="com.nbcuni.cnbc.cnbcrt"){ //fix
                     appicon=appbundle.CFBundleIcons.CFBundlePrimaryIcon.CFBundleIconFiles[0];
                     fullicon=appbundle.Container;
                    }
                    if (appicon[0] == undefined) {
                        fullicon = "null";
                    } else {
                        fullicon = apppath + "/" + appicon[0];
                    }
                } else {
                    fullicon = "null";
                    ///////////////////////Missing Apps Fix1//////////////////////////
                    if (appbundle.CFBundleIdentifier == "com.directed.viper") {
                        fullicon = apppath;
                    }
                }

            } else {
                var kindofapp = "system";
                var appbundle = getvalue(system,systembundle,i);
                var apppath = appbundle.Path; //icon path
                if (appbundle.CFBundleIconFiles) {
                    var appicon = appbundle.CFBundleIconFiles;
                } else {
                    if (appbundle.CFBundleIcons) {
                        var appicon = appbundle.CFBundleIcons.CFBundlePrimaryIcon.CFBundleIconFiles;
                    } else {
                        var appicon = "null";
                    }
                }

                if (appicon.value >= 2) {
                    if (appicon[0] == undefined) {
                        var fullicon = "null";
                    } else {
                        var fullicon = apppath + "/" + appicon[0];
                    }
                } else {
                    var fullicon = "null";
                }
            }

            var nam = allapps[i];
            // Some apps dont follow com.apple.bla fix them here.
            if (nam == "libactivator") {
                nam = "com.apple.activator"
            };
            if (nam == "com.pandora") {
                nam = "com.apple.pandora"
            };
            if (nam == "com.in-notes") {
                nam = "com.apple.innotes"
            };
            if (nam == "D4D2433BGC") {
                nam = "com.apple.weirdo"
            };
            if (nam == "com.chase") {
                nam = "com.apple.chase"
            };
            if (nam == "com.udemy") {
                nam = "com.apple.udemy"
            };
            if (nam == "com.directed.viper") {};

            if (nam == "com.nbcuni.cnbc.cnbcrt"){
                nam = "com.apple.cnbc";
                app = "CNBC";
                fullicon = JSON.stringify(fullicon).split('/');
                fullicon = "/private/var/mobile/Applications/" + fullicon[5] + "/CNBC.app/App_Icon_76x76@2x.png";
            }
            nam = nam.split('.');
            createli(nam[2], allapps[i], fullicon, kindofapp); //create list of apps
            //alert(nam[2]+allapps[i]+fullicon+kindofapp);
        }
    }

    if (kind == "user") {} else {
        var systemsaves = loadLocal('system');
        if (systemsaves == null) {
            createphoneapp();

            function createphoneapp() {
                var nn1 = "Phone";
                var na1 = "com.apple.mobilephone";
                var ni1 = "/Applications/MobilePhone.app/icon@2x~iphone.png";
                var nk1 = "system";
                createli(nn1, na1, ni1, nk1);
            }

        }
    }
}



function lastapp(){
  var lasticon=getlastapp();

  if(lasticon==null){
    alert("no last app:(");
  }
  lasticon=JSON.stringify(lasticon).split(">");
  lasticon=lasticon[1].replace(/"/g, "");
  lasticon=lasticon.replace(/ /g,'');
  openapp(lasticon);
}

function savetheme(){
    var themename=prompt('Name your theme','');
        themename=themename.replace(/\s+/g, '');
    var LBEvo = mutabledict();
      setobject(LBEvo,loadLocal('locked'),"ElementsLocked");
      setobject(LBEvo,loadLocal('weatherwalls'),"WeatherWallsave");
      setobject(LBEvo,loadLocal('animations'),"Animation");
      setobject(LBEvo,SMStxt,"Smssv");
      setobject(LBEvo,MAILtxt,"Mailsv");
      setobject(LBEvo,PHONEtxt,"Phonesv");
      setobject(LBEvo,TWITTERtxt,"Twittersv");
      setobject(LBEvo,TWEETBOTtxt,"Tweetbotsv");
      setobject(LBEvo,WHATSAPPtxt,"Whatsappsv");
      setobject(LBEvo,loadLocal('capsOBJ'),"ElementCaps");
      setobject(LBEvo,loadLocal('dragOBJ'),"MainElements");
      setobject(LBEvo,loadLocal('hideOBJ'),"HideElements");
      setobject(LBEvo,loadLocal('iconimgOBJ'),"IconImages");
      setobject(LBEvo,loadLocal('iconOBJ'),"IconList");
      setobject(LBEvo,loadLocal('colorOBJ'),"ElementColors");
      setobject(LBEvo,loadLocal('fontOBJ'),"ElementFonts");
      setobject(LBEvo,loadLocal('opacityOB'),"ElementOpacity");
      setobject(LBEvo,loadLocal('scaleOBJ'),"ElementScale");
      setobject(LBEvo,loadLocal('userbg'),"Background");
      setobject(LBEvo,loadLocal('shadowOBJ'),"ElementShadow");
      setobject(LBEvo,loadLocal('lockscreenchosen'),"Lockscreen");
      setobject(LBEvo,loadLocal('newiconimgOBJ'),"CustomIcon");
      setobject(LBEvo,loadLocal('iconset'),"CustomWeatherIcon");
      setobject(LBEvo,loadLocal('objiwidgets'),"SelectediWidget");
      setobject(LBEvo,loadLocal('createdobjcreate'),"CreatedItem");
      setobject(LBEvo,loadLocal('overlay'),"WallOverlay");
      setobject(LBEvo,loadLocal('alignOB'),"ElementAlign");
   var saveDir = "/var/mobile/Library/LBEvoThemes/";
   var plistName = themename + ".plist";
   var filePath = saveDir+plistName;
   savedplist(LBEvo,filePath);
   window.location = window.location.href;
}

function openweather(){
  openapp("com.apple.weather");
}



var dragging = false; //make sure drag is false unless moved
function openapp(bundle){
    if(dragging==true){} //do nothing varible set in touch.js
      else{ //open app that is clicked
        var passcode=isPasscodeon();
        if(passcode==true){
          unlockphone();
          setTimeout(function(){  
            openappBundle(bundle);
          }, 3000);
        }
        else{
         openappBundle(bundle);
        }
    }
}

loadObject = function(savobj,type){
  if(savobj!=null){
    if(savobj.length>=2){
        if(savobj!='undefined'){
    var parsed = JSON.parse(savobj);
    Object.keys(parsed).forEach(function (key) {
        var value = parsed[key];
            if(type == 'hide'){$('#'+key).css('display',value); addappdoubleclick(key);}
                else if(type == 'opacity'){ getEL(key).style.opacity = value; }
                    else if(type == 'icon'){
                            $(".icons").append('<div class="iconcan" name="'+value+'" id=' + key + '></div>');
                                if (loadLocal('locked') !== null) {} else {$('#' + key).touch();}
                    }
                    else if(type == 'iconimg'){
                        if(checkKey(key)){
                            var bundle = getEL(key).getAttribute('name');
                            linkFuncts = "closethisapp('" + key + "')";

                            getEL(key).innerHTML = getEL(key).innerHTML+'<center><div class="iconcan" id="b' + key + '"><img ontouchend="openapp(' + bundle + ') " id="icon' + key + '" class="iconimages" src="' + value + '"></div></center><span id="closer' + key + '" class="closer" >X</span>';
                            closer = getEL("closer" + key);
                            closer.setAttribute('onTouchEnd', linkFuncts);
                         }   
                    }
                    else if(type == 'newiconimg'){
                        if (checkKey(key)) {
                            $('#b' + key + ' .iconimages').attr('src', value);
                        } else {}
                    }
                    else if(type == 'scale'){
                        if(checkKey(key)){
                            if (key === "line" || key === "thickline" || key === "mediumline") {
                                getEL(key).style.height = value+"px";
                            }
                             if (key === "icon") {
                                getEL(key+'img').style.width = value+'px';
                            }
                            if (key === "day1icon" || key === "day2icon" || key === "day3icon" || key === "day4icon") {
                                getEL(key+'i').style.width = value+'px';
                            }
                                
                             if (hazClass(getEL(key),'iconcan')) {
                                getEL('icon'+key).style.width = value+'px';
                            }
                             if (hazClass(getEL(key),'widget')) {
                                if (value >= 2) {
                                    alert("widgets can only be scaled from 0.0 to 1.9")
                                } else {
                                    getEL(key).style.webkitTransform = "scale(" + value + ")";
                                }
                            }
                            getEL(key).style.fontSize = value + 'px';
                        }
                    }
                    else if(type == 'color'){
                        if(checkKey(key)){
                            if (key === "line" || key === "thickline" || key === "mediumline") {
                                getEL(key).style.backgroundColor = value;
                            }
                             var creatitem = $("#" + key).hasClass("createditem");
                            if (creatitem === true) {
                                getEL(key).style.backgroundColor = value;
                            } else {
                                getEL(key).style.color = value;
                            }
                        }
                    }
                    else if(type == 'shadow'){
                        if(checkKey(key)){
                            if (key === "line" || key === "thickline" || key === "mediumline") {
                                getEL(key).style.webkitBoxShadow = value;
                            } else {
                                getEL(key).style.textShadow = value;
                            }
                        }
                    }
                    else if(type == 'align'){
                        getEL(key).style.textAlign = value;
                    }
                    else if(type =='iwidgets'){
                        getwidgetvalues(key, value);
                    }
                    else if(type == 'dragposition'){
                         if(checkKey(key)){
                            if(key == 'weathericonsmenu'){}
                                else{
                                getEL(key).style.webkitTransform = value;
                                }
                        }
                    }
                    else if(type == 'fonts'){
                        //alert('font'+key+value);
                        $('#'+key).css('font-family',value);
                        //getEL(key).style.fontFamily = value;
                    }
                    else if(type == 'caps'){
                        if(checkKey(key)){
                            $('#'+key).css('text-transform',value);
                            //getEL(key).style.textTransform = value;
                        }
                    }
                

                });
            }
        }
    }
}

setTimeout(function(){
loadObject(loadLocal('iconOBJ'),'icon');
loadObject(loadLocal('hideOBJ'),'hide');
loadObject(loadLocal('objiwidgets'),'iwidgets');
loadObject(loadLocal('fontOBJ'),'fonts');
loadObject(loadLocal('iconimgOBJ'),'iconimg');
loadObject(loadLocal('newiconimgOBJ'),'newiconimg');
loadObject(loadLocal('colorOBJ'),'color');
loadObject(loadLocal('shadowOBJ'),'shadow');
loadObject(loadLocal('alignOB'),'align');
loadObject(loadLocal('capsOBJ'),'caps');
loadObject(loadLocal('opacityOB'),'opacity');
loadObject(loadLocal('scaleOBJ'),'scale');
loadObject(loadLocal('dragOBJ'),'dragposition');


},0);

var calev=getcalendarEvents(0);
if(calev == 'No Events'){}
else{
    eventsplit=calev[0].split(':'); //split array
    date=eventsplit[0];
    date=JSON.stringify(date);
    date = date.replace(/"/g, "").split('-');
getEL('events').innerHTML=date[1]+"/"+date[2]+": "+eventsplit[1];
}


function formatSizeUnits(bytes){
    if  (bytes>=1000000000) {bytes=(bytes/1000000000).toFixed(2)+' GB';}
    else if (bytes>=1000000)    {bytes=(bytes/1000000).toFixed(2)+' MB';}
    else if (bytes>=1000)       {bytes=(bytes/1000).toFixed(2)+' KB';}
    else if (bytes>1)       {bytes=bytes+' bytes';}
    else if (bytes==1)      {bytes=bytes+' byte';}
    else                {bytes='0 byte';}
    return bytes;
}

var ddata = devicedata();

 getEL('name').innerHTML=devicename();
 getEL("dsize").innerHTML = "Total: " + formatSizeUnits(ddata.NSFileSystemSize);
 getEL("dfree").innerHTML = "Free: " + formatSizeUnits(ddata.NSFileSystemFreeSize);
 getEL("msize").innerHTML = "Memory: " + formatSizeUnits(devicemem());
 getEL("CPU").innerHTML = "CPU Cores: " + cpu();
 getEL("firm").innerHTML =  firmware();
 getEL("uptime").innerHTML = "Device on for "+uptimeinfo()+" mins";
 getEL("battery").innerHTML = getbattery()+"%";


function alertmemory(){
    closemenu();
  var memoryuse=getjavascriptmemory();
  var free=confirm(memoryuse+"\n *Click ok to free ram","");
  if(free){
    freememory();
  }
}

    
    

if(plisttxt==1){
    var stxt=loadLocal("smstext");
    var mtxt=loadLocal("mailtext");
    var ptxt=loadLocal("phonetext");
    var twtext=loadLocal("twittertext");
    var twbtext=loadLocal("tweetbottext");
    var watext=loadLocal("whatsapptext");


    if(stxt!="undefined"){
      SMStxt=stxt;
    }
    if(mtxt!="undefined"){
      MAILtxt=mtxt;
    }
    if(ptxt!="undefined"){
      PHONEtxt=ptxt;
    }
    if(twtext!="undefined"){
      TWITTERtxt=twtext;
    }
    if(twbtext!="undefined"){
      TWEETBOTtxt=twbtext;
    }
    if(watext!="undefined"){
      WHATSAPPtxt=watext;
    }
}


  getEL("sms").innerHTML = SMStxt+getbadgeSMS();
  getEL("mail").innerHTML = MAILtxt+getbadgeEmail();
  getEL("phone").innerHTML = PHONEtxt+getbadgePhone();
  getEL("twitter").innerHTML = TWITTERtxt+getbadgeTwitter();
  getEL("tweetbot").innerHTML = TWEETBOTtxt+getbadgeTweetbot();
  getEL("whatapp").innerHTML = WHATSAPPtxt+getbadgeWhatsapp();

  saveLocal('apiDeviceName',devicename());
  saveLocal('apiDeviceSize',"Total: " + formatSizeUnits(systemsize()));
  saveLocal('apiDeviceFree',"Free: " + formatSizeUnits(systemfree()));
  saveLocal('apiMsize',"Memory: " + formatSizeUnits(devicemem()));
  saveLocal('apiCPU',"CPU Cores: " + cpu());
  saveLocal('apiUptime','Device on for '+uptimeinfo()+' mins');
  saveLocal('apiFirm',firmware());
  saveLocal('apiSMS',SMStxt+getbadgeSMS());
  saveLocal('apiEmail',MAILtxt+getbadgeEmail());
  saveLocal('apiPhone',PHONEtxt+getbadgePhone());
  saveLocal('apiTwitter',TWITTERtxt+getbadgeTwitter());
  saveLocal('apiTweetbot',TWEETBOTtxt+getbadgeTweetbot());
  saveLocal('apiWhatsapp',WHATSAPPtxt+getbadgeWhatsapp());
