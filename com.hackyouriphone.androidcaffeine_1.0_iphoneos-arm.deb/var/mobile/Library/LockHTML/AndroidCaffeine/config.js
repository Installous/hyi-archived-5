var MainColor = "White";
var BoxColor = "DarkRed";
var BoxTextColor = "LightGrey";
var ShadowColor = "Black";
var ZoomLevel = 100;
