//modified by chevymusclecar //


var WidgetActionOne = false;
var WidgetActionTwo = false;
var WidgetActionThree = false;
var WidgetActionFour = false;


function touchEnd(event) {
if ( WidgetActionOne == false ) {
	document.getElementById('AniActionOne').style.webkitAnimationName = "ActionOneAppear";
	document.getElementById('AniActionOne').style.webkitAnimationDuration = "0.5s";
	WidgetActionOne = true;
	document.getElementById('AniActionTwo').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionTwo').style.webkitAnimationDuration = "0.5s";
	WidgetActionTwo = false;
	document.getElementById('AniActionThree').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionThree').style.webkitAnimationDuration = "0.5s";
	WidgetActionThree = false;
    document.getElementById('AniActionFour').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionFour').style.webkitAnimationDuration = "0.5s";
	WidgetActionFour = false;
	} else {
	document.getElementById('AniActionOne').style.webkitAnimationName = "ActionOneDisappear";
	document.getElementById('AniActionOne').style.webkitAnimationDuration = "0.5s";
	WidgetActionOne = false;
	}}
	
function touchEnd2(event) {
if ( WidgetActionTwo == false ) {
	document.getElementById('AniActionTwo').style.webkitAnimationName = "ActionTwoAppear";
	document.getElementById('AniActionTwo').style.webkitAnimationDuration = "0.5s";
	WidgetActionTwo = true;
	document.getElementById('AniActionOne').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionOne').style.webkitAnimationDuration = "0.5s";
	WidgetActionOne = false;
	document.getElementById('AniActionThree').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionThree').style.webkitAnimationDuration = "0.5s";
	WidgetActionThree = false;
	document.getElementById('AniActionFour').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionFour').style.webkitAnimationDuration = "0.5s";
	WidgetActionFour = false;
	} else {
	document.getElementById('AniActionTwo').style.webkitAnimationName = "ActionTwoDisappear";
	document.getElementById('AniActionTwo').style.webkitAnimationDuration = "0.5s";
	WidgetActionTwo = false;
	}}

function touchEnd3(event) {
if ( WidgetActionThree == false ) {
	document.getElementById('AniActionThree').style.webkitAnimationName = "ActionThreeAppear";
	document.getElementById('AniActionThree').style.webkitAnimationDuration = "0.5s";
	WidgetActionThree = true;
	document.getElementById('AniActionOne').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionOne').style.webkitAnimationDuration = "0.5s";
	WidgetActionOne = false;
	document.getElementById('AniActionTwo').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionTwo').style.webkitAnimationDuration = "0.5s";
	WidgetActionTwo = false;
	document.getElementById('AniActionFour').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionFour').style.webkitAnimationDuration = "0.5s";
	WidgetActionFour = false;
	} else {
	document.getElementById('AniActionThree').style.webkitAnimationName = "ActionThreeDisappear";
	document.getElementById('AniActionThree').style.webkitAnimationDuration = "0.5s";
	WidgetActionThree = false;
	}}

function touchEnd4(event) {
if ( WidgetActionFour == false ) {
	document.getElementById('AniActionFour').style.webkitAnimationName = "ActionFourAppear";
	document.getElementById('AniActionFour').style.webkitAnimationDuration = "0.5s";
	WidgetActionFour = true;
	document.getElementById('AniActionOne').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionOne').style.webkitAnimationDuration = "0.5s";
	WidgetActionOne = false;
	document.getElementById('AniActionTwo').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionTwo').style.webkitAnimationDuration = "0.5s";
	WidgetActionTwo = false;
	document.getElementById('AniActionThree').style.webkitAnimationName = "StayInvisible";
	document.getElementById('AniActionThree').style.webkitAnimationDuration = "0.5s";
	WidgetActionThree = false;
	} else {
	document.getElementById('AniActionFour').style.webkitAnimationName = "ActionFourDisappear";
	document.getElementById('AniActionFour').style.webkitAnimationDuration = "0.5s";
	WidgetActionFour = false;
	}}
 
function init(){
var el1 = document.getElementById("ActionOne");
if ( ChangeClick == false ) {
	el1.addEventListener("touchend", touchEnd, false);
	} else {
	el1.addEventListener("click", touchEnd, false);
var el2 = document.getElementById("ActionTwo");
if ( ChangeClick == false ) {
	el1.addEventListener("touchend", touchEnd2, false);
	} else {
	el2.addEventListener("click", touchEnd2, false);
var el3 = document.getElementById("ActionThree");
if ( ChangeClick == false ) {
	el1.addEventListener("touchend", touchEnd3, false);
	} else {
	el3.addEventListener("click", touchEnd3, false);
var el4 = document.getElementById("ActionFour");
if ( ChangeClick == false ) {
	el1.addEventListener("touchend", touchEnd4, false);
	} else {
	el4.addEventListener("click", touchEnd4, false);
	}}}}}
	





