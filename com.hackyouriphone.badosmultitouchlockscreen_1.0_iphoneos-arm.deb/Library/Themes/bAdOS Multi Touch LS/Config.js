/*

By Dacal, modified for chevymusclecar.
Modified by chevymusclecar.

*/


// CONFIGURATION TOUCH TYPE //


var ChangeClick = true; // True ONLY if you have problem to show forecast when touch the screen.


