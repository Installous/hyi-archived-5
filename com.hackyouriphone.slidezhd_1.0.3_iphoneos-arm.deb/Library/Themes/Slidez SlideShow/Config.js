// Configuration Clock

var ampm = true;         // true=12hr clock false=24hr clock







