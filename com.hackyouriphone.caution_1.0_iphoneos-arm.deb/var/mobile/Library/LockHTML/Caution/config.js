var ZoomSection1 = 100;
var ZoomSection2 = 80;
var ZoomSection3 = 60;
var ZoomSection4 = 70;
var CustomColor = false;
var CustomColorShadows = true;
var CustomColorBackground = "linear-gradient(to right, #000000, #434343)";
var CustomColorText = "White";
