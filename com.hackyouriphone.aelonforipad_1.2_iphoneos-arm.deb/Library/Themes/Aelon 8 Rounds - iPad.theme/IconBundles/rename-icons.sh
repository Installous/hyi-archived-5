for file in *@3x.png; do
  a=`echo "$file" | sed 's/@3x.png*$//'`
  mv $file `basename "$a" .png`~ipad.png
done