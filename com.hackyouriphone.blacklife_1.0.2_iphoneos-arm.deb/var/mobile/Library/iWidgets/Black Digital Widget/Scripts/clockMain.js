clock({
padzero : padzero,
  refresh : refresh,
twentyfour : true,
  success: function(clock){


document.getElementById('hour').innerHTML = clock.hourtext(); 
document.getElementById('minute').innerHTML = clock.minute();
document.getElementById('ampm').innerHTML = clock.am();
document.getElementById('weekday').innerHTML = clock.daytext();
document.getElementById('date').innerHTML = clock.date();
document.getElementById('month').innerHTML = clock.smonth();
document.getElementById('year').innerHTML = clock.year();
  }
});