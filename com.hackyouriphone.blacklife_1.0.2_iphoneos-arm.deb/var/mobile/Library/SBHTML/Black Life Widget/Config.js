var iconSet = "Le0n"; 
var twentyfourhour = true; 
var pad = true; 
