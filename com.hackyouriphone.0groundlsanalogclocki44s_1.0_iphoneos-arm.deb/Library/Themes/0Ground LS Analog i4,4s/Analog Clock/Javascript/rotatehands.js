// Analog clock hands rotation.js by Ian Nicoll.

var ShowSecHand = true; // true to show second hand, false to disable the code (saves battery)

$(document).ready(function() {
    if (ShowSecHand == true) {
        setInterval( function() {
        var seconds = new Date().getSeconds();
        var sdegree = seconds * 6;
        var srotate = "rotate(" + sdegree + "deg)";
        $("#sec").css("-webkit-transform", srotate );
        }, 1000 );
    } else {
        document.getElementById("sec").style.display = 'none';
    }

    setInterval( function() {
    var hours = new Date().getHours();
    var mins = new Date().getMinutes();
    var hdegree = hours * 30 + (mins / 2);
    var hrotate = "rotate(" + hdegree + "deg)";
    $("#hour,").css("-webkit-transform", hrotate );
    }, 1000 );

    setInterval( function() {
    var mins = new Date().getMinutes();
    var mdegree = mins * 6;
    var mrotate = "rotate(" + mdegree + "deg)";
    $("#min,").css("-webkit-transform", mrotate );
    }, 1000 );
});