var Height = "105"; // Dock height - in pixels (default: 100)
var Width = "72"; // Dock width - in percent (default: 80)
var FloatyMode = true; // iPad style dock
var DarkMode = true; // Toggle darkmode
var TwelveHour = false; // Toggle 12hr clock
var Clock = true; // Toggle clock view
var Battery = true; // Toggle battery view
var WiFi = true; // Toggle Wi-Fi view
