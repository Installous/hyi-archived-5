var twentyFourHourTime = true;
//Toggles twelve and twenty-four hour time.