
var updateInterval = "15"; //weather refresh in minutes

var ss = "8"; // slideshow interval in seconds

var slideshow = true; //true or false

var dark = true; //true or false for a dark background

var ytext = "This is Vesper theme."; //add your own text

var lang = "en"; /*
English - en
German - de
French - fr
Italian -it
Spanish - sp
Danish - da
Turkish - tr
*/

var Clock = "24h"; // "12h" or "24h"
