﻿var ledPath = "";

function updateBcSet(group, time) {
	var t2 = time%10;
	var t1 = (time-t2)/10;
	for(var x=8; x>0; x=x/2) {
		if( (t1 - x) >= 0 ) {$("#BKA2"+group+"0"+x).attr("src",ledPath+"led1.png"); t1-=x; }
		if( (t2 - x) >= 0 ) {$("#BKA2"+group+x).attr("src",ledPath+"led1.png"); t2-=x; }
	}
}

function updateBinaryClock() {
	var today=new Date();
	$("#binaryClock img").attr("src",ledPath+"led0.png");
	updateBcSet("S",today.getSeconds());
	updateBcSet("M",today.getMinutes());
	updateBcSet("H",today.getHours());
	setTimeout('updateBinaryClock()',1000);
}


