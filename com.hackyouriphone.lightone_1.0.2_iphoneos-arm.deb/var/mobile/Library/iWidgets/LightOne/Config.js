var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; // choose between "en", "ca", "fr", "de", "it", or "cz"
var prC = '#FFFFFF';//, seC = '#000000'
