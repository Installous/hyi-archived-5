var musicOn = false;
//------------------------- MUSIC FUNCTIONS ---------------------------
function checkMusic(){
	if (isplaying === 1) {
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
	}else{
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
	}
	
	if(title === "(null)"){
		musicOn = false;
		document.getElementById('_artist').innerHTML = '';
		document.getElementById('_title').innerHTML = '';
		removeMusic();
	}else{
		musicOn = true;
		document.getElementById('_artist').innerHTML = artist;
		document.getElementById('_title').innerHTML = title;
		if(document.getElementById('buttonsCont').classList.contains("weather")){
			document.getElementById('musB').style.display = 'block';
			document.getElementById('cleB').style.display = 'none';
		}
	}
	
	
	if(album === "(null)"){
		//document.getElementById('_album').innerHTML = "";
		//document.getElementById('musicArt').src = 'img/note.png';
	}else{
		//document.getElementById('_album').innerHTML = album;
		
		var xhr = new XMLHttpRequest();
		xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
		xhr.send();
		if (xhr.status === "404") {
			//document.getElementById('musicArt').src = 'img/note.png';
		}else{
			document.getElementById('musicArt').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
		}
	}
	
}


function playPause() {
	if ( document.getElementById('playPause').classList.contains("zeek-buttonplay")){ 
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
	}else{ 
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
	}
	window.location = 'xeninfo:playpause';
	document.getElementById('playPause').style.textShadow= "0px 0px 10px #FFFFFF";
	setTimeout(function (){
		document.getElementById('playPause').style.textShadow= "0 0 5px #000000";
	}, 200);
}
		
function next() {
	window.location = 'xeninfo:nexttrack';
	document.getElementById('next').style.textShadow= "0px 0px 10px #FFFFFF";
	setTimeout(function (){
		document.getElementById('next').style.textShadow= "0 0 5px #000000";
	}, 200);
}
			
function prev() {
	window.location = 'xeninfo:prevtrack';
	document.getElementById('prev').style.textShadow= "0px 0px 10px #FFFFFF";
	setTimeout(function (){
		document.getElementById('prev').style.textShadow= "0 0 5px #000000";
	}, 200);
}

