
window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

var h = 30;
var gauge1;
var gauge2;
var perc = 0;
var yp;


function init(){
	gauge1 = semiGauge("batgauge",100,18);
	gauge2 = loadLiquidFillGauge("fillgauge1", 0);
	updateClock();
	setInterval("updateClock();", 1000);
	checkSettings();
}

function checkSettings(){
	
	prC = C1;
	h = contH;
	yp = 100 - h + '%';
	document.documentElement.style.setProperty('--primary', C1);
	document.documentElement.style.setProperty('--secondary', C2);
	document.documentElement.style.setProperty('--third', C3);
	document.documentElement.style.setProperty('--contC', cC);
	
	document.documentElement.style.setProperty('--yPos', yPos + 'px');
	document.documentElement.style.setProperty('--fyPos', fyPos + 'px');
	document.documentElement.style.setProperty('--contH', contH + '%');
	document.documentElement.style.setProperty('--contR', contR + 'px');
	
	if(_bg === 0){
		document.getElementById("bg").style.display = 'none';
	}
	
	if(dt === 0){
		document.getElementById("_date").style.display = 'none';
		document.getElementById("_time").style.display = 'none';
	}
	
	if(cb === 1){
		document.getElementById("appsCont").classList.add('blur');
	}
	
	if(em === 0){
		changeScreen();
	}
	
	if(we === 1 && em === 1){
		changeScreen();
	}
	
	//create forecast
    forecastMaker.makeForecast({
        holder: document.getElementById('forecast'),
		color: prC,
        dayCount: 4, //number of days
        dayWidth: 50, //holder width can also be used as spacing
        dayHeight: 45, //holder height
        imgWidth: 38, //image size
        font: 'heavy',
        dayTop: 0, //day vertical position from top
        tempBottom: 0, //temp vertical position from bottom
        fontSize: 8, //day text and temp size
        iconURL: 'weather_icons/', //url to icon
        iconsName: 'weatherIcons', //id for weather icons (increments)
        daysName: 'weatherDays', //id for days (increments)
        tempsName: 'weatherTemps', //id for temps (increments)
    });
	
}

//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	//var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	
	perc = 100 - Math.round(100/1440 * ((currentTime.getHours() * 60) + currentMinutes));
	//document.getElementById("_time").innerHTML = perc;
	
	gauge2.update(perc);
	
	
	document.getElementById("_date").innerHTML = shortmonths[currentTime.getMonth()] + ", " + shortdays[currentTime.getDay()] + " " + currentDate;
	
	document.getElementById("_time").innerHTML = currentHours + "|" + currentMinutes1;
		
}


function changeScreen(){
	
	if(document.getElementById('buttonsCont').classList.contains("empty")){
		showWeather();
		
		if(musicOn){
			document.getElementById('weaB').style.display = 'none';
			document.getElementById('musB').style.display = 'block';
		}else{
			document.getElementById('weaB').style.display = 'none';
			document.getElementById('cleB').style.display = 'block';
		}
		
		return;
	}
	
	if(musicOn){
		if(document.getElementById('buttonsCont').classList.contains("weather")){
			document.getElementById('buttonsCont').classList.remove("weather");
			document.getElementById('buttonsCont').classList.remove("empty");
			document.getElementById('buttonsCont').classList.add("music");
			
			if(em === 1){
				document.getElementById('musB').style.display = 'none';
				document.getElementById('cleB').style.display = 'block';
			}else{
				document.getElementById('musB').style.display = 'none';
				document.getElementById('weaB').style.display = 'block';
			}
			
			TweenMax.to(document.getElementById('_weaCont'), 0.5, {alpha:0, onComplete:function(){
				document.getElementById('_weaCont').style.display = 'none';
				//add music animation
				document.getElementById('_musCont').style.display = 'block';
				TweenMax.to(document.getElementById('_musCont'), 0.5, {alpha:1});
			}});
			
			return;
		}
		
		if(document.getElementById('buttonsCont').classList.contains("music")){
			removeMusic();
			return;
		}
	}else{
		if(document.getElementById('buttonsCont').classList.contains("weather") && em === 1){
			document.getElementById('buttonsCont').classList.remove("weather");
			document.getElementById('buttonsCont').classList.remove("music");
			document.getElementById('buttonsCont').classList.add("empty");
			
			document.getElementById('weaB').style.display = 'block';
			document.getElementById('cleB').style.display = 'none';
			
			TweenMax.to(document.getElementById('bg'), 0.5, {alpha:0});
			TweenMax.to(document.getElementById('appsCont'), 0.5, {top:'100%'});
			TweenMax.to(document.getElementById('_weaCont'), 0.5, {alpha:0, onComplete:function(){
				document.getElementById('_weaCont').style.display = 'none';
			}});
			
			return;
		}
	}
}

function removeMusic(){
	if(document.getElementById('buttonsCont').classList.contains("weather")){
		document.getElementById('musB').style.display = 'none';
		document.getElementById('cleB').style.display = 'block';
	}
	
	if(document.getElementById('buttonsCont').classList.contains("music")){
		if(em === 1){
			document.getElementById('buttonsCont').classList.remove("music");
			document.getElementById('buttonsCont').classList.remove("weather");
			document.getElementById('buttonsCont').classList.add("empty");
					
			document.getElementById('cleB').style.display = 'none';
			document.getElementById('weaB').style.display = 'block';
			
			TweenMax.to(document.getElementById('bg'), 0.5, {alpha:0});
			TweenMax.to(document.getElementById('_musCont'), 0.5, {alpha:0, onComplete:function(){
				document.getElementById('_musCont').style.display = 'none';
				TweenMax.to(document.getElementById('appsCont'), 0.5, {top:'100%'});
			}});
		}else{
			if(musicOn){
				document.getElementById('weaB').style.display = 'none';
				document.getElementById('musB').style.display = 'block';
			}else{
				document.getElementById('weaB').style.display = 'none';
				document.getElementById('cleB').style.display = 'block';
			}
			TweenMax.to(document.getElementById('_musCont'), 0.5, {alpha:0, onComplete:function(){
				document.getElementById('_musCont').style.display = 'none';
				showWeather();
			}});
		}
	}
}

function showWeather(){
	document.getElementById('buttonsCont').classList.remove("empty");
	document.getElementById('buttonsCont').classList.remove("music");
	document.getElementById('buttonsCont').classList.add("weather");
	
	document.getElementById('_weaCont').style.display = 'block';
	TweenMax.to(document.getElementById('bg'), 0.5, {alpha:1});
	TweenMax.to(document.getElementById('appsCont'), 0.5, {top:yp});
	TweenMax.to(document.getElementById('_weaCont'), 0.5, {alpha:1});
}

