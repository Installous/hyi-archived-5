

var startAnim = false;

//--------------------------- XENINFO ---------------------------
function mainUpdate(type){ 
	if(type === "weather"){
		checkWeather();
	}else if (type === "battery"){
		updateBattery();	  	
	}else if (type === "music"){
		checkMusic();
	}else if (type == "statusbar"){
		//updateBars();	
	}
}

//------------------- WIFI SIGNAL FUNCTION -----------------------
/*//var signalBars;
//var wifiBars;
function updateBars(){
	//signalBars = 4;
	//wifiBars = 3;
	gauge1.update(signalBars);
	gauge2.update(wifiBars);
}*/

//------------------------- BATTERY FUNCTIONS ---------------------------
//var batteryPercent;
//var batteryCharging = 0;
var batInside = document.getElementById("batInside");

function updateBattery() {
	"use strict";

	var batt = document.getElementById("percent");
	//console.log("battery");
	//batteryPercent = 20;
	batt.innerHTML = batteryPercent;
	gauge1.update(batteryPercent);
}

//------------------------- WEATHER FUNCTIONS ---------------------------
function checkWeather(){
	document.getElementById('weatherIcon').src = 'weather_icons/' + weather.conditionCode + '.png';
	document.getElementById('weaB').src = 'weather_icons/' + weather.conditionCode + '.png';
	//document.getElementById('tempe').innerHTML = weather.temperature + 'º';
	document.getElementById('condition').innerHTML = weather.condition;
	document.getElementById("_hum").innerHTML = weather.humidity + '%';
	document.getElementById("_win").innerHTML = weather.windSpeed;
	document.getElementById("_vis").innerHTML = weather.chanceofrain + '%';
	
	animateWeather(weather.temperature, weather.low, weather.high);
	
	//forecast
    var icon, i;
    for (i = 0; i < fcastObj.dayCount; i++) { //loop through forecast and update each day
    	icon = (weather.dayForecasts[i].icon == 3200) ? weather.conditionCode : weather.dayForecasts[i].icon;
        document.getElementById(fcastObj.icon + i).src = fcastObj.iconURL + icon + '.png';
        document.getElementById(fcastObj.day + i).innerHTML = shortdays[weather.dayForecasts[i].dayOfWeek - 1];
        document.getElementById(fcastObj.temp + i).innerHTML = weather.dayForecasts[i].high + '/' + weather.dayForecasts[i].low;
		document.getElementById(fcastObj.icon + i).style.filter = 'opacity(.5) drop-shadow(0 0 0 ' + prC + ')';
    }
	
	if(startAnim === false){
		startAnim = true;
		$('#tempe').each(function() {
		  $(this).prop('Counter', 0).animate({
			Counter: weather.temperature
		  }, {
			duration: 1200,
			easing: 'swing',
			step: function(now) {
			  $(this).text(Math.ceil(now));
			}
		  });
		});
		return;
	}else{
		document.getElementById("tempe").innerHTML = weather.temperature;
	}
	
}

//animateWeather(28, 25, 33);
function animateWeather(curr, low, high){
	var range = 0;
	for(var i = low; i < high; i++){
		range++;
	}
	if(curr > high){
		curr = high;
	}
	if(curr < low){
		curr = low;
	}
	var tempRange = curr - low;
	var newH = tempRange * 98 / range;
	
	document.getElementById("cir").style.left = newH + '%';
	document.getElementById("tempe").style.left = newH + '%';
}

//------------------------- OPEN APP FUNCTIONS ---------------------------
function openApp(app){
	window.location = 'xeninfo:openapp:' + app;
}


