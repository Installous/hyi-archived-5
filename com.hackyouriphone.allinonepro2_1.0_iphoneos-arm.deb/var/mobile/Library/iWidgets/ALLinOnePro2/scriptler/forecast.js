/* 

Usage:

forecastMaker.makeForecast({
  holder: document.getElementById('forecast'), //div where you want the forecast
  color: 'white', //font color
  dayCount: 5, //number of days
  dayWidth: 55, //holder width can also be used as spacing
  dayHeight: 55, //holder height
  imgWidth: 30, //image size
  font: 'helvetica',
  dayTop: -4, //day vertical position from top
  tempBottom: 0, //temp vertical position from bottom
  fontSize: 10, //day text and temp size
  iconURL: 'icons/', //url to icon
  iconsName: 'weatherIcons', //id for weather icons (increments)
  daysName: 'weatherDays', //id for days (increments)
  tempsName: 'weatherTemps', //id for temps (increments)
});

*/
var forecastMaker = {
    setHolderCSS: function (holder, innerHolder) {
    	holder.style.cssText = "text-align:center;";
    	innerHolder.style.cssText = "display:inline-block;";
    	/* doesn't work on iOS 10 */
        //holder.style.cssText = "display: flex;justify-content: center;";
    },
    makeForecast: function (obj) {
        var doc = document,
        	innerHolder = document.createElement('div');
        for (var i = 0; i < obj.dayCount; i++) {
            var box = doc.createElement('div'),
                image = doc.createElement('img'),
                days = doc.createElement('span'),
                temps = doc.createElement('span');

            //container for elements
            /*	
            	//doesn't work on iOS10
            	float: left;
				display: flex;
		  		justify-content: center;
		  	*/
            box.style.cssText = "\
					position: relative;\
					width: " + obj.dayWidth + "px;\
					height: " + obj.dayHeight + "px;\
					display:inline-block; \
		  			";

            //image element	
            image.id = obj.iconsName + i;
            image.style.cssText = "\
		  			position:absolute;\
		  			left:50%; \
		  			-webkit-transform:translate(-50%, 0); \
					top:8px;\
					width: " + obj.imgWidth + "px;\
					";
            image.src = obj.iconURL + (30 + i) + ".png";
            box.appendChild(image);

            //day element
            days.innerHTML = "days";
            days.id = obj.daysName + i;
            days.style.cssText = "\
			    position:absolute;\
					color:" + obj.color +";\
					top:" + obj.dayTop + "px;\
					text-align:center;\
					left:50%; \
		  			-webkit-transform:translate(-50%, 0); \
					width: " + obj.dayWidth + "px;\
					font-size:" + obj.fontSize + "px;\
					font-family:" + obj.font + ";\
					";
            box.appendChild(days);

            //temp element
            temps.innerHTML = "temps";
            temps.id = obj.tempsName + i;
            temps.style.cssText = "\
			    	position:absolute;\
					bottom:" + obj.tempBottom + "px;\
					text-align:center;\
					left:50%; \
		  			-webkit-transform:translate(-50%, 0); \
					width: " + obj.dayWidth + "px;\
					color:" + obj.color +";\
					font-size:" + obj.fontSize + "px;\
					font-family:" + obj.font + ";\
					;"
            box.appendChild(temps);
            innerHolder.appendChild(box);
            obj.holder.appendChild(innerHolder);
        }
        this.setHolderCSS(obj.holder, innerHolder);
        window.fcastObj = {
        	dayCount: obj.dayCount,
        	iconURL: obj.iconURL,
        	icon: obj.iconsName,
        	day: obj.daysName,
        	temp: obj.tempsName

        };
    }
};