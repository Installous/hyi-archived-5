
window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);


//create forecast
        forecastMaker.makeForecast({
            holder: document.getElementById('forecast'),
			color: prC,
            dayCount: 6, //number of days
            dayWidth: 60, //holder width can also be used as spacing
            dayHeight: 38, //holder height
            imgWidth: 40, //image size
            font: 'thin',
            dayTop: 1, //day vertical position from top
            tempBottom: 0, //temp vertical position from bottom
            fontSize: 12, //day text and temp size
            iconURL: 'resimler/havadurumu/', //url to icon
            iconsName: 'weatherIcons', //id for weather icons (increments)
            daysName: 'weatherDays', //id for days (increments)
            tempsName: 'weatherTemps', //id for temps (increments)
        });


var clock=document.getElementById("canvas");
var ctx = clock.getContext("2d");
//var my_gradient = ctx.createLinearGradient(0, 0, 85, 75);
var x = 75;
var y = 75;



function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	//var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock == "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	if (Clock == "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	
	
	document.getElementById("_month").innerHTML = shortmonths[currentTime.getMonth()];
	//document.getElementById("_day").innerHTML = days[currentTime.getDay()];
	document.getElementById("_date").innerHTML = currentDate;
	
	document.getElementById("_hour").innerHTML = currentHours;
	document.getElementById("_minutes").innerHTML = currentMinutes1;
	
	//-----Analog Clock-----
	
	ctx.beginPath();
	//ctx.clearRect(0, 0, clock.width, clock.height);
	ctx.fillStyle=teC;
	ctx.arc(x,y,70,0,Math.PI*2,true);
	ctx.fill();
	ctx.strokeStyle='transparent';
	ctx.lineWidth=1;
	ctx.stroke();
	
	drawPointer(360*(currentHours/12)+(currentMinutes/60)*30-90,35,"red",5);
	drawPointer(360*(currentMinutes/60)+(currentTime.getSeconds()/60)*6-90,50,"#FFFF00",4);
	drawPointer(360*(currentTime.getSeconds()/60)+x-90,60,"blue",2);
		
}




function drawPointer(deg,len,color,w){
	var rad=(Math.PI/180*deg);
	var x1=x+Math.cos(rad)*len;
	var y1=y+Math.sin(rad)*len;
	 
	ctx.beginPath();
	ctx.strokeStyle=color;
	ctx.lineWidth=w;
	ctx.lineCap = "round";
	ctx.moveTo(x,y);
	ctx.lineTo(x1,y1);
	ctx.stroke();
}


//var batteryPercent;
//var batteryCharging = 0;
var batInside = document.getElementById("batInside");

function updateBattery() {
	"use strict";

	var batt = document.getElementById("percentage");
	//console.log("battery");
	//batteryPercent = 20;
	batt.innerHTML = batteryPercent;
	batInside.style.width = (batteryPercent * 100 / 100) + 'px';
	
	if(batteryCharging === 1){
		batInside.style.background = '#2483CB';
	}else{
		batInside.style.background = '#519900';
	}
	
	if (batteryPercent <= 20 && batteryPercent > 10 && batteryCharging === 0) {
		batInside.style.background = '#992600';
	} else if (batteryPercent <= 10 && batteryCharging === 0) {
		batInside.style.background = '#DE3840';
	}
}


function checkWeather(){
	//forecast
    var icon, i;
    for (i = 0; i < fcastObj.dayCount; i++) { //loop through forecast and update each day
    	icon = (weather.dayForecasts[i].icon == 3200) ? weather.conditionCode : weather.dayForecasts[i].icon;
        document.getElementById(fcastObj.icon + i).src = fcastObj.iconURL + icon + '.png';
        document.getElementById(fcastObj.day + i).innerHTML = shortdays[weather.dayForecasts[i].dayOfWeek - 1];
        document.getElementById(fcastObj.temp + i).innerHTML = weather.dayForecasts[i].high + '/' + weather.dayForecasts[i].low;
    }
	
}

function checkSettings(){
	if(weat === 0){
		document.getElementById("_tempContBg").style.display = 'none';
	document.getElementById("_tempCont").style.display = 'none';

	}
      if(canvas === 0){
	document.getElementById("canvas").style.display = 'none';

	}
	if(battery === 0){
		document.getElementById("_batContBg").style.display = 'none';
		document.getElementById("_batCont").style.display = 'none';

	}

	document.documentElement.style.setProperty('--primary', prC);
	document.documentElement.style.setProperty('--secondary', seC);

document.documentElement.style.setProperty('--tertiary', teC);

	document.body.style.transform = "scale(" + scaleP + "," + scaleP + ")";
}


function init(){
	checkSettings();
	//my_gradient.addColorStop(0, "#2BD4DA");
	//my_gradient.addColorStop(1, "#2483CB");
	updateClock();
	setInterval("updateClock();", 1000);
}


		function playPause() {
			if ( document.getElementById('playPause').classList.contains("zeek-buttonplay")){ 
				document.getElementById('playPause').classList.remove("zeek-buttonplay");
				document.getElementById('playPause').classList.add("zeek-buttonpause");
				document.getElementById('playPause').src = 'resimler/pause.png';
			}else{ 
				document.getElementById('playPause').classList.remove("zeek-buttonpause");
				document.getElementById('playPause').classList.add("zeek-buttonplay");
				document.getElementById('playPause').src = 'resimler/play.png';
			}
			window.location = 'xeninfo:playpause';
		}
		
		function next() {
			window.location = 'xeninfo:nexttrack';
		}
			
		function prev() {
			window.location = 'xeninfo:prevtrack';
		}


function mainUpdate(type){ 
	if(type == "weather"){
		checkWeather();
	}else if (type == "system"){
				
	}else if (type == "battery"){
		updateBattery();	  	
	}else if (type == "music"){
		if (isplaying === 1) {
			document.getElementById('playPause').classList.remove("zeek-buttonplay");
			document.getElementById('playPause').classList.add("zeek-buttonpause");
			document.getElementById('playPause').src = 'resimler/pause.png';
		}else {
			document.getElementById('playPause').classList.remove("zeek-buttonpause");
			document.getElementById('playPause').classList.add("zeek-buttonplay");
			document.getElementById('playPause').src = 'resimler/play.png';
		}
		if(title === "(null)"){
			document.getElementById('controls').style.display = 'none';	
		}else{
			document.getElementById('controls').style.display = 'block';
		}
	}
}


