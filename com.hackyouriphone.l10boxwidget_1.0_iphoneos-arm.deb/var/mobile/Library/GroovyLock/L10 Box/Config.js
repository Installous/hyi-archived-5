var twentyfourh = false; // true for 24 hr
var pad = true; // true to pad zero in hour
var textcolor = "white"; // Enter the color code or name you want.  sample; #33BEFF (light blue), sample2; #9FA2B1 (Black Eagle color), sample3;  #ebd394 (gold) ...
var IconSet = "Le0n"; //