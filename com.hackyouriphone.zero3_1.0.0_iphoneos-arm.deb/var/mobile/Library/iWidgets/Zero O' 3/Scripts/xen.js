


//--------------------------- XENINFO ---------------------------
function mainUpdate(type){ 
	if (type === "battery"){
		updateBattery();	  	
	}else if (type === "music"){
		if(mu === 1){
			checkMusic();
		}
	}else if (type == "statusbar"){
		sigBars(wifiBars, "wifi");
		sigBars(signalBars, "carr");
	}
}

//sigBars("2", "wifi");
//sigBars("3", "carr");
//------------------------- SIGNAL FUNCTIONS ---------------------------
function sigBars(_curr, name){
	if(name === "wifi"){
		if(_curr === "0"){
			document.getElementById("wiS1").style.opacity = 0.5;
			document.getElementById("wiS2").style.opacity = 0.5;
			document.getElementById("wiS3").style.opacity = 0.5;
		}
		if(_curr === "1"){
			document.getElementById("wiS1").style.opacity = 1;
			document.getElementById("wiS2").style.opacity = 0.5;
			document.getElementById("wiS3").style.opacity = 0.5;
		}
		if(_curr === "2"){
			document.getElementById("wiS1").style.opacity = 1;
			document.getElementById("wiS2").style.opacity = 1;
			document.getElementById("wiS3").style.opacity = 0.5;
		}
		if(_curr === "3"){
			document.getElementById("wiS1").style.opacity = 1;
			document.getElementById("wiS2").style.opacity = 1;
			document.getElementById("wiS3").style.opacity = 1;
		}
	}
	
	if(name === "carr"){
		if(_curr === "0"){
			document.getElementById("caS1").style.opacity = 0.5;
			document.getElementById("caS2").style.opacity = 0.5;
			document.getElementById("caS3").style.opacity = 0.5;
			document.getElementById("caS4").style.opacity = 0.5;
		}
		if(_curr === "1"){
			document.getElementById("caS1").style.opacity = 1;
			document.getElementById("caS2").style.opacity = 0.5;
			document.getElementById("caS3").style.opacity = 0.5;
			document.getElementById("caS4").style.opacity = 0.5;
		}
		if(_curr === "2"){
			document.getElementById("caS1").style.opacity = 1;
			document.getElementById("caS2").style.opacity = 1;
			document.getElementById("caS3").style.opacity = 0.5;
			document.getElementById("caS4").style.opacity = 0.5;
		}
		if(_curr === "3"){
			document.getElementById("caS1").style.opacity = 1;
			document.getElementById("caS2").style.opacity = 1;
			document.getElementById("caS3").style.opacity = 1;
			document.getElementById("caS4").style.opacity = 0.5;
		}
		if(_curr === "4"){
			document.getElementById("caS1").style.opacity = 1;
			document.getElementById("caS2").style.opacity = 1;
			document.getElementById("caS3").style.opacity = 1;
			document.getElementById("caS4").style.opacity = 1;
		}
	}
}



//------------------------- BATTERY FUNCTIONS ---------------------------
//var batteryPercent;
function updateBattery(){
	//batteryPercent = 25;
	document.getElementById("_perc").innerHTML = batteryPercent;
	
}
