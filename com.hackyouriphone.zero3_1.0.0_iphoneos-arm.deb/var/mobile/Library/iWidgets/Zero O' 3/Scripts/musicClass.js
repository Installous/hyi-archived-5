
//------------------------- MUSIC FUNCTIONS ---------------------------
function checkMusic(){
	if (isplaying === 1) {
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
	}else{
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
	}
	
	if(title === "(null)"){
		document.getElementById('_sc4').style.display = 'none';
		document.getElementById('_artist').innerHTML = '';
		document.getElementById('_title').innerHTML = 'No Media';
		if(!document.getElementById('_sc4').classList.contains("hide")){
			musicSH();
		}
	}else{
		if(artist === "(null)"){
			document.getElementById('_artist').innerHTML = '';
		}else{
			document.getElementById('_artist').innerHTML = artist;
		}
		document.getElementById('_title').innerHTML = title;
		document.getElementById('_sc4').style.display = 'block';
	}
	
	
	if(album === "(null)"){
		//document.getElementById('_album').innerHTML = "";
		document.getElementById('musicArt').src = 'img/note.PNG';
		document.getElementById('musicArtBg').src = 'img/note.PNG';
	}else{
		//document.getElementById('_album').innerHTML = album;
		
		var xhr = new XMLHttpRequest();
		xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
		xhr.send();
		if (xhr.status === "404") {
			document.getElementById('musicArt').src = 'img/note.PNG';
			document.getElementById('musicArtBg').src = 'img/note.PNG';
		}else{
			document.getElementById('musicArt').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
			document.getElementById('musicArtBg').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
		}
	}
	
}


function playPause() {
	if ( document.getElementById('playPause').classList.contains("zeek-buttonplay")){ 
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
	}else{ 
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
	}
	window.location = 'xeninfo:playpause';
	document.getElementById('playPause').style.textShadow= "0px 0px 10px #FFFFFF";
	setTimeout(function (){
		document.getElementById('playPause').style.textShadow= "0px 0px 0px #FFFFFF";
	}, 200);
}
		
function next() {
	window.location = 'xeninfo:nexttrack';
	document.getElementById('next').style.textShadow= "0px 0px 10px #FFFFFF";
	setTimeout(function (){
		document.getElementById('next').style.textShadow= "0px 0px 0px #FFFFFF";
	}, 200);
}
			
function prev() {
	window.location = 'xeninfo:prevtrack';
	document.getElementById('prev').style.textShadow= "0px 0px 10px #FFFFFF";
	setTimeout(function (){
		document.getElementById('prev').style.textShadow= "0px 0px 0px #FFFFFF";
	}, 200);
}

