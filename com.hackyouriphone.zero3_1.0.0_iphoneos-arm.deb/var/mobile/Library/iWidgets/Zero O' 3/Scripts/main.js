
window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);


var musOp = false;
var remOp = true;
var rem = true;


function init(){
	if(ti === 1 || da === 1){
		updateClock();
		setInterval("updateClock();", 1000);
	}
	checkSettings();
}

function checkSettings(){
	
	if(to === 1){
		document.getElementById("_appsCont").classList.remove('noTop');
		document.getElementById("_appsCont").classList.add('Top');
		document.getElementById("appsContIn").classList.remove('noTop');
		document.getElementById("appsContIn").classList.add('Top');
		
		document.getElementById("border").classList.add('Top');
		
		document.getElementById("scHolder").classList.add('Top');
		
		document.getElementById("artCont").classList.add('Top');
		
		document.getElementById("controls").classList.remove('noTop');
		document.getElementById("controls").classList.add('Top');
		document.getElementById("playPause").classList.remove('noTop');
		document.getElementById("playPause").classList.add('Top');
		document.getElementById("prev").classList.remove('noTop');
		document.getElementById("prev").classList.add('Top');
		document.getElementById("next").classList.remove('noTop');
		document.getElementById("next").classList.add('Top');
	}
	
	if(ac === 0){
		document.getElementById("_appsCont").style.display = 'none';
	}
	document.documentElement.style.setProperty('--appH', acH + 'px');
	
	if(ti === 0){
		document.getElementById("timeCont").style.display = 'none';
	}
	document.getElementById("timeCont").style.right = tiX + 'px';
	document.getElementById("timeCont").style.top = tiY + 'px';
	
	if(da === 0){
		document.getElementById("dateCont").style.display = 'none';
	}
	document.getElementById("dateCont").style.left = daX + 'px';
	document.getElementById("dateCont").style.top = daY + 'px';
	
	if(bu === 0){
		document.getElementById("scHolder").style.display = 'none';
	}
	
	document.documentElement.style.setProperty('--txtC', c1);
	document.documentElement.style.setProperty('--secondary', c2);
}


//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	//var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	
	document.getElementById("_month").innerHTML = shortmonths[currentTime.getMonth()];
	document.getElementById("_date").innerHTML = currentDate;
	document.getElementById("_day").innerHTML = days[currentTime.getDay()];
	
	document.getElementById("_hour").innerHTML = currentHours + '<br>' + currentMinutes1;
	//document.getElementById("_minutes").innerHTML = currentMinutes1;
	document.getElementById("_sec").innerHTML = currentSeconds;
		
}


//------------------------- BUTTON FUNCTIONS ---------------------------
//------------------------ SHOW MUSIC -------------------------
function musicSH(){
	if(document.getElementById('_sc4').classList.contains("hide")){
		moveMusic('open');
		musOp = true;
		return;
	}else{
		moveMusic('close');
		musOp = false;
		return;
	}
}

function moveMusic(str){
	if(str === 'open'){
		document.getElementById("_musCont").style.display = 'block';
		
		TweenMax.to(document.getElementById('appsContIn'), 0.5, {alpha:0.5});
		
		TweenMax.to(document.getElementById('_musCont'), 0.5, {top:'0px', alpha:1, onComplete:function(){
			//TweenMax.to(document.getElementById('infoCont'), 0.2, {alpha:1});
			TweenMax.to(document.getElementById('artCont'), 0.4, {alpha:1, left:'0px'});
			document.getElementById('_sc4').classList.remove("hide");
		}});
	}
	
	if(str === 'close'){
		TweenMax.to(document.getElementById('artCont'), 0.4, {alpha:0, left:'-100%'});
		
		TweenMax.to(document.getElementById('appsContIn'), 0.5, {alpha:1});
		
		TweenMax.to(document.getElementById('infoCont'), 0.4, {alpha:1, onComplete:function(){
			
			TweenMax.to(document.getElementById('_musCont'), 0.5, {top:'100vh', alpha:0, onComplete:function(){
				document.getElementById("_musCont").style.display = 'none';
				document.getElementById('_sc4').classList.add("hide");
			}});
		}});
	}
}


function slideArt(){
	if(document.getElementById('musicArt').classList.contains("in")){
		document.getElementById('musicArt').classList.remove("in");
		TweenMax.to(document.getElementById('musicArt'), 0.5, {left:'50%'});
		return;
	}else{
		document.getElementById('musicArt').classList.add("in");
		TweenMax.to(document.getElementById('musicArt'), 0.5, {left:0});
		return;
	}
}


//------------------------- COLOR FUNCTIONS ---------------------------
function changeColor(){
	if(document.getElementById('container').classList.contains("dark")){
		document.getElementById('container').classList.remove("dark");
		document.documentElement.style.setProperty('--primary', '#0F0F0D');//
		//document.documentElement.style.setProperty('--secondary', 'rgba(248,248,248,0.40)');
		document.documentElement.style.setProperty('--third', '#D8E8E9');
		return;
	}else{
		document.getElementById('container').classList.add("dark");
		document.documentElement.style.setProperty('--primary', '#D8E8E9');
		//document.documentElement.style.setProperty('--secondary', 'rgba(31,35,41,0.40)');
		document.documentElement.style.setProperty('--third', '#0F0F0D');
		return;
	}
}


