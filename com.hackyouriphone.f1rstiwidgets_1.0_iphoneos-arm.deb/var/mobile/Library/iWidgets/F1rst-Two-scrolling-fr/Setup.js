// Configuration by Dacal //

// For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)
var ampm = false; // Set to true for 12h format
var gps = false; // You NEED to install crazyvivek's "GPS Weather Lockscreen" for GPS localization
var locale = 615702; // Yahoo Weather (used if gps set to false or myLocation.txt file not found)
var tempUnit = "c"; // f for fahrenheit
var updateInterval = 15; // in minutes
var lang = "fr"; // (fr) for french, (de) for german, (sp) for spanish, (en) or anything else for english.
var SecDisplay = false; // true to display seconds - battery eater !
var GMT = 0; // Adjust the hour of sunset and sunrise only if YahooWeather don't report correctly summer time

