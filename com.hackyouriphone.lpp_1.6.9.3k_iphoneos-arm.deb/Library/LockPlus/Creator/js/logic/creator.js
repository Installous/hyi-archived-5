/* 
	Runs actions that places multiple items automatically.
*/
(function(window, doc) {
	var creations = {
		MusicControls: function(){
			var name, div,
			width = 200,
			height = 60;

			action.addtoScreen('playmusic');
			action.addtoScreen('prevmusic');
			action.addtoScreen('nextmusic');

			action.selectedItem = 'playmusic';
			name = customPanel.makeFirstPanel();
			action.selectedItem = 'prevmusic';
			customPanel.addToPanel(name);
			action.selectedItem = 'nextmusic';
			customPanel.addToPanel(name);

			div = doc.getElementById(name);

			action.setCss(name, 'width', width+'px');
			action.setCss(name, 'height', height+'px');
			action.setCss(name, 'background-color', 'rgba(0,0,0,0.6)');
			action.setCss(name, 'border-radius', '10px');
			action.setCss(name, 'left', 320 / 2 - div.offsetWidth / 2 + "px");

			name = 'playmusic';
			div = doc.getElementById(name);
			action.setCss(name, 'width', '50px');
			action.setCss(name, 'height', '30px');
			action.setCss(name, 'line-height', '30px');
			action.setCss(name, 'text-align', 'center');
			action.setCss(name, 'left', width / 2 - 50 / 2 + "px");
			action.setCss(name, 'top', height / 2 - 30 / 2 + "px");

			name = 'prevmusic';
			div = doc.getElementById(name);
			action.setCss(name, 'width', '50px');
			action.setCss(name, 'height', '30px');
			action.setCss(name, 'line-height', '30px');
			action.setCss(name, 'text-align', 'center');
			action.setCss(name, 'left', "20px");
			action.setCss(name, 'top', height / 2 - 30 / 2 + "px");

			name = 'nextmusic';
			div = doc.getElementById(name);
			action.setCss(name, 'width', '50px');
			action.setCss(name, 'height', '30px');
			action.setCss(name, 'line-height', '30px');
			action.setCss(name, 'text-align', 'center');
			action.setCss(name, 'left', "130px");
			action.setCss(name, 'top', height / 2 - 30 / 2 + "px");
		},
		ForecastIcons: function(){
			var name = '', 
			div,
			width = 210,
			height = 60,
			iconwidth = 30;

			action.addtoScreen('day1icon');
			action.addtoScreen('day2icon');
			action.addtoScreen('day3icon');
			action.addtoScreen('day4icon');
			

			action.selectedItem = 'day1icon';
			name = customPanel.makeFirstPanel();
			action.selectedItem = 'day2icon';
			customPanel.addToPanel(name);
			action.selectedItem = 'day3icon';
			customPanel.addToPanel(name);
			action.selectedItem = 'day4icon';
			customPanel.addToPanel(name);


			div = doc.getElementById(name);

			action.setCss(name, 'width', width+'px');
			action.setCss(name, 'height', height+'px');
			action.setCss(name, 'background-color', 'rgba(0,0,0,0.6)');
			action.setCss(name, 'border-radius', '10px');
			action.setCss(name, 'left', 320 / 2 - div.offsetWidth / 2 + "px");

			name = 'day1icon';
			div = doc.getElementById(name);
			div.children[0].style.cssText = 'pointer-events:none;width:' + iconwidth + 'px;' + 'height:' + iconwidth + 'px;';
			action.setCss(name, 'width', iconwidth+'px');
			action.setCss(name, 'height', iconwidth+'px');
			action.setCss(name, 'top', height / 2 - iconwidth / 2 + "px");
			action.setCss(name, 'left', "15px");

			name = 'day2icon';
			div = doc.getElementById(name);
			div.children[0].style.cssText = 'pointer-events:none;width:' + iconwidth + 'px;' + 'height:' + iconwidth + 'px;';
			action.setCss(name, 'width', iconwidth + 'px');
			action.setCss(name, 'height', iconwidth + 'px');
			action.setCss(name, 'top', height / 2 - iconwidth / 2 + "px");
			action.setCss(name, 'left', "65px");

			name = 'day3icon';
			div = doc.getElementById(name);
			div.children[0].style.cssText = 'pointer-events:none;width:' + iconwidth + 'px;' + 'height:' + iconwidth + 'px;';
			action.setCss(name, 'width', iconwidth+'px');
			action.setCss(name, 'height', iconwidth+'px');
			action.setCss(name, 'top', height / 2 - iconwidth / 2 + "px");
			action.setCss(name, 'left', "115px");

			name = 'day4icon';
			div = doc.getElementById(name);
			div.children[0].style.cssText = 'pointer-events:none;width:' + iconwidth + 'px;' + 'height:' + iconwidth + 'px;';
			action.setCss(name, 'width', iconwidth+'px');
			action.setCss(name, 'height', iconwidth+'px');
			action.setCss(name, 'top', height / 2 - iconwidth / 2 + "px");
			action.setCss(name, 'left', "165px");

		}
	}

	function createCreation(name){
		if(creations[name]){
			creations[name]();
		}
	}
    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.make = function(name) {
            createCreation(name);
        };
        return externalMethods;
    }
    window.creator = initExternalMethods();
}(window, document));