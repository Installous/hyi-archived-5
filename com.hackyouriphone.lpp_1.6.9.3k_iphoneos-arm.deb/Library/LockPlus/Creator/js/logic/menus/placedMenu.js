(function(window, doc) {

    function selectPlacedElement(name){
        /*
            if there is a selected item, unselect it.
        */
        if(action.selectedItem){
            deselectScreenElement(action.selectedItem, true);
        }
        action.selectedItem = name;
        $('#' + name).css('outline', '1px solid white');
        bottomMenu.toggle();
        $('#editDragger').css('display', 'block');
    }

    function loadPlacedElements(){
        var placedItems = action.savedElements.placedElements,
            placedObject = {
                name: 'placedItems',
            },
            element, innerHTML, elementDIV;

        for(element in placedItems){
            innerHTML = document.getElementById(element).innerHTML;

            if(innerHTML.includes('</div>')){
                innerHTML = "CUSTOM";
            }else if (innerHTML == ""){
                innerHTML = document.getElementById(element).style.width + " x " + document.getElementById(element).style.height;
            }

            innerHTML = "- " + String(innerHTML).slice(0,20);
            placedObject[element + "~" + innerHTML] = function(){
                console.log('placedMenu.js');
            } 
        }
        return placedObject;
    }

    function initExternalMethods(){
        var externalMethods = {};
        externalMethods.create = function(){
            var obj = loadPlacedElements();
            menuLayout.generateMenu({
        		dict: obj,
        		backAction: function(){
                    menuLayout.loadMainMenu();
        		},
        		clickAction: function(el){
                    selectPlacedElement(el.target.title.split('~')[0]);
        		}
        	});
        };
        externalMethods.selectItem = function(name){
            selectPlacedElement(name);
        };
        return externalMethods;
    }
    window.placedMenu = initExternalMethods();
}(window, document));

