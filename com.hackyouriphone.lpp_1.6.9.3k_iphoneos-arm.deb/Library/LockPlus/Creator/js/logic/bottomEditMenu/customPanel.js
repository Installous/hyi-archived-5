(function(window, doc) {
    var customPanels = {
        names: [],
        data: {}
    };

    //check array to see what numbers have been used.
    function getDivName(counter) {
        if (!counter) {
            counter = 0;
        }
        if (customPanels.names.length > 0) {
            if (customPanels.names.contains('customPanels' + counter)) {
                return getDivName(counter + 1);
            } else {
                return counter;
            }
        } else {
            return 0;
        }
    }

    function makeFirstPanel(number){
        var customName = 'customPanels' + getDivName();

            if(number){
                customName = 'customPanels' + number;
            }

            action.addtoScreen(customName, action.selectedItem);
            customPanels.names.push(customName);
            customPanels.data[customName] = [action.selectedItem];
            customVar = customName;
            //document.getElementById(customVar).style['data-vars'] = JSON.stringify(customPanels);
            action.savedElements.placedElements[customVar]['data-vars'] = customPanels.data[customVar];
            action.savedElements.placedElements[customVar]['data-name'] = customName;
            action.savedElements.placedElements[customVar]['width'] = '100px';
            action.savedElements.placedElements[customVar]['height'] = '200px';
            doc.getElementById(customName).style.width = '100px';
            doc.getElementById(customName).style.height = '200px';
            doc.getElementById(customName).setAttribute('data-title', customName);
            
            doc.getElementById(customName).className = 'customPanel';
            action.saveStorage();
            return customName;
    }

    function addToPanel(name){
        var elemen = null;
            //div.parentElement.removeChild(div);
            customPanels.data[name].push(action.selectedItem);
            customVar = name;
            action.savedElements.placedElements[customVar]['data-vars'] = customPanels.data[customVar];
           
            elemen = document.getElementById(action.selectedItem);
            elemen.style.top = 0;
            elemen.style.left = 0;
            action.savedElements.placedElements[elemen.id]['top'] = 0;
            action.savedElements.placedElements[elemen.id]['left'] = 0;
            
            action.saveStorage();
            //document.getElementById(customVar).style['data-vars'] = JSON.stringify(customPanels);
            document.getElementById(name).appendChild(document.getElementById(action.selectedItem));
    }

    function showcustomPanels() {
        if (document.getElementById('customDivMenu')) {
            return;
        }
        var customVar = null;
        if (customPanels.names.length > 0) {
            var div = document.createElement('div'),
                create,
                extra,
                close,
                remove;
            div.className = 'customDivMenu';
            div.id = 'customDivMenu';
            document.body.appendChild(div);
            for (var i = 0; i < customPanels.names.length; i++) {
                create = document.createElement('div');
                create.innerHTML = customPanels.names[i];
                create.style.color = "white";
                create.onclick = function() {
                    addToPanel(this.innerHTML)
                }
                div.appendChild(create);
            }
            extra = document.createElement('div');
            extra.innerHTML = "Add Panel";
            extra.style.color = "white";
            extra.onclick = function() {
                div.parentElement.removeChild(div);

                var customName = 'customPanel' + getDivName();
                action.addtoScreen(customName, action.selectedItem);
                customPanels.names.push(customName);
                customPanels.data[customName] = [action.selectedItem];
                customVar = customName;
                //document.getElementById(customVar).style['data-vars'] = JSON.stringify(customPanels);
                action.savedElements.placedElements[customVar]['data-vars'] = customPanels.data[customVar];
                action.savedElements.placedElements[customVar]['data-name'] = customName;
                //action.savedElements.placedElements[customVar]['data-name'] = customName;
                document.getElementById(customName).setAttribute('data-title', customName);
                document.getElementById(customName).className = 'customPanel';

                action.savedElements.placedElements[customVar]['width'] = '100px';
                action.savedElements.placedElements[customVar]['height'] = '200px';
                document.getElementById(customName).style.width = '100px';
                document.getElementById(customName).style.height = '200px';

                action.saveStorage();
            }
            remove = document.createElement('div');
            remove.innerHTML = "Remove From Panel";
            remove.style.color = "white";
            remove.onclick = function() {
                var parent = document.getElementById('screenElements');
                parent.appendChild(document.getElementById(action.selectedItem));
                Object.keys(customPanels.data).forEach(function(key){
                    var newArray = [];
                    if(customPanels.data[key].contains(action.selectedItem)){
                        for (var i = 0; i < customPanels.data[key].length; i++) {
                            if(customPanels.data[key][i] != action.selectedItem){
                                newArray.push(customPanels.data[key][i]);
                            }
                        }
                        customPanels.data[key] = newArray;
                        action.savedElements.placedElements[key]['data-vars'] = customPanels.data[key];
                        action.saveStorage();
                    }
                });
            }
            close = document.createElement('div');
            close.innerHTML = "Close Panel";
            close.style.color = "white";
            close.onclick = function() {
                div.parentElement.removeChild(div);
            }
            div.appendChild(extra);
            div.appendChild(remove);
            div.appendChild(close);
        } else {
            makeFirstPanel();
        }

    }


    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.show = function() {
            //alert('test');
            showcustomPanels();
        };
        externalMethods.makeFirstPanel = function(number) {
            return makeFirstPanel(number);
        };
        externalMethods.addToPanel = function(number) {
            addToPanel(number);
        };
        externalMethods.getCustomPanelObj = function() {
            return customPanels;
        };
        externalMethods.setCustomPanelObj = function(obj) {
            customPanels = obj;
        };
        externalMethods.clear = function() {
            customPanels = {
                names: [],
                data: {}
            };
        };
        return externalMethods;
    }
    window.customPanel = initExternalMethods();
}(window, document));