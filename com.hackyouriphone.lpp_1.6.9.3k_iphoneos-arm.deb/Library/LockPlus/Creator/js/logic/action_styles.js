/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/
/*global
  action,
  alert,
  constants,
  $
*/
/**
 * Handling of mutliple styles
 *
 *
 */

action.autoCenter = function () {
    action.setCss(action.selectedItem, 'left', '0');
    action.setCss(action.selectedItem, 'width', '320');
};
action.cgcolor = function (color, cssKey, div) {
    var selectedColorDIV = document.getElementById(action.selectedItem);

    if (color) {
        action.setCss(action.selectedItem, cssKey, color);
    } else {
        $("#" + div).spectrum({
            showInitial: true,
            maxSelectionSize: 66,
            localStorageKey: 'spectrum',
            showAlpha: true,
            showInput: true,
            preferredFormat: "rgba",
            showPalette: true,
            color: $('#' + this.selectedItem).css(cssKey),
            palette: []
        });
        setTimeout(function () {
            $('#' + div).spectrum('show');
        }, 0); //give it time to load.

        //this removes pressing cancel to cancel the color
        // $("#" + div).on('hide.spectrum', function (e, tinycolor) {
        //     action.cgcolor(tinycolor.toRgbString(), cssKey, div);
        // });
        
        $("#" + div).on('move.spectrum', function (e, tinycolor) {
            action.cgcolor(tinycolor.toRgbString(), cssKey, div);
        });
        $("#" + div).on('hide.spectrum', function (e, tinycolor) {
            $("#" + div).spectrum("destroy");
        });
    }
};
// action.cgStyle = function () {
//     var lastSelector = '#' + $('#' + action.selectedItem).css('font-style') + 'Option';
//     this.cgOption('style', constants.editArray[9], ['italic', 'oblique', 'initial'], 0, true, function (optionSelector) {
//         lastSelector = action.basicOptionSelected(optionSelector, lastSelector, 'font-style', $(optionSelector).attr('id').substring(0, $(optionSelector).attr('id').length - 6));
//     }, function (optionName) {
//         return action.getBasicOptionElement(optionName, 'text-align: center; font-style: ' + optionName, 'font-style');
//     });
// };
// action.cgBorderStyle = function () {
//     var lastSelector = '#' + $('#' + action.selectedItem).css('border-style') + 'Option';
//     this.cgOption('borderStyle', constants.borderArray[0], ['dotted', 'dashed', 'solid', 'double', 'groove', 'ridge', 'inset', 'outset'], 20, true, function (optionSelector) {
//         lastSelector = action.basicOptionSelected(optionSelector, lastSelector, 'border-style', $(optionSelector).attr('id').substring(0, $(optionSelector).attr('id').length - 6));
//     }, function (optionName) {
//         return action.getBasicOptionElement(optionName, 'text-align:center; font-size:15px;', 'border-style');
//     });
// };
