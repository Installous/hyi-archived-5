
/**
 * holds the array of fonts
 * Defines clock, weather, system, and misc elements
 * Loads after clock.js as it contains cF and convertTOWord
 */
function moveAllItems(style, move){
    Object.keys(action.savedElements.placedElements).forEach(function (key) {
        try {
            if (action.savedElements.placedElements[key][style]) {
                var top = action.savedElements.placedElements[key][style];
                action.savedElements.placedElements[key][style] = parseInt(move, 10) + parseInt(top, 10);
                document.getElementById(key).style[style] = parseInt(move, 10) + parseInt(top, 10) + "px";
            } else {
                action.savedElements.placedElements[key][style] = parseInt(move, 10);
                document.getElementById(key).style[style] = parseInt(move, 10) + "px";
            }
        } catch (err) {
            //alert(err + action.savedElements.placedElements[key]);
        }
        action.saveStorage();
    });
}

var fontArray = ['abeatbykai', 'adamasreg', 'android', 'aileronlight', 'aileronthin', 'aileronbold', 'aileronthick', 'aileronultra', 'aileronheavy', 'ailerons', 'akrobatblack', 'akrobatbold', 'akrobatexbold', 'akrobatlight', 'akrobatregular', 'akrobatsemibold', 'akrobatthin', 'akrobatxlight', 'allura', 'alpine', 'apriolight', 'aprioreg', 'anders', 'arista', 'autograf', 'avantgarde', 'aventura', 'azedobold', 'azedolight', 'back', 'bariollight', 'bariolthin', 'bariolbold', 'bikoblack', 'bikoregular', 'bikobold', 'bebasbold', 'bebaslight', 'bebasneue', 'bebasneueregular', 'blanch', 'breaksemi', 'braxton', 'building', 'canter', 'canarolight', 'captian', 'clemente', 'codebold', 'codelight', 'condlight', 'cooperhewiththin', 'cooperhewittbold', 'cooperhewittbook', 'cooperhewittlight', 'cooperhewittreg', 'crafted', 'cumulous', 'damier', 'din', 'dinerfat', 'disclaimerclassic', 'disclaimerreg', 'dense', 'earth', 'everafte', 'establo', 'fabfelt', 'feast', 'flow', 'freeky', 'fronte', 'futura', 'future', 'fringe', 'fortuna', 'geoma', 'gido', 'gasaltreg', 'gasaltthin', 'gasaltbold', 'globerreg', 'globerthin', 'geoman', 'goodvibes', 'gothicregular', 'gothicbold', 'hab', 'hallo', 'hanging', 'high', 'higher', 'huxlee', 'heygorgeous', 'ikaros', 'infinity', 'inkferno', 'jaapokki', 'jellyka', 'kanji', 'kaneda', 'king', 'krinkles', 'krinklesdecor', 'lcd', 'lg', 'lobster', 'lot', 'loveloblack', 'latoblack', 'latobold', 'latolight', 'latoreg', 'latothin', 'loveloline', 'lovelolinel', 'manbow', 'nexabold', 'nexabolder', 'nexalight', 'manifesto', 'manteka', 'makhina', 'masterofbreak', 'mikadolight', 'mikadoregular', 'mikadobold', 'mikadomedium', 'mikadoultra', 'mikadoblack', 'modernesans', 'moonlight', 'moonbold', 'moonshinerround', 'moonshinersharp', 'mohave', 'mostwasted', 'olympic', 'oswald', 'panama', 'penelope', 'perfo', 'plstk', 'poplar', 'provisionary', 'pushkin', 'quadrantabold', 'quadrantareg', 'qontra', 'ratinfested', 'reckoner', 'reboard', 'realtimethin', 'realtimelight', 'realtimeregular', 'realtimesemi', 'realtimebold', 'rexbold', 'roadrage', 'robotobold', 'robotolight', 'robotoregular', 'salamat', 'samster', 'samsunglight', 'samsungregular', 'samsungexlight', 'samsungreg', 'sanfranlight', 'sanfranthin', 'sanfranreg', 'sanfranbold', 'sanfranheavy', 'sciflysans', 'streamster', 'shimes', 'shimestwo', 'signer', 'scriptina', 'storopia', 'superair', 'talldark', 'timber', 'tiza', 'track', 'tresdias', 'wildyouth', 'zekton', 'zelda', 'entypo', 'mat1', 'mat2', 'mat3', 'mat4', 'mat5', 'webdev', 'Mountain'

    ],
    menuPanel = {
        name: "menuPanel",
        background: {
            name: "background",
            Camera_Roll: function() {
                action.uploadSelection= 'cgBackground';
                $('#bgInput').click();
            },
            Wallpaper_website: function() {
                location.href = "http://idevicewalls.com";
            },
            Photo_editor: function() {
                location.href = "https://doka.photo/";
            },
            clear_BG: function() {
                jPopup({
                    type: "confirm",
                    message: "Do you wish to clear the background?",
                    yesButtonText: "YES",
                    noButtonText: "NO",
                    functionOnNo: function() {},
                    functionOnOk: function() {
                        $('#wallpaper').attr('src', '');
                        $('#wallpaper').css('display', 'none');
                    }
                });
            },
            help: function() {
                jPopup({
                    type: "alert",
                    message: "The background option is only used when you are about to upload a theme. If you want a wallpaper included with your uploaded theme set it here before upload. Setting a background here does not apply it to your lockscreen. You apply wallpapers to the lockscreen via the stock settings. Settings> Wallpaper> Choose a new wallpaper> set to lockscreen",
                    yesButtonText: "OK",
                    functionOnOk: function() {
                        //do something on ok
                    }
                });
            }
        },
        overlay: {
            name: "overlay",
            Camera_Roll: function() {
                action.uploadSelection= 'cgOverlay';
                $('#bgInput').click();
            },
            Overlay_website: function() {
                location.href = "http://idevicewalls.com/index.php?category=overlays";
            },
            clear_Overlay: function() {
                jPopup({
                    type: "confirm",
                    message: "Do you wish to clear the overlay?",
                    yesButtonText: "YES",
                    noButtonText: "NO",
                    functionOnNo: function() {},
                    functionOnOk: function() {
                        $('.screenoverlay').css('background-image', '');
                        action.savedElements.overlay = '';
                        action.saveStorage();
                    }
                });
            },
            help: function() {
                jPopup({
                    type: "alert",
                    message: "Overlays are not moveable, but if you want to make a custom overlay go back to the main LockPlus menu, click tools, then make overlay. It will allow you to place multiple images and place them wherever you want. Once you save it use it as an overlay here.",
                    yesButtonText: "OK",
                    functionOnOk: function() {
                        //do something on ok
                    }
                });
            }
        },
        add_elements: function() {
            menuLayout.close();
            elementMenu.open();
            // menuLayout.setCurrentMenu = "";
        },
        // elements: function(){

        //     menuLayout.close();
        //     elementMenu.open();
        //     menuLayout.setCurrentMenu = "";
        // },
        placed_Elements: function() {
            menuLayout.close();
            placedMenu.create();
        },
        widgets: function() {
            menuLayout.close();
            jsWidgets.showWidgets();
        },
        add_font: {
            name: "add_font",
            select_font: function() {
                menuLayout.close();
                //action.addFont();
                addFontsMenu.create();
            },
            font_help: function() {
                jPopup({
                    type: "alert",
                    message: "A font with .otf extention and no spaces in the name can be placed in /Library/LockPlus/fonts once a font is put here press reload fonts, then select the font to use. It will then show in the fonts when stylig an element.",
                    yesButtonText: "OK",
                    functionOnOk: function() {
                        //do something on ok
                    }
                });
            }
        },
        move_all: {
            name: "move_all",
            add_Grabber: function() {
                var div = document.createElement('div'),
                    middleTop = screen.height / 2 - 50 + "px",
                    middleLeft = screen.width / 2 - 50 + "px";

                div.id = 'moveGrabber';
                div.style.top = middleTop
                div.style.left = middleLeft

                var y = null;
                var x = null;

                var counter = 0;

                var setnumber = 0;
                var setnumber2 = 0;

                document.body.appendChild(div);

                $(div).draggable({
                    axis: "",
                    start: function(event, ui) {

                    },
                    drag: function(event, ui) {
                        y = parseInt(middleTop, 10) - ui.position.top;
                        x = parseInt(middleLeft, 10) - ui.position.left;
                        if (setnumber) {
                            moveAllItems('top', setnumber - y);

                        }
                        if (setnumber2) {
                            moveAllItems('left', setnumber2 - x);
                        }
                        setnumber = y;
                        setnumber2 = x;
                    },
                    stop: function(event, ui) {
                        div.style.top = middleTop;
                        div.style.left = middleLeft;
                        setnumber = 0;
                        setnumber2 = 0;
                    },
                    create: function(event, ui) {

                    }
                });
            },
            remove_Grabber: function() {
                var moveGrabber = document.getElementById('moveGrabber');
                if (moveGrabber) {
                    document.body.removeChild(moveGrabber);
                }

            },
            move_Help: function() {
                jPopup({
                    type: "alert",
                    message: "Add a grabber and move it around the screen to move elements. You cannot move overlays, they are stationary.",
                    yesButtonText: "Ok",
                    functionOnOk: function() {
                        //do something on ok
                    }
                });
            }
        },
        // multi_select:function(){
        //     multiDragger.start();
        //     menuLayout.close();
        // },
        exporting: {
            name: "exporting",
            export_SBHTML: function() {
                jPopup({
                    type: "confirm",
                    message: "Do you wish to export this widget to XenHTML? It will be located in XenHTML when screen goes blank.",
                    yesButtonText: "Yes",
                    noButtonText: "No",
                    functionOnNo: function() {},
                    functionOnOk: function() {
                        if (mobilecheck()) {
                            window.location = "exportSBHTML";
                        }
                    }
                });
            },
            export_Widget: function() {
                jPopup({
                    type: "confirm",
                    message: "Do you wish to export this widget to XenHTML? It will be located in XenHTML when screen goes blank.",
                    yesButtonText: "Yes",
                    noButtonText: "No",
                    functionOnNo: function() {},
                    functionOnOk: function() {
                        if (mobilecheck()) {
                            window.location = "exportWidget";
                        }
                    }
                });
            },
            exporting_help: function() {
                jPopup({
                    type: "alert",
                    message: "If you are exporting a widget with touches exportWidget, otherwise exportSBHTML. Widget makes Widget.html with sizing, SBHTML will fit the screen.",
                    yesButtonText: "Ok",
                    functionOnOk: function() {
                        //do something on ok
                    }
                });
            }
        },
        settings:{
            name: "settings",
            reset_all: function(){
                 jPopup({
                    type: "confirm",
                    message: "You must reload the creator for changes to take. This will also reset the color picker.",
                    yesButtonText: "Reload Now",
                    noButtonText: "Cancel",
                    functionOnNo: function() {
                        //do something on no
                    },
                    functionOnOk: function() {
                        localStorage.creatorOptions = null;
                        localStorage.removeItem('spectrum');
                        location.href = "file:///Library/LockPlus/LockPlus/index.html"
                    }
                });
            },
            set_BGColor: function(){
                creatorOptions.showColorPickerForCreatorOptions('bgcolor');
            },
            set_CircleColor:function(){
                creatorOptions.showColorPickerForCreatorOptions('circlecolor');
            },
            circle_outside:function(){
                creatorOptions.showColorPickerForCreatorOptions('circleoutside');
            },
            MenuBarsColor: function(){
                creatorOptions.showColorPickerForCreatorOptions('menubarscolor');
            },
            MenuBarsTextColor: function(){
                creatorOptions.showColorPickerForCreatorOptions('menubarstextcolor');
            },
            MenuButtonColor: function(){
                creatorOptions.showColorPickerForCreatorOptions('menubuttoncolor');
            },
            MenuButtonTextColor: function(){
                creatorOptions.showColorPickerForCreatorOptions('menubuttontextcolor');
            }
        },
        clear_Screen: function() {
            jPopup({
                type: "confirm",
                message: "Do you wish to clear the screen?",
                yesButtonText: "Yes",
                noButtonText: "No",
                functionOnNo: function() {},
                functionOnOk: function() {
                    action.clearTheme(1);
                    customPanel.clear();
                }
            });
        },
        upload_theme: function() {
            jPopup({
                type: "confirm",
                message: "Upload this theme? Once uploaded you can then download it by name.",
                yesButtonText: "Yes",
                noButtonText: "No",
                functionOnNo: function() {},
                functionOnOk: function() {
                    menuLayout.close();
                    action.saveTheme();
                }
            });
        },
        exit_creator: function() {
            location.href = "file:///Library/LockPlus/LockPlus/index.html";
        }
    },
    elementPanel = {
        name: "elementPanel",
        clockElements: {
            name: "clockElements",
            time: {
                name: 'time',
                title: "Clocks",
                fullclock: cF.zhour() + ":" + cF.minute() + ":" + cF.second(),
                clock: cF.hour() + ":" + cF.minute(),
                zclock: cF.zhour() + ":" + cF.minute() + " (padded hour)",
                hour: cF.hour() + " (hour)",
                zhour: cF.zhour() + " (padded hour)",
                minute: cF.minute() + " (minute)",
                second: cF.second() + " (seconds)",
                clocksmush: cF.hour() + "" + cF.minute(),
                clocksmush1: cF.zhour() + "" + cF.minute() + " (padded)",
                clockline: cF.hour() + "|" + cF.minute(),
                clockdot: cF.hour() + "." + cF.minute(),
                clockdsh1: cF.zhour() + '-' + cF.minute() + " (padded)",
                clockdsh2: cF.hour() + '-' + cF.minute(),
                clockdot: cF.hour() + "." + cF.minute(),
                zclockdot: cF.zhour() + "." + cF.minute() + " (padded)",
                clockpm: cF.hour() + ":" + cF.minute() + cF.am() + " (Only shows am/pm on 12hr)",
                sclock: cF.hour() + ":" + cF.minute() + cF.ampmstrict() + " (always show am/pm)",
                sclockpadded: cF.zhour() + ":" + cF.minute() + cF.ampmstrict() + " (padded always show am/pm)",
                pm: cF.am() + " (am or pm)",
                amalways: cF.amalways() + " (am or pm always show)",
                timer: "00:00 (Clock Timer iOS10+)"
            },
            timeText: {
                name: 'timeText',
                title: "Time Text",
                htext: cF.hourtext() + " (hour text)",
                mtext: "o' clock" + " (minute text)",
                mtext2: "zero one & forty one",
                mtext3: "one & forty one",
                hrmin: cF.hourtext() + '.' + cF.minute(),
                hrnsmin: cF.hourtext() + ' ' + cF.minute(),
                hrsmush: cF.hourtext() + cF.minute(),
                hrmintx: (cF.minutetwotext() !== "") ? cF.hourtext() + '.' + cF.minuteonetextdot() + '.' + cF.minutetwotext() : cF.hourtext() + '.' + cF.minuteonetextdot() + cF.minutetwotext(),
                ttext: cF.hourtext() + " " + cF.minuteonetext() + ' ' + cF.minutetwotext(),
                min1: cF.minuteonetext() + " (Minute P1)",
                min2: cF.minutetwotext() + " (Minute P2)",
                min3: cF.minuteonetextNoSpace() + " (Minute No Space P1)",
                //ttextstr: cF.hourtext() + "" + cF.minuteonetext() + '' + cF.minutetwotext() + '<p style="text-transform:uppercase">' + cF.daytext() + '</p><p style="text-transform:lowercase">the' + cF.dateplus() + '</p>',

                nhrtmin: cF.hourtext() + ':' + cF.minute(),
                nhrtmin2: cF.zhour() + ':' + cF.minuteonetext() + ' ' + cF.minutetwotext(),
                nhrtmin3: cF.zhour() + ':' + cF.minuteonetextNoSpace() + ' ' + cF.minutetwotext(),
                nhrtarrowmin: cF.hourtext() + '>>' + cF.minute(),
                nttext: "[" + cF.hourtext() + "]" + cF.minuteonetext() + cF.minutetwotext(),
                nttext2: "(" + cF.hourtext() + ")" + cF.minuteonetext() + cF.minutetwotext(),
                tod: cF.tod() + " (time of day)",
                tod2: cF.tod2() + " (time of day - has night)",
                lngclstring: "It's " + cF.hour() + ":" + cF.minute() + " on " + cF.daytext().toLowerCase() + " the " + cF.dateplus()
            },
            dates: {
                name: 'dates',
                title: "Dates",
                date: cF.date() + " (Date)",
                datepad: cF.paddeddate() + " (Padded date)",
                
                datetext: cF.datetext(),
                dateplus: cF.dateplus(),
                datepadfirst: String(cF.paddeddate()).charAt(0) + " (Padded date first value)",
                datepadsecond: String(cF.paddeddate()).charAt(1) + " (Padded date second value)",
                daysleft: cF.daysLeft() + " ( days left in year)",
                daysleftpercent: cF.daysLeftPercentLeft() + " (year percent done)",
                daysleftpercent2: cF.daysLeftPercentToGo() + " (percent left in year)",
                prevdate: cF.prevdate() + " (yesterday's date)",
                nextdate: cF.nextdate() + " (tomorrow's date)",

                datemonthnum: cF.paddeddate() + '' + cF.monthdatepadded() + " (date/month)",
                monthnumdate: cF.monthdate() + '' + cF.paddeddate() + " (month/date)",
                timeslashdatemonth: cF.zhour() + cF.minute() + " / " + cF.paddeddate() + '' + cF.monthdatepadded() + " (time / datemonth)",
                timeslashmonthdate: cF.zhour() + cF.minute() + " / " + cF.monthdatepadded() + '' + cF.paddeddate() + " (time / monthdate)",
                monthdateslashtime: cF.monthdatepadded() + '' + cF.paddeddate()  + " / " + cF.zhour() + cF.minute() + " (monthdate / time)",
                datemonthslashtime: cF.paddeddate() + '' + cF.monthdatepadded() + " / " + cF.zhour() + cF.minute() + " (datemonth / time)",

                datebar: cF.monthdate() + '|' + cF.date() + '|' + cF.smyear(),
                datebar2: cF.date() + '|' + cF.monthdate() + '|' + cF.smyear(),
                datesnslash: cF.monthdate() + '/' + cF.date() + '/' + cF.smyear(),
                datesnslash2: cF.date() + '/' + cF.monthdate() + '/' + cF.smyear(),
                datesingled: cF.monthdate() + '-' + cF.date() + '-' + cF.smyear(),
                datesingled2: cF.date() + '-' + cF.monthdate() + '-' + cF.smyear(),
                mdy: cF.monthdate() + "/" + cF.date() + "/" + cF.year(),
                mdy2: cF.date() + "/" + cF.monthdate() + "/" + cF.year(),
                monthnumslashdatepad: cF.monthdate() + '/' + cF.paddeddate() + " (Padded date)",
                monthnumslashdate: cF.monthdate() + '/' + cF.date(),
                monthnumslashdatepad2: cF.monthdatepadded() + '/' + cF.paddeddate() + " (Full Padded)",
                monthnumslashdatepad3: cF.paddeddate() + '/' + cF.monthdatepadded() + " (Full Padded)",
                dateslashmonthpad: cF.paddeddate() + '/' + cF.monthdate() + " (Padded date)",
                dateslashmonthnumber: cF.date() + '/' + cF.monthdate(),
                dateliketime1: cF.paddeddate() + ':' + cF.monthdatepadded(),
                dateliketime2: cF.monthdatepadded() + ':' + cF.paddeddate(),
            },
            day: {
                name: 'day',
                title: "Day Text",
                day: cF.daytext(),
                sday: cF.sdaytext(),
                sday1: cF.sdaytext().slice(0, 1) + " (first letter of day)",
                sday2: cF.sdaytext().slice(1, 2) + " (second letter of day)",
                sday3: cF.sdaytext().slice(2, 3) + " (third letter of day)",
                daycut1: cF.daytext().substring(1) + " (cut first letter off)",
                daycut2: cF.daytext().substring(2) + " (cut first + second letter off)",
                daycut: cF.daytext().substring(3) + " (cut first 3 letters off day)",
                mday: cF.mdaytext() + " (day piece 'Wednes')",
                yestday: cF.yesterdaydaytext() + " (previous day)",
                sprevday: cF.sprevday() + " (previous day short)",
                nextday: cF.nextdaytext() + " (next day)",
                snextday: cF.snextday() + " (next day short)",
            },
            month: {
                name: 'month',
                title: "Month",
                monthD: cF.monthdate() + " (Month Number)",
                monthDPadded: cF.monthdatepadded() + " ( Padded)"
            },
            monthText: {
                name: 'monthText',
                title: "Month Text",
                month: cF.monthtext(),
                smonth: cF.smonthtext(),
                smonthsplit: cF.monthtext().substring(3) + ' (cut first 3 letters off month)',
                smonth1: cF.smonthtext().slice(0, 1) + " (first letter of month)",
                smonth2: cF.smonthtext().slice(1, 2) + " (second letter of month)",
                smonth3: cF.smonthtext().slice(2, 3) + " (third letter of month)",
                prevmonth: cF.prevmonthtext() + " (previous month)",
                sprevmonth: cF.sprevmonth() + " (previous month short)",
                nextmonth: cF.nextmonthtext() + " (next month)",
                snextmonth: cF.snextmonth() + " (next month short)",
            },
            year: {
                name: 'year',
                title: "Year",
                year: "" + cF.year(),
                yearnum: cF.year().toString().slice(2, 4) + " (year)",
                yeartext: convertTOWord(cF.year())
            },
            strings: {
                name: 'strings',
                title: "Strings",
                sdaymonthdate: cF.sdaytext() + ', ' + cF.monthtext() + ' ' + cF.paddeddate(),
                sdaydatemonth: cF.sdaytext() + ', ' + cF.paddeddate() + ' ' + cF.monthtext(),
                sdaymonthdateno: cF.sdaytext() + ' ' + cF.monthtext() + ' ' + cF.paddeddate(),
                sdaydatemonthno: cF.sdaytext() + ' ' + cF.paddeddate() + ' ' + cF.monthtext(),
                sdaymonth: cF.sdaytext() + ', ' + cF.monthtext(),

                dstring: cF.sdaytext() + ', ' + cF.smonthtext() + ' ' + cF.date(),
                dstringpad: cF.sdaytext() + ', ' + cF.smonthtext() + ' ' + cF.paddeddate(),
                nsmdd: cF.sdaytext() + " " + cF.date(),
                smdotdate: cF.smonthtext() + '.' + cF.date(),
                datesmdot: cF.date() + '.' + cF.smonthtext(),
                dateslashmonth: cF.date() + "/" + cF.monthtext(),
                monthslashdate: cF.monthtext() + "/" + cF.date(),
                datemonth: cF.date() + " " + cF.monthtext(),
                datemonthrev: cF.monthtext() + " " + cF.date(),
                fullmonthdotdate: cF.monthtext() + '.' + cF.date(),
                datedotmonthfull: cF.date() + '.' + cF.monthtext(),
                nsmmyear: cF.smonthtext() + " " + cF.year(),
                nmdplusyear: cF.monthtext() + " " + cF.dateplus() + " " + cF.year(),
                datemonthyear: cF.date() + ' ' + cF.monthtext() + ', ' + cF.year(),
                prevdaystrings: cF.yesterdaydaytext() + ' ' + cF.monthtext() + ' ' + cF.prevdate(),
                todaystrings: cF.daytext() + ' ' + cF.monthtext() + ' ' + cF.date(),
                nextdaystrings: cF.nextdaytext() + ' ' + cF.monthtext() + ' ' + cF.nextdate(),
                dateplusof: cF.dateplus() + " of " + cF.monthtext(),
                dateplusplusof: cF.daytext() + ", " + cF.dateplus() + " of " + cF.monthtext(),
                datestring: cF.daytext() + ", " + cF.monthtext() + " " + cF.date(),
                datedash: cF.daytext() + "-" + cF.monthtext() + "-" + cF.date(),
                datespace: cF.daytext() + " " + cF.monthtext() + " " + cF.date(),
                ndatedash: cF.daytext() + " - " + cF.monthtext() + " - " + cF.date(),
                monthdateyear: cF.monthtext() + " " + cF.date() + ", " + cF.year(),
                daydatesmonth: cF.daytext() + ' ' + cF.date() + ' ' + cF.smonthtext(),
                daydatescommamonth: cF.daytext() + ', ' + cF.date() + ' ' + cF.smonthtext(),
                monthlinespace: cF.monthtext() + " | " + cF.date() + " | " + cF.year(),
                monthline: cF.monthtext() + "|" + cF.date() + "|" + cF.year(),
                monthdayyear: cF.monthtext() + " " + cF.date() + " " + cF.year(),
                datestringrev: cF.monthtext() + " " + cF.date() + ", " + cF.daytext(),
                datedotmonth: cF.date() + '.' + cF.monthtext(),
                monthdot: cF.monthtext() + "." + cF.date(),
                daydatemonth: cF.daytext() + " | " + cF.date() + " " + cF.monthtext(),
                daydatemonth2: cF.date() + " " + cF.monthtext() + " | " + cF.daytext(),
                dayabdatemonth: cF.sdaytext() + ' ' + cF.date() + ' ' + cF.smonthtext(),
                daycommadatemonth: cF.sdaytext() + ', ' + cF.date() + ' ' + cF.smonthtext(),
                daydate: cF.daytext() + " " + cF.date(),
                daydotdate: cF.daytext() + "." + cF.date(),
                nsmd: cF.smonthtext() + " " + cF.date(),
                ndsm: cF.date() + " " + cF.smonthtext(),
                ndsm2: cF.paddeddate() + " " + cF.smonthtext(),
                ndsm3: cF.smonthtext() + " " + cF.paddeddate(),
                ndsm4: cF.sdaytext() + " " + cF.paddeddate(),
                ndsmd: cF.date() + " " + cF.sdaytext(),
                datedotsmonth: cF.date() + '.' + cF.sdaytext(),
                datedotsmonthpad: cF.paddeddate() + '.' + cF.sdaytext(),
                smonthdotdate: cF.sdaytext() + '.' + cF.date(),
                smonthdotdatepad: cF.sdaytext() + '.' + cF.paddeddate(),
            }
        },
        weatherElements: {
            name: 'weatherElements',
            wstring: {
                name: 'wstring',
                title: "String",
                tempcon: "76 Cloudy",
                tempcon1: "76°f Cloudy",
                tempcon2: "76° Cloudy",
                contemp: "Cloudy 76°",
                contemp2: "Cloudy 76°f",
                windstr: "25mph N",
                medwstring: "Cloudy &amp; 76&deg;",
                lngwstring: "It's cloudy outside and the temp is around 35&deg;.",
                lngwstring2: "Currently it's 35&deg; outside.",
                lngwstring3: "Currently it's cloudy, the high today will reach 60&deg; </br> Right now it's 90&deg; and your battery is 50%",
                lngwstring4: "It could be cloudy and 50&deg; but who really knows. </br> What I can tell you is your battery is 50%:)",
                lngwstring5: "The current temperature is 90&deg;, it's cloudy with a wind speed of 30mph. </br> Your battery is at 90% and is charging.",
            },
            temps: {
                name: 'temps',
                title: "Temp",
                temp: "76",
                tempdeg: "76°",
                tempdegplus: "76°f"
            },
            icon: {
                name: 'icon',
                title: "Icon",
                icon: "Weather",
                coloricon: 'Color Icon'
            },
            forecast: {
                name: 'forecast',
                title: "Forecast",

                day1day: "Day1 Day Mon",
                day1icon: "Day1 Icon",
                day1lohigh: "Day1 75°/50°",
                day1high: "Day1 High 75°",
                day1low: "Day1 Low 50°",
                day1highno: "Day1 High 75",
                day1lowno: "Day1 Low 50",

                day2day: "Day2 Day Tue",
                day2icon: "Day2 Icon",
                day2lohigh: "Day2 75°/50°",
                day2high: "Day2 High 75°",
                day2low: "Day2 Low 50°",
                day2highno: "Day2 High 75",
                day2lowno: "Day2 Low 50",

                day3day: "Day3 Day Wed",
                day3icon: "Day3 Icon",
                day3lohigh: "Day3 75°/50°",
                day3high: "Day3 High 75°",
                day3low: "Day3 Low 50°",
                day3highno: "Day3 High 75",
                day3lowno: "Day3 Low 50",

                day4day: "Day4 Day Thu",
                day4icon: "Day4 Icon",
                day4lohigh: "Day4 75°/50°",
                day4high: "Day4 High 75°",
                day4low: "Day4 Low 50°",
                day4highno: "Day4 High 75",
                day4lowno: "Day4 Low 50",

                day5day: "Day5 Day Fri",
                day5icon: "Day5 Icon",
                day5lohigh: "Day5 75°/50°",
                day5high: "Day5 High 75°",
                day5low: "Day5 Low 50°",
                day5highno: "Day5 High 75",
                day5lowno: "Day5 Low 50",
            },
            highs: {
                name: 'highs',
                title: "High",
                high: "80",
                highdeg: "80°",
                highdegplus: "80°f"
            },
            lows: {
                name: 'lows',
                title: "Low",
                low: "70",
                lowdeg: "70°",
                lowdegplus: "70°f"
            },
            lowhigh: {
                name: 'lowhigh',
                title: "High and Low",
                highdashlow: "80-70",
                highdashlowdeg: "80°-70°",
                highslashlow: "80/70",
                highslashlowdeg: "80°/70°"
            },
            city: {
                name: 'city',
                title: "City",
                city: "Current City"
            },
            condition: {
                name: 'condition',
                title: "Condition",
                condition: "Cloudy"
            },
            humidity: {
                name: 'humidity',
                title: "Humidity",
                humidity: "60"
            },
            windchill: {
                name: 'windchill',
                title: "Wind Chill",
                windchill: "20°"
            },
            wind: {
                name: 'wind',
                title: "Wind",
                wind: "25mph",
                winddirection: "N"
            },
            visibility: {
                name: 'visibility',
                title: "Visibility",
                visibility: "20miles"
            },
            rain: {
                name: 'rain',
                title: "Rain",
                rain: "20%"
            },
            dewpoint: {
                name: 'dewpoint',
                title: "Dewpoint",
                dewpoint: "40°"
            },
            feelslike: {
                name: 'feelslike',
                title: "FeelsLike",
                feelslike: "90",
                feelslikedeg: "90°"
            },
            suntime: {
                name: 'suntime',
                title: "Sun",
                sunrise: "5:00 (sunrise)",
                sunset: "7:00 (sunset)"
            },
            update: {
                name: 'update',
                title: "Last Updated",
                update: "Last Updated"
            }

        },
        systemElements: {
            name: 'systemElements',
            phone_name: {
                name: 'phone_name',
                title: "phone_name",
                phonename: "iPhone Name",
                phonename2: 'Hello, Name',
            },
            firmware: {
                name: 'firmware',
                title: "Firmware",
                firmware: "Version 8.3"
            },
            ipaddress: {
                name: 'ipaddress',
                title: "iPAddress",
                ipaddress: "192.168.x.x"
            },
            battery: {
                name: 'battery',
                title: "Battery",
                battery: "100",
                batterypercent: "100%",
                batteryperslashcharge: "80% / charging",
                chargingtxt: "Not Charging",
                chargingstate: "Charging",
                onlycharging: "Charging (only charging)"
            },
            memory: {
                name: 'memory',
                title: "Memory",
                ramFree: "700 (Free)",
                ramUsed: "100 (Used)",
                ramAvailable: "800 (Available)",
                ramFreeMB: "700mb (Free)",
                ramUsedMB: "100mb (Used)",
                ramAvailableMB: "800mb (Available)"
            },
            unlock: {
                name: 'unlock',
                title: "Unlock",
                unlock: "Unlock"
            },
            respring: {
                name: 'respring',
                title: "Respring",
                respring: "Respring"
            },
            sleep: {
                name: 'sleep',
                title: "Sleep",
                sleep: "Sleep"
            },
            flashlight: {
                name: 'flashlight',
                title: "Flashlight",
                flashlight: "Flashlight"
            },
            music: {
                name: 'music',
                title: "Music",
                playmusic: "Play (no hide)",
                nextmusic: "Next (no hide)",
                prevmusic: "Previous (no hide)",
                playmusichide: "Play (auto hide)",
                nextmusichide: "Next (auto hide)",
                prevmusichide: "Previous (auto hide)",
                songtitle: "Song Title (auto hide)",
                songartist: 'Song Artist (auto hide)',
                songalbum: 'Song Album (auto hide)',
                songalbumArt: 'Song Artwork (auto hide)',
                songtitlenohide: "Song Title (no hide)",
                songartistnohide: 'Song Artist (no hide)',
                songalbumnohide: 'Song Album (no hide)',
                songalbumArtnohide: 'Song Artwork (no hide)'
            },
            search: {
                name: 'search',
                title: "Search",
                searchicon: "Search Icon",
                searchtext: "Search Text"
            },
            signal: {
                name: 'signal',
                title: "Signal",
                signal: "3",
                signalpercent: "40%"
            },
            alarm: {
                name: 'alarm',
                title: "Alarm",
                alarm24: "10:30 AM",
                alarmstring: "Tue 10:30 AM",
                alarmstringsmall: "Tue 10:30",
                alarm: "8:00",
                alarmhr: "8",
                alarmmin: "30",
                alarmday: "Tuesday",
                alarmsday: "Tue"
            },
            wifi: {
                name: 'wifi',
                title: "Wifi",
                wifi: "20",
                wifipercent: "20%"
            },
            notifications: {
                name: 'notifications',
                title: "Notifications",
                notifymail: "Mail",
                notifysms: "SMS",
                notifyphone: "Phone",
                notifywhats: "WhatsApp",
                notifytelegram: "Telegram",
                notifytelegramx: "TelegramX",
                notifyfbmessenger: "FBMessenger",
                notifydiscord: "Discord",
                notifyviber: "Viber",
                notifyinstagram: "Instagram",
                notifyfacebook: "Facebook",
                notifygmail: "Gmail",
                notifyoutlook: "Outlook",
                notifyairmail: "AirMail",
                notifyymail: "YMail",
                notifysnapchat: "SnapChat",
                notifyreddit: "Reddit",
                notifygoogleplus: "GooglePlus",
                notifylinkedin: "LinkedIn",
                notifyslack: "Slack",
                notifyspark: "Spark",
                notifydiscord: "Discord",
                notifytwitter: "Twitter",
                notifytweetbot: "Tweetbot",
                notifyyoutube: "YouTube",
            }
        },
        symbols: {
            name: "symbols",
            html_symbols: {
                name: 'html_symbols',
                title: 'html_symbols',
                sy1: '⦿',
                sy2: '◉',
                sy3: '○',
                sy4: '◌',
                sy5: '◎',
                sy6: '●',
                sy7: '◔',
                sy8: '◯',
                sy9: '〇',
                sy10: '⊕',
                sy11: '⊖',
                sy12: '⊘',
                sy13: '❝',
                sy14: '❞',
                sy15: '♛',
                sy16: '☾',
                sy17: '﹏',
                sy18: '︴',
                sy19: '☰',
                sy20: '▸',
                sy21: '▾',
                sy22: '⎔',
                sy23: '',
                sy24: '⍝',
                sy25: '⌘',
                sy26: '⌥',
                sy27: '⍋',
                sy28: '✖',
                sy29: '❜',
                sy30: '❛',
                sy31: '▦',
                sy32: '❀',
                sy33: '⋆',
                sy34: '™',
                sy35: '⊛',
                sy36: '◐',
                sy37: '◑',
                sy38: '﹄',
                sy39: '﹃',
                sy40: '〣',
                sy41: '㋡',
                sy42: 'ッ',
                sy43: '✘',
                sy44: '❤',
                sy45: '⤻',
                sy46: '⬏',
                sy47: '☽',
                sy48: '☾',
                sy49: '♪',
                sy50: '〈',
                sy51: '〉',
                sy52: '✹',
                sy53: '☂',
            },
            fonts:{
                name: 'fonts',
                title: 'fonts',

                ft1_entypoF: 'A',
                ft2_entypoF: 'B',
                ft3_entypoF: 'C',
                ft4_entypoF: 'D',
                ft5_entypoF: 'E',
                ft6_entypoF: 'F',
                ft7_entypoF: 'G',
                ft8_entypoF: 'H',
                ft9_entypoF: 'I',
                ft10_entypoF: 'J',
                ft11_entypoF: 'K',
                ft12_entypoF: 'L',
                ft13_entypoF: 'M',
                ft14_entypoF: 'N',
                ft15_entypoF: 'O',
                ft16_entypoF: 'P',
                ft17_entypoF: 'Q',
                ft18_entypoF: 'R',
                ft19_entypoF: 'S',
                ft20_entypoF: 'T',
                ft21_entypoF: 'U',
                ft22_entypoF: 'V',
                ft23_entypoF: 'W',
                ft24_entypoF: 'X',
                ft25_entypoF: 'Y',
                ft26_entypoF: 'Z',
                ft27_entypoF: 'a',
                ft28_entypoF: 'b',
                ft29_entypoF: 'c',
                ft30_entypoF: 'd',
                ft31_entypoF: 'e',
                ft32_entypoF: 'f',
                ft33_entypoF: 'g',
                ft34_entypoF: 'h',
                ft35_entypoF: 'i',
                ft36_entypoF: 'j',
                ft37_entypoF: 'k',
                ft38_entypoF: 'l',
                ft39_entypoF: 'm',
                ft40_entypoF: 'n',
                ft41_entypoF: 'o',
                ft42_entypoF: 'p',
                ft43_entypoF: 'q',
                ft44_entypoF: 'r',
                ft45_entypoF: 's',
                ft46_entypoF: 't',
                ft47_entypoF: 'u',
                ft48_entypoF: 'v',
                ft49_entypoF: 'w',
                ft50_entypoF: 'x',
                ft51_entypoF: 'y',
                ft52_entypoF: 'z',
                ft53_entypoF: '0',
                ft54_entypoF: '1',
                ft55_entypoF: '2',
                ft56_entypoF: '3',
                ft57_entypoF: '4',
                ft58_entypoF: '5',
                ft59_entypoF: '6',
                ft60_entypoF: '7',
                ft61_entypoF: '8',
                ft62_entypoF: '9',

                ft1_mashup: 'A',
                ft2_mashup: 'B',
                ft3_mashup: 'C',
                ft4_mashup: 'D',
                ft5_mashup: 'E',
                ft6_mashup: 'F',
                ft7_mashup: 'G',
                ft8_mashup: 'H',
                ft9_mashup: 'I',
                ft10_mashup: 'J',
                ft11_mashup: 'K',
                ft12_mashup: 'L',
                ft13_mashup: 'M',
                ft14_mashup: 'N',
                ft15_mashup: 'O',
                ft16_mashup: 'P',
                ft17_mashup: 'Q',
                ft18_mashup: 'R',
                ft19_mashup: 'S',
                ft20_mashup: 'T',
                ft21_mashup: 'U',
                ft22_mashup: 'V',
                ft23_mashup: 'W',
                ft24_mashup: 'X',
                ft25_mashup: 'Y',
                ft26_mashup: 'Z',
                ft27_mashup: 'a',
                ft28_mashup: 'b',
                ft29_mashup: 'c',
                ft30_mashup: 'd',
                ft31_mashup: 'e',
                ft32_mashup: 'f',
                ft33_mashup: 'g',
                ft34_mashup: 'h',
                ft35_mashup: 'i',
                ft36_mashup: 'j',
                ft37_mashup: 'k',
                ft38_mashup: 'l',
                ft39_mashup: 'm',
                ft40_mashup: 'n',
                ft41_mashup: 'o',
                ft42_mashup: 'p',
                ft43_mashup: 'q',
                ft44_mashup: 'r',
                ft45_mashup: 's',
                ft46_mashup: 't',
                ft47_mashup: 'u',
                ft48_mashup: 'v',
                ft49_mashup: 'w',
                ft50_mashup: 'x',
                ft51_mashup: 'y',
                ft52_mashup: 'z',
                ft53_mashup: '0',
                ft54_mashup: '1',
                ft55_mashup: '2',
                ft56_mashup: '3',
                ft57_mashup: '4',
                ft58_mashup: '5',
                ft59_mashup: '6',
                ft60_mashup: '7',
                ft61_mashup: '8',
                ft62_mashup: '9',

                ft1_mat2F: 'A',
                ft2_mat2F: 'B',
                ft3_mat2F: 'C',
                ft4_mat2F: 'D',
                ft5_mat2F: 'E',
                ft6_mat2F: 'F',
                ft7_mat2F: 'G',
                ft8_mat2F: 'H',
                ft9_mat2F: 'I',
                ft10_mat2F: 'J',
                ft11_mat2F: 'K',
                ft12_mat2F: 'L',
                ft13_mat2F: 'M',
                ft14_mat2F: 'N',
                ft15_mat2F: 'O',
                ft16_mat2F: 'P',
                ft17_mat2F: 'Q',
                ft18_mat2F: 'R',
                ft19_mat2F: 'S',
                ft20_mat2F: 'T',
                ft27_mat2F: 'a',
                ft28_mat2F: 'b',
                ft29_mat2F: 'c',
                ft30_mat2F: 'd',
                ft31_mat2F: 'e',
                ft32_mat2F: 'f',
                ft33_mat2F: 'g',
                ft34_mat2F: 'h',
                ft35_mat2F: 'i',
                ft36_mat2F: 'j',
                ft37_mat2F: 'k',
                ft38_mat2F: 'l',
                ft39_mat2F: 'm',
                ft40_mat2F: 'n',
                ft41_mat2F: 'o',
                ft42_mat2F: 'p',
                ft43_mat2F: 'q',
                ft44_mat2F: 'r',
                ft45_mat2F: 's',
                ft46_mat2F: 't',

                ft1_mat4F: 'A',
                ft2_mat4F: 'B',
                ft3_mat4F: 'C',
                ft4_mat4F: 'D',
                ft5_mat4F: 'E',
                ft6_mat4F: 'F',
                ft7_mat4F: 'G',
                ft8_mat4F: 'H',
                ft9_mat4F: 'I',
                ft10_mat4F: 'J',
                ft11_mat4F: 'K',
                ft12_mat4F: 'L',
                ft13_mat4F: 'M',
                ft14_mat4F: 'N',
                ft15_mat4F: 'O',
                ft16_mat4F: 'P',
                ft17_mat4F: 'Q',
                ft18_mat4F: 'R',
                ft19_mat4F: 'S',
                ft20_mat4F: 'T',
                ft21_mat4F: 'U',
                ft22_mat4F: 'V',
                ft23_mat4F: 'W',
                ft24_mat4F: 'X',
                ft25_mat4F: 'Y',
                ft26_mat4F: 'Z',
                ft27_mat4F: 'a',
                ft28_mat4F: 'b',
                ft29_mat4F: 'c',
                ft30_mat4F: 'd',
                ft31_mat4F: 'e',
                ft32_mat4F: 'f',
                ft33_mat4F: 'g',
                ft34_mat4F: 'h',
                ft35_mat4F: 'i',
                ft36_mat4F: 'j',
                ft37_mat4F: 'k',
                ft38_mat4F: 'l',
                ft39_mat4F: 'm',
                ft40_mat4F: 'n',
                ft41_mat4F: 'o',
                ft42_mat4F: 'p',
                ft43_mat4F: 'q',
                ft44_mat4F: 'r',
                ft45_mat4F: 's',
                ft46_mat4F: 't',
                ft47_mat4F: 'u',
                ft48_mat4F: 'v',
                ft49_mat4F: 'w',
                ft50_mat4F: 'x',
                ft51_mat4F: 'y',
                ft52_mat4F: 'z',
                ft53_mat4F: '0',
                ft54_mat4F: '1',
                ft55_mat4F: '2',
                ft56_mat4F: '3',
                ft57_mat4F: '4',
                ft58_mat4F: '5',
                ft59_mat4F: '6',
                ft60_mat4F: '7',
                ft61_mat4F: '8',
                ft62_mat4F: '9',

                ft1_mat5F: 'A',
                ft2_mat5F: 'B',
                ft3_mat5F: 'C',
                ft4_mat5F: 'D',
                ft5_mat5F: 'E',
                ft6_mat5F: 'F',
                ft7_mat5F: 'G',
                ft8_mat5F: 'H',
                ft9_mat5F: 'I',
                ft10_mat5F: 'J',
                ft11_mat5F: 'K',
                ft12_mat5F: 'L',
                ft13_mat5F: 'M',
                ft14_mat5F: 'N',
                ft15_mat5F: 'O',
                ft16_mat5F: 'P',
                ft17_mat5F: 'Q',
                ft18_mat5F: 'R',
                ft19_mat5F: 'S',
                ft20_mat5F: 'T',
                ft21_mat5F: 'U',
                ft22_mat5F: 'V',
                ft23_mat5F: 'W',
                ft24_mat5F: 'X',
                ft25_mat5F: 'Y',
                ft26_mat5F: 'Z',
                ft27_mat5F: 'a',
                ft28_mat5F: 'b',
                ft29_mat5F: 'c',
                ft30_mat5F: 'd',
                ft31_mat5F: 'e',
                ft32_mat5F: 'f',
                ft33_mat5F: 'g',
                ft34_mat5F: 'h',
                ft35_mat5F: 'i',
                ft36_mat5F: 'j',
                ft37_mat5F: 'k',
                ft38_mat5F: 'l',
                ft39_mat5F: 'm',
                ft40_mat5F: 'n',
                ft41_mat5F: 'o',
                ft42_mat5F: 'p',
                ft43_mat5F: 'q',
                ft44_mat5F: 'r',
                ft45_mat5F: 's',
                ft46_mat5F: 't',
                ft47_mat5F: 'u',
                ft48_mat5F: 'v',
                ft49_mat5F: 'w',
                ft50_mat5F: 'x',
                ft51_mat5F: 'y',
                ft52_mat5F: 'z',
                ft53_mat5F: '0',
                ft54_mat5F: '1',
                ft55_mat5F: '2',
                ft56_mat5F: '3',
                ft57_mat5F: '4',
                ft58_mat5F: '5',
                ft59_mat5F: '6',
                ft60_mat5F: '7',
                ft61_mat5F: '8',
                ft62_mat5F: '9',
            }

        },
        miscElements: {
            name: 'miscElements',
            hue: {
                name: 'hue',
                title: "Hue Widget",
                hueLights: "Lights",
                hueGroups: "Groups"
            },
            avatar: {
                name: 'avatar',
                title: "Avatar",
                avatarImage: "Image (set in tools)"
            },
            rss: {
                name: "rss",
                title: "RSS-Quote",
                quote1: "quote1",
                quote1Artist: "quote1Artist"
            },
            text: {
                name: "text",
                title: "Text Elements",
                textOne: "Custom Text 1",
                textTwo: "Custom Text 2",
                textThree: "Custom Text 3",
                textFour: "Custom Text 4",
                textFive: "Custom Text 5",
                textSix: "Custom Text 6",
                textSeven: "Custom Text 7",
                textEight: "Custom Text 8",
                textNine: "Custom Text 9",
                textTen: "Custom Text 10",
                textEleven: "Custom Text 11",
                textTwelve: "Custom Text 12",
                textThirteen: "Custom Text 13",
                textFourteen: "Custom Text 14",
                textFifteen: "Custom Text 15",
                textSixteen: "Custom Text 16",
                textSeventeen: "Custom Text 17",
                textEighteen: "Custom Text 18",
                textNineteen: "Custom Text 19",
                textTwenty: "Custom Text 20",
                textTwentyOne: "Custom Text 21"
            },
            box: {
                name: "box",
                title: "Squares",
                boxOne: "Custom Box 1",
                boxTwo: "Custom Box 2",
                boxThree: "Custom Box 3",
                boxFour: "Custom Box 4",
                boxFive: "Custom Box 5",
                boxSix: "Custom Box 6",
                boxSeven: "Custom Box 7",
                boxEight: "Custom Box 8",
                boxNine: "Custom Box 9",
                boxTen: "Custom Box 10",
                boxEleven: "Custom Box 11",
                boxTwelve: "Custom Box 12",
                boxThirteen: "Custom Box 13",
                boxFourteen: "Custom Box 14",
                boxFifteen: "Custom Box 15",
                boxSixteen: "Custom Box 16",
                boxSeventeen: "Custom Box 17",
                boxEighteen: "Custom Box 18",
                boxNineteen: "Custom Box 19",
                boxTwenty: "Custom Box 20",
                boxAutoHideOne: "Music Hide Box 1",
                boxAutoHideTwo: "Music Hide Box 2",
                boxAutoHideThree: "Music Hide Box 3",
                boxAutoHideFour: "Music Hide Box 4",
                boxAutoHideFive: "Music Hide Box 5",
                boxAutoHideSix: "Music Hide Box 6"
            },
            circle: {
                name: "circle",
                title: "Circles",
                boxCircleOne: "Custom Circle 1",
                boxCircleTwo: "Custom Circle 2",
                boxCircleThree: "Custom Circle 3",
                boxCircleFour: "Custom Circle 4",
                boxCircleFive: "Custom Circle 5",
                boxCircleSix: "Custom Circle 6",
                boxCircleSeven: "Custom Circle 7",
                boxCircleEight: "Custom Circle 8",
                boxCircleNine: "Custom Circle 9",
                boxCircleTen: "Custom Circle 10",
                boxCircleEleven: "Custom Circle 11",
                boxCircleTwelve: "Custom Circle 12",
                boxCircleThirteen: "Custom Circle 13",
                boxCircleFourteen: "Custom Circle 14",
                boxCircleFifteen: "Custom Circle 15",
                boxCircleSixteen: "Custom Circle 16",
                boxCircleSeventeen: "Custom Circle 17",
                boxCircleEighteen: "Custom Circle 18",
                boxCircleNineteen: "Custom Circle 19",
                boxCircleTwenty: "Custom Circle 20",
                boxCircleAutoHideOne: "Music Hide Circle 1",
                boxCircleAutoHideTwo: "Music Hide Circle 2",
                boxCircleAutoHideThree: "Music Hide Circle 3",
                boxCircleAutoHideFour: "Music Hide Circle 4",
                boxCircleAutoHideFive: "Music Hide Circle 5",
                boxCircleAutoHideSix: "Music Hide Circle 6"
            },
            triangle: {
                name: "triangle",
                title: "Triangles",
                triAngleOne: "Custom Triangle 1",
                triAngleTwo: "Custom Triangle 2",
                triAngleThree: "Custom Triangle 3",
                triAngleFour: "Custom Triangle 4",
                triAngleFive: "Custom Triangle 5",
                triAngleSix: "Custom Triangle 6",
                triAngleSeven: "Custom Triangle 7",
                triAngleEight: "Custom Triangle 8",
                triAngleNine: "Custom Triangle 9",
                triAngleTen: "Custom Triangle 10",
                triAngleEleven: "Custom Triangle 11",
                triAngleTwelve: "Custom Triangle 12",
                triAngleThirteen: "Custom Triangle 13",
                triAngleFourteen: "Custom Triangle 14",
                triAngleFifteen: "Custom Triangle 15",
                triAngleSixteen: "Custom Triangle 16",
                triAngleSeventeen: "Custom Triangle 17",
                triAngleEighteen: "Custom Triangle 18",
                triAngleNineteen: "Custom Triangle 19",
                triAngleTwenty: "Custom Triangle 20"
            },
            apps: {
                name: "apps",
                title: "Apps 1",
                app1: "Mail",
                app2: "SMS",
                app3: "Phone",
                app4: "Twitter",
                app5: "Tweetbot",
                app6: "Telegram"
            },
            apps2: {
                name: "apps2",
                title: "Apps 2",
                app7: "Instagram",
                app8: "Pandora",
                app9: "Spotify",
                app10: "Facebook",
                app11: "Kik",
                app12: "YouTube"
            },
            apps3: {
                name: "apps3",
                title: "Apps 3",
                app13: "WhatsApp",
                app14: "Safari",
                app15: "Weather",
                app16: "Clock",
                app17: "Music",
                app18: "Camera"
            },
            apps4: {
                name: "apps4",
                title: "Apps 4",
                app19: "Reminders",
                app20: "Notes",
                app21: "Maps",
                app22: "Calendar",
                app23: "Calculator",
                app24: "Cydia"
            },
            apps5: {
                name: "apps5",
                title: "Apps 5",
                app25: "YouTube",
                app26: "Settings",
                app27: "AppStore",
                app28: "Health",
                app29: "TelegramHD"
            },
            apps6: {
                name: "apps6",
                title: "Apps 6",
                app30: "Discord"
            }
        },
        templates: {
            name: 'templates',
            MusicControls: function(){
                creator.make('MusicControls');
            },
            ForecastIcons: function(){
                creator.make('ForecastIcons');
            }
        }

    };