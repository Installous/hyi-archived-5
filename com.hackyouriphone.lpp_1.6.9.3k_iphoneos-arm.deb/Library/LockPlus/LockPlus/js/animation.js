/* 

    Animations
    fsAnimation.checkAnimations is called by the tweak. It will pass info from settings
    letting the function know which animations are enabled.

*/

var fsAnimations = {
  rain: ['rain.html', 'rainwclouds.html', 'rainangleright.html', 'rainangleleft.html'],
  clouds: ['clouds.html', 'clouds2.html', 'clouds3.html', 'clouds4.html'],
  sun: ['sun.html'],
  snow: ['snow.html', 'snow1.html'],
  moon: ['moon.html'],
  thunderstorm: ['thunderstorm.html', 'thunderstormwclouds.html'],
  weather: false,
  birds: false,
  mp4: false,
  space: false,
  fireflies: false,
  spaceroad: false,
  spiral: false,
  globe: false,
  gif: false,
  createFrame: function(id, url, width) {
    var frame = document.createElement('iframe');
        frame.frameBorder = 0;
        frame.width = width;
        frame.height = screen.height;
        frame.style.pointerEvents = "none";
        frame.id = id;
        document.body.appendChild(frame);
        setTimeout(function(){
          frame.setAttribute("src", url);
        }, 0);
  },
  getRandomURL: function(type) {
    var random = Math.floor(Math.random() * type.length);
        return type[random];
  },
  getWeatherURL: function() {
    var array = null,
        picked = null,
        code = (injectedWeather.conditionCode === undefined) ? 34 : Number(injectedWeather.conditionCode);
    if([32, 36].indexOf(code) > -1){
        array = fsAnimations.sun;
    }else if([0, 19, 20, 21, 22, 26, 27, 28, 29, 30, 44, 34, 33].indexOf(code) > -1){
        array = fsAnimations.clouds;
    }else if([8, 9, 10, 11, 12, 17, 18, 35].indexOf(code) > -1){
        array = fsAnimations.rain;
    }else if([5, 6, 7, 13, 14, 15, 16, 41, 42, 43, 46].indexOf(code) > -1){
        array = fsAnimations.snow;
    }else if([31].indexOf(code) > -1){
        array = fsAnimations.moon;
    }else if([1, 2, 3, 4, 37, 38, 39, 45, 47].indexOf(code) > -1){
        array = fsAnimations.thunderstorm;
    }
    picked = this.getRandomURL(array);
    return picked;
  },
  showCharging: function(html){
    if(!document.getElementById('batteryAnimation')){
      this.createFrame('batteryAnimation', 'extras/animation/batteryAnimations/' + html + '/index.html', 320);
    }
  },
  removeCharging: function(){
    if(document.getElementById('batteryAnimation')){
      document.getElementById('batteryAnimation').parentElement.removeChild(document.getElementById('batteryAnimation'));
    }
  },
  showBGAnimation: function(html){
    if(document.getElementById('backgroundAnimation')){
      return;
    }
    var dir = 'extras/animation/backgroundAnimations/',
        ext = '/index.html',
        size = 320,
        fullURL = "";
      if(html === 'weather'){
        ext = "/" + fsAnimations.getWeatherURL();
      }
      if(html === 'birds'){
        size = screen.width;
      }
      fullURL = dir + html + ext;
      this.createFrame('backgroundAnimation', fullURL, size);
  },
  testLoaded: function(){
    return "Loaded";
  }
};
