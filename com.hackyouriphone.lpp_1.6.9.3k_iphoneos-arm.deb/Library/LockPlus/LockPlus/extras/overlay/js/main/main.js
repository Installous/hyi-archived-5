var helpers = {
    createDOM : function (params) {
        var d = document.createElement(params.type);
        if (params.className) {
            d.setAttribute('class', params.className);
        }
        if (params.id) {
            d.id = params.id;
        }
        if (params.innerHTML) {
            d.innerHTML = params.innerHTML;
        }
        if (params.attribute) {
            d.setAttribute(params.attribute[0], params.attribute[1]);
        }
        return d;
    },
    fakeClick: function (element){
        if (document.createEvent) {
           var e = document.createEvent("MouseEvents");
            e.initMouseEvent("click", true, true, window,
                             0, 0, 0, 0, 0, false, false, false,
                             false, 0, null);

            element.dispatchEvent(e);
      } else if (element.fireEvent) {
            element.fireEvent("onclick");
      }
    },
    popupValue: function (name){
        if(paper.project.selectedItems.length > 0){
            jPopup({
                type: "input",
                message: "Enter a number below for " + name + " value",
                yesButtonText: "Apply",
                noButtonText: "Cancel",
                functionOnNo: function() {
                    //alert('cancel');
                },
                functionOnOk: function(value) {
                    var currentPath;
                        currentPath = paper.project.selectedItems[0];
                        var bounds = currentPath.bounds;
                        if(name === 'width'){
                            var oldWidth = currentPath.bounds.width,
                                newWidth = Number(value),
                                oldHeight = currentPath.bounds.height,
                                percent,
                                finalWidth,
                                finalHeight;
                            if(oldWidth < newWidth){
                                percent = (newWidth - oldWidth) / oldWidth * 100;
                                finalWidth = oldWidth + ((oldWidth / 100) * percent);
                                finalHeight = oldHeight + ((oldHeight / 100) * percent);
                            }else{
                                percent = (oldWidth - newWidth) / oldWidth * 100;
                                finalWidth = oldWidth - ((oldWidth / 100) * percent);
                                finalHeight = oldHeight - ((oldHeight / 100) * percent);
                            }
                            bounds.width = finalWidth;
                            bounds.height = finalHeight;
                            document.getElementById('height').innerHTML = "height:" + bounds.height;
                        }else{
                            bounds[name] = Number(value);
                        }
                        currentPath.setBounds(bounds.x, bounds.y, bounds.width, bounds.height);
                        document.getElementById(name).innerHTML = name + ":" + Number(value);
                }
            });
        }
    }
};


var triggers = {
        width: function(){
            helpers.popupValue('width');
        },
        height: function(){
            helpers.popupValue('height');
        },
        y: function(){
            helpers.popupValue('y');
        },
        x: function(){
            helpers.popupValue('x');
        },
        addImage: function(){
            helpers.fakeClick(document.getElementById('imagefile'));
        },
        download: function(){
            if(paper.project.selectedItems){
                for (var i = 0; i < paper.project.selectedItems.length; i++) {
                    paper.project.selectedItems[i].selected = false;
                }
            }
            setTimeout(function(){
                jPopup({
                    type: "confirm",
                    message: "Do you wish to save this to your photos?",
                    yesButtonText: "Yes",
                    noButtonText: "No",
                    functionOnNo: function() {
                        
                    },
                    functionOnOk: function() {
                        var filename = "Test";
                        var canvas = document.getElementById('canvas');
                        var lnk = document.createElement('a'), e;
                        lnk.download = filename;
                        lnk.href = canvas.toDataURL("image/png;base64");
                        helpers.fakeClick(lnk);
                    }
                });
            },1000);
            
        },
        exit: function(){
            parent.document.location.reload();
            //location.href = location.href;
        }
    };
    document.getElementById('canvas').addEventListener('click', function(e){
        // var point = new Point(e.offsetX, e.offsetY);
        // var path = project.hitTest(point, null);
        // if(!path){
        //     if(paper.project.selectedItems){
        //         for (var i = 0; i < paper.project.selectedItems.length; i++) {
        //             paper.project.selectedItems[i].selected = false;
        //         }
        //     }
        //     document.getElementById('width').innerHTML = "";
        //     document.getElementById('height').innerHTML = "";
        //     document.getElementById('y').innerHTML = "";
        //     document.getElementById('x').innerHTML = "";
        // }
    });
    document.getElementById('menu').addEventListener('touchend', function(e){
        if(e.target.id){
            triggers[e.target.id]();
        }
    });

//init paper object
paper.install(window);
var paperTools = {};

//load paperJS
window.onload = function() {
    var canvas = document.getElementById('canvas');
    paper.setup(canvas);
    paper.settings.handleSize = 2;
    paperTools.select.init();
}

