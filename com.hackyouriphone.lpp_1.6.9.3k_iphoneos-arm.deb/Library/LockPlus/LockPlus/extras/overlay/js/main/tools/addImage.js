//polyfill for .includes
if (!Array.prototype.includes) {
  Object.defineProperty(Array.prototype, 'includes', {
    value: function(searchElement, fromIndex) {
      if (this == null) {
        throw new TypeError('"this" is null or not defined');
      }
      var o = Object(this);
      var len = o.length >>> 0;
      if (len === 0) {
        return false;
      }
      var n = fromIndex | 0;
      var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);
      function sameValueZero(x, y) {
        return x === y || (typeof x === 'number' && typeof y === 'number' && isNaN(x) && isNaN(y));
      }
      while (k < len) {
        if (sameValueZero(o[k], searchElement)) {
          return true;
        }
        k++;
      }
      return false;
    }
  });
}

function addImageToPaper(divid){
  var raster = new Raster(divid);
        raster.position = view.center;
        raster.scale(0.2);
}

//store added images for reference
var addedImages = [];

//generate random id for image
function generateRandom(){
    var random = Math.floor(Math.random() * 1000) + 1, // 1 - 1000
        name = 'tempImage';
    return name + random;
}

// when image is selected generate random id, send to paper 
// paper wants the image in the dom so add it, but hide it
function addImage(e){
    var reader = new FileReader();
        reader.onload = function(e){
            var image = document.createElement('img'),
                random = generateRandom();
                if(addedImages.includes(random)){
                    random = generateRandom();
                    addedImages.push(random);
                }else{
                    addedImages.push(random);
                }
                image.src = e.target.result;
                image.className = 'uploadedImages'; 
                image.id = random; //random
                document.body.appendChild(image);
                addImageToPaper(random);
                setTimeout(function(){
                  document.body.removeChild(image);
                },1000);
        }
        reader.readAsDataURL(e.target.files[0]);
}

//detect when image is uploaded
document.getElementById('imagefile').addEventListener('change', function(e){
    addImage(e);
});
