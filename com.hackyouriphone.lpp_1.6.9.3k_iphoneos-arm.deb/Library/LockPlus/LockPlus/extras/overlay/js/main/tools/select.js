paperTools.select = {
    tool: null,
    init: function() {
        var path,
            pixel,
            segment,
            addedHolders,
            hitOptions = {
                segments: true,
                pixel: true,
                stroke: true,
                fill: true,
                curves: true,
                quide: true,
                tolerance: 40
            };
        this.tool = new Tool({
            onMouseDown: function(event) {
                if(paper.project.selectedItems){
                    for (var i = 0; i < paper.project.selectedItems.length; i++) {
                        paper.project.selectedItems[i].selected = false;
                    }
                }
                 var hitResult = project.hitTest(event.point, hitOptions);
                if (hitResult) {
                    if(hitResult.type === 'pixel'){
                        path = hitResult.item;
                        hitResult.item.selected = true;
                        document.getElementById('width').innerHTML = "Width:" + Math.floor(path.bounds.width);
                        document.getElementById('height').innerHTML = "Height:" + Math.floor(path.bounds.height);
                        document.getElementById('y').innerHTML = "Y:" + Math.floor(path.bounds.y);
                        document.getElementById('x').innerHTML = "X:" + Math.floor(path.bounds.x);
                    }
                }else{
                    if(paper.project.selectedItems){
                        for (var i = 0; i < paper.project.selectedItems.length; i++) {
                            paper.project.selectedItems[i].selected = false;
                        }
                    }
                    document.getElementById('width').innerHTML = "";
                    document.getElementById('height').innerHTML = "";
                    document.getElementById('y').innerHTML = "";
                    document.getElementById('x').innerHTML = "";
                }
            },
            onMouseMove: function(event) {
                
            },
            onMouseDrag: function(event) {

                if (segment) {
                    
                } else if (path) {
                    path.position.x += event.delta.x;
                    path.position.y += event.delta.y;
                    document.getElementById('width').innerHTML = "Width:" + Math.floor(path.bounds.width);
                    document.getElementById('height').innerHTML = "Height:" + Math.floor(path.bounds.height);
                    document.getElementById('y').innerHTML = "Y:" + Math.floor(path.bounds.y);
                    document.getElementById('x').innerHTML = "X:" + Math.floor(path.bounds.x);
                }else if (pixel){
                    //console.log('test');
                    // path.position.x += event.delta.x;
                    // console.log('pixel2');
                }

            },
            onMouseUp: function(event) {

            }
        });
    }
};