var Clock = "24h"; // choose between "12h" or "24h"
var lang = "en"; // (tr) for turkish, (de) for german, (sp) for spanish, (it) for italian, (en) for english
var gps = true; // Requires MyLocation app
var locale = 2323778; // Yahoo il kodu
var tempUnit = "c"; // f for fahrenheit
var updateInterval = 30; // in minutes
var UseCityGPS = true; // If your city is innacurate with Yahoo, you can try to use the GPS localization (if available).
var UseNeighborhood = false; // If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).
