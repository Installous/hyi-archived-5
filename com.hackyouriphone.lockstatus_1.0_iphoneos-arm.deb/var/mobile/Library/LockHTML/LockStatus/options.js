var Hide = false; //Hide "placement" background
var Width = "58"; //Width of status bar - in percent (default: 58)