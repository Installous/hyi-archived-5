var MainColor = "Black";
var SecondTextColor = "White";
var SecondColor = "linear-gradient(to right, #7474bf, #348ac7)";
var ZoomLevel = 100;