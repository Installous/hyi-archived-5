var Scale = "1";
var Clock = "12h"; // choose between "12h" or "24h"
var TextColor = "azure";
var CalloutColor = "azure";
var TextColorinCallout = "dimgrey";
var AlwaysShowCallout = false;
var IconWeather = "W";