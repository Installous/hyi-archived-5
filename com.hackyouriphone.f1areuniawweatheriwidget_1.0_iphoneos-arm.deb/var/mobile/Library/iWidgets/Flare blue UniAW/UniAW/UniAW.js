/****************************
*           UniAW6          *
*     Author: Ian Nicoll    *
*    with credit to Dacal   *
*     update by oldster     *
*   Version 1.0 13.04.2013  *
*    http://itheming.de/    *
****************************/
	        
var filename = "";
var where = "";
var whereOld = "";    
var Conditions = [
	"thunderstorm",		//0 	tornado
	"thunderstorm",		//1 	tropical storm
	"thunderstorm",		//2 	hurricane
	"thunderstorm",		//3 	severe thunderstorms
	"thunderstorm",		//4 	thunderstorms
	"sleet",				//5 	mixed rain and snow
	"sleet",				//6 	mixed rain and sleet
	"sleet",				//7 	mixed snow and sleet
	"sleet",				//8 	freezing drizzle
	"showers_cloud",	//9 	drizzle
	"sleet",				//10 	freezing rain
	"showers_cloud",	//11 	showers
	"rain",				//12 	showers
	"snow",				//13 	snow flurries
	"snow",				//14 	light snow showers
	"snow",				//15 	blowing snow
	"snow",				//16 	snow
	"hail",				//17 	hail
	"sleet",				//18 	sleet
	"fog",				//19 	dust
	"fog",				//20 	foggy
	"haze",				//21 	haze
	"fog",				//22 	smoky
	"wind",				//23 	blustery
	"wind",				//24 	windy
	"frost",				//25 	cold
	"cloud",				//26 	cloudy
	"partlycloudy",		//27 	mostly cloudy (night)
	"partlycloudy",		//28 	mostly cloudy (day)
	"partlycloudy",		//29 	partly cloudy (night)
	"partlycloudy",		//30 	partly cloudy (day)
	"moon",				//31 	clear (night)
	"sun",				//32 	sunny
	"partlycloudy",		//33 	fair (night)
	"partlycloudy",		//34 	fair (day)
	"sleet",				//35 	mixed rain and hail
	"sun",				//36 	hot
	"thunderstorm",		//37 	isolated thunderstorms
	"thunderstorm",		//38 	scattered thunderstorms
	"thunderstorm",		//39 	scattered thunderstorms
	"showers_cloud",	//40 	scattered showers
	"snow",				//41 	heavy snow
	"snow",				//42 	scattered snow showers
	"snow",				//43 	heavy snow
	"partlycloudy",		//44 	partly cloudy
	"thunderstorm",		//45 	thundershowers
	"snow",				//46 	snow showers
	"thunderstorm",		//47 	isolated thundershowers
	"blank"];			//3200 	not available
			                
function UniAW(code,sunset,sunrise) {
	document.getElementById("status").innerHTML = "UniAW";
	
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();	
	time_to_change_wall = currentHours + currentMinutes/60;	
	
	// SUNSET/SUNRISE FORMAT
	sunriseh = sunrise.substring(0,obj.sunrise.indexOf(":",0));
	sunrisem = sunrise.substring(obj.sunrise.indexOf(":",0)+1,obj.sunrise.indexOf(" ",0));
	sunseth = sunset.substring(0,obj.sunset.indexOf(":",0));
	sunsetm = sunset.substring(obj.sunset.indexOf(":",0)+1,obj.sunset.indexOf(" ",0));
	sunriseh = parseInt(sunriseh) ;
	sunseth = parseInt(sunseth) ;
	sunseth = sunseth + 12;
		
	// DAY AND NIGHT DURATION
	dayhour = parseInt(sunriseh) + parseInt(sunrisem)/60;
	nighthour = parseInt(sunseth) + parseInt(sunsetm)/60;
	DurationOfDay = nighthour - dayhour;
	DurationOfNight = 24 - DurationOfDay;
		
	// POSITION OF SUN/MOON
	if ((time_to_change_wall < dayhour) || (time_to_change_wall > nighthour)) {
		where = "night";
		if (time_to_change_wall < dayhour) { time_to_change_wall = time_to_change_wall +24 };
		if (Sun_Moon_from_right_to_left === true){
			pTranslate = parseInt((1-(time_to_change_wall - nighthour)/ DurationOfNight)*320);
		} else {
			pTranslate = parseInt(((time_to_change_wall - nighthour)/ DurationOfNight)*320);
		}
		document.getElementById("moon").style.webkitTransform = "translateX("+pTranslate+"px)";
		document.getElementById("moonray").style.webkitTransform = "translateX("+pTranslate+"px)";
		} else {					
			where = "day";
			if (Sun_Moon_from_right_to_left === true){
				pTranslate = parseInt((1-(time_to_change_wall - dayhour)/ DurationOfDay)*320);
			} else {
				pTranslate = parseInt(((time_to_change_wall - dayhour)/ DurationOfDay)*320);
			}
			document.getElementById("sun").style.webkitTransform = "translateX("+pTranslate+"px)";
			document.getElementById("sunray").style.webkitTransform = "translateX("+pTranslate+"px)";
		}
			
		if (filename == "") {
			filename = Conditions[code];
			whereOld = where;
			loadjscssfile ("Weather", filename, "css");
			loadjscssfile ("Weather", filename, "js");
		} else {
			if ((Conditions[obj.icon] != filename ) || (where != whereOld)) {
				whereOld = where;
				clearInterval(meteorTimer);
				delelement("astronautContainer");
				delelement("starContainer");
				delelement("meteorContainer");
				delelement("frameContainer");
				delelement("cloudContainer");
				delelement("dropContainer");
				delelement("wiperContainer");
				delelement("starsBGContainer");
				replacejscssfile("Weather", filename, Conditions[code], "css");
				replacejscssfile("Weather", filename, Conditions[code], "js");
				filename = Conditions[code];
				filename = Conditions[code];	
		}
	}
}

function delelement(elem) {
	var element = document.getElementById(elem);
	while (element.firstChild) { element.removeChild(element.firstChild); }
}

function loadjscssfile(url, filename, filetype){
	if (filetype=="js") {
		var fileref = document.createElement("script");
		fileref.type = "text/javascript";
		fileref.charset = "utf-8";
		fileref.src = "UniAW/JavaScript/" + url + "/" + filename + ".js";
	 }
	if (filetype=="css") {
		var fileref = document.createElement("link");
		fileref.rel = "stylesheet";
		fileref.href = "UniAW/Css/" + url + "/" + filename + ".css";
		fileref.type = "text/css";
		fileref.media = "screen";
 	}
	document.getElementsByTagName("head")[0].appendChild(fileref);
}

function createjscssfile(url, filename, filetype){
	if (filetype=="js") {
		var fileref = document.createElement("script");
		fileref.type = "text/javascript";
		fileref.charset = "utf-8";
		fileref.src = "UniAW/JavaScript/" + url + "/" + filename + ".js";
 	}
	if (filetype=="css") {
		var fileref = document.createElement("link");
		fileref.rel = "stylesheet";
		fileref.href = "UniAW/Css/" + url + "/" + filename + ".css";
		fileref.type = "text/css";
		fileref.media = "screen";
 	}
	return fileref;
}

function replacejscssfile(url, oldfilename, newfilename, filetype){
	var targetelement = (filetype=="js")? "script" : (filetype=="css")? "link" : "none";
	var targetattr = (filetype=="js")? "src" : (filetype=="css")? "href" : "none";
	var allsuspects = document.getElementsByTagName(targetelement);
	for (var i = allsuspects.length; i>=0; i--) { 
		if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute
(targetattr).indexOf(oldfilename)!=-1) {
			var newelement = createjscssfile(url, newfilename, filetype);
			allsuspects[i].parentNode.replaceChild(newelement, allsuspects[i]);
		}
	}
}