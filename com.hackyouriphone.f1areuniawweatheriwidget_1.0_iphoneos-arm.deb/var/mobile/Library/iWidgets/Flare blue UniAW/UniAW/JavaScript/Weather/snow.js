// Snow condition iph5
// UniAW6.0 By Ian Nicoll with credit to Dacal

var NUMBER_OF_CLOUDS = 10; // clouds to show on screen
var NUMBER_OF_CLOUDS_IMAGES = 17; // images + 1
var NUMBER_OF_drop = 30; // drop to show on screen
var NUMBER_OF_DROP_IMAGES = 4; // images + 1
var container1 = document.getElementById("cloudContainer");
var container2 = document.getElementById("dropContainer");
var container3 = document.getElementById("wiperContainer");
if (where == "day") {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='none';
if (ShowWiper === true) container3.appendChild(createAlight());
} else {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='none';
if (ShowWiper === true) container3.appendChild(createAlight());
}
//document.getElementById("weatherWall").style.display='block';

for (var i = 0; i < NUMBER_OF_CLOUDS; i++)
{
container1.appendChild(createACloud());
}

for (var i = 0; i < NUMBER_OF_drop; i++)
{
container2.appendChild(createAdrop());
}

function randomInteger(low, high) {
    return low + Math.floor(Math.random() * (high - low));
}
function randomFloat(low, high) {
    return low + Math.random() * (high - low);
}
function pixelValue(value) {
    return value + "px";
}
function durationValue(value) {
    return value + "s";
}

function createAlight() {
    var image = document.createElement("img");
    image.id = "wiper";	
    image.src = "UniAW/Images/Weather/wiper/wiper.png";
    return image;
}

function createACloud() {
    var cloudDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "UniAW/Images/Weather/cloud/" + where + "/cloud" + randomInteger(1, NUMBER_OF_CLOUDS_IMAGES) + ".png";
    cloudDiv.style.top = pixelValue(randomInteger(-90, 30));
    cloudDiv.style.left = pixelValue(randomInteger(-340, 50));
    cloudDiv.style.webkitAnimationName = "fade, float";
    var fadeAndfloatDuration = durationValue(randomFloat(50, 140));
    cloudDiv.style.webkitAnimationDuration = fadeAndfloatDuration + ", " + fadeAndfloatDuration;
    cloudDiv.appendChild(image);
    return cloudDiv;
}

function createAdrop() {
    var dropDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "UniAW/Images/Weather/snow/snow" + randomInteger(1, NUMBER_OF_DROP_IMAGES) + ".png";
    dropDiv.style.top = pixelValue(randomInteger(-200, 50));
    dropDiv.style.left = pixelValue(randomInteger(-10, 330));
    dropDiv.style.webkitAnimationName = "fade2, drop";
    var fadeAndDropDuration = durationValue(randomFloat(4, 10));
    dropDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
    dropDiv.appendChild(image);
    return dropDiv;
}

