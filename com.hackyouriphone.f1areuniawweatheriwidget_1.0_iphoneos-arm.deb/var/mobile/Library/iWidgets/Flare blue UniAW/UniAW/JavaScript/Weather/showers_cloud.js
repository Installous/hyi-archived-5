// Showers condition iph5
// UniAW6.0 By Ian Nicoll with credit to Dacal

var NUMBER_OF_CLOUDS = 9; // clouds to show on screen
var NUMBER_OF_CLOUDS_IMAGES = 17; // images + 1
var NUMBER_OF_drop = 30; // drop to show on screen
var NUMBER_OF_DROP_IMAGES = 9; // images + 1
var container = document.getElementById("frameContainer");
var container1 = document.getElementById("cloudContainer");
var container2 = document.getElementById("dropContainer");
var container3 = document.getElementById("wiperContainer");

if (where == "day") {
function createArainbow() {
    var image = document.createElement("img");
    image.id = "rainbow";	
    image.src = "UniAW/Images/Weather/rainbow/rainbow2.png";
    return image;
}
if (ShowRainbow === true) container.appendChild(createArainbow());
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='block';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='block';
if (ShowWiper === true) container3.appendChild(createAwiper());
} else {
document.getElementById("moon").style.display='block';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='block';
document.getElementById("sunray").style.display='none';
if (ShowWiper === true) container3.appendChild(createAwiper());

var NUMBER_OF_LIGHT = 30; // Number of stars to show on screen
var NUMBER_OF_LIGHT_IMAGES = 6; // images + 1
var NUMBER_OF_METEOR = 3; // Number of meteors to show on screen
var NUMBER_OF_METEOR_IMAGES = 3; // images + 1
var container4 = document.getElementById("starContainer");
var container5 = document.getElementById("meteorContainer");
var container6 = document.getElementById("starsBGContainer");
container6.appendChild(createAbackground());

// METEOR ANIMATION
var meteorTimer = setInterval( function () {
	delelement("meteorContainer");
	for (var i = 0; i < NUMBER_OF_METEOR; i++) { container5.appendChild(createAmeteor());	}
	}, 10000);

// STARS ANIMATION
for (var i = 0; i < NUMBER_OF_LIGHT; i++) { container4.appendChild(createAstar()); }


}


for (var i = 0; i < NUMBER_OF_CLOUDS; i++)
{
container1.appendChild(createACloud());
}

for (var i = 0; i < NUMBER_OF_drop; i++)
{
container2.appendChild(createAdrop());
}

function randomInteger(low, high) {
    return low + Math.floor(Math.random() * (high - low));
}
function randomFloat(low, high) {
    return low + Math.random() * (high - low);
}
function pixelValue(value) {
    return value + "px";
}
function durationValue(value) {
    return value + "s";
}

function createAwiper() {
    var image = document.createElement("img");
    image.id = "wiper";	
    image.src = "UniAW/Images/Weather/wiper/wiper.png";
    return image;
}

function createAstar() {
    var starDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "UniAW/Images/Weather/moon/star" + randomInteger(1, NUMBER_OF_LIGHT_IMAGES) + ".png";
    starDiv.style.top = pixelValue(randomInteger(0, 70));
    starDiv.style.left = pixelValue(randomInteger(10, 310));
    starDiv.style.webkitAnimationName =  "star_anim";
    starDiv.style.webkitAnimationDuration = durationValue(randomInteger(5, 20));
	starDiv.style.webkitAnimationDelay = durationValue(randomInteger(1, 10));
    starDiv.appendChild(image);
    return starDiv;
}

function createAbackground() {
    var image = document.createElement("img");
    image.id = "starsBG";	
    image.src = "UniAW/Images/Weather/moon/starsBG.png";
    return image;
}

function createAmeteor() {
    var dropDiv = document.createElement("div");
    var image = document.createElement("img");
	var meteorNumber = randomInteger(1, NUMBER_OF_METEOR_IMAGES);
    image.src = "UniAW/Images/Weather/moon/meteor" + meteorNumber + ".png";
    dropDiv.style.top = pixelValue(randomInteger(-10, 70));
    dropDiv.style.left = pixelValue(randomInteger(0, 320));
    dropDiv.style.webkitAnimationName = "fade2, drop" + meteorNumber;
    var fadeAndDropDuration = durationValue(randomFloat(1, 2));
    dropDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
	dropDiv.style.webkitAnimationDelay = durationValue(randomInteger(1, 7));
    dropDiv.appendChild(image);
    return dropDiv;
}

function createACloud() {
    var cloudDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "UniAW/Images/Weather/cloud/" + where + "/cloud" + randomInteger(1, NUMBER_OF_CLOUDS_IMAGES) + ".png";
    cloudDiv.style.top = pixelValue(randomInteger(-90, 30));
    cloudDiv.style.left = pixelValue(randomInteger(-340, 50));
    cloudDiv.style.webkitAnimationName = "fade, float";
    var fadeAndfloatDuration = durationValue(randomFloat(50, 140));
    cloudDiv.style.webkitAnimationDuration = fadeAndfloatDuration + ", " + fadeAndfloatDuration;
    cloudDiv.appendChild(image);
    return cloudDiv;
}

function createAdrop() {
    var dropDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "UniAW/Images/Weather/rain/drop" + randomInteger(1, NUMBER_OF_DROP_IMAGES) + ".png";
    dropDiv.style.top = pixelValue(randomInteger(-200, 50));
    dropDiv.style.left = pixelValue(randomInteger(-10, 330));
    dropDiv.style.webkitAnimationName = "fade2, drop";
    var fadeAndDropDuration = durationValue(randomFloat(1, 2));
    dropDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
    dropDiv.appendChild(image);
    return dropDiv;
}
