// moon condition iph5
// UniAw6.0 by Ian Nicoll with credit to Dacal

if (where == "day") {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='block';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='block';
} else {
document.getElementById("moon").style.display='block';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='block';
document.getElementById("sunray").style.display='none';

var NUMBER_OF_LIGHT = 30; // Number of stars to show on screen
var NUMBER_OF_LIGHT_IMAGES = 6; // images + 1
var NUMBER_OF_METEOR = 3; // Number of meteors to show on screen
var NUMBER_OF_METEOR_IMAGES = 3; // images + 1

var NUMBER_OF_CLOUDS = 1; // Astronauts to show on screen
var NUMBER_OF_IMAGES = 2; // Astronaut images + 1

var container = document.getElementById("astronautContainer");
var container1 = document.getElementById("starContainer");
var container2 = document.getElementById("meteorContainer");
var container3 = document.getElementById("starsBGContainer");
container3.appendChild(createAbackground());

// METEOR ANIMATION
var meteorTimer = setInterval( function () {
	delelement("meteorContainer");
	for (var i = 0; i < NUMBER_OF_METEOR; i++) { container2.appendChild(createAmeteor());	}
	}, 10000);

// STARS ANIMATION
for (var i = 0; i < NUMBER_OF_LIGHT; i++) { container1.appendChild(createAstar()); }
}

for (var i = 0; i < NUMBER_OF_CLOUDS; i++)
{
container.appendChild(createAastronaut());
}

function randomInteger(low, high) {
    return low + Math.floor(Math.random() * (high - low));
}

function pixelValue(value) {
    return value + "px";
}

function durationValue(value) {
    return value + "s";
}

function randomFloat(low, high) {
    return low + Math.random() * (high - low);
}


function createAastronaut() {
    var cloudDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "UniAW/Images/Weather/astronaut/astronaut" + randomInteger(1, NUMBER_OF_IMAGES) + ".png";
    cloudDiv.style.top = pixelValue(randomInteger(0, 0));
    cloudDiv.style.left = pixelValue(randomInteger(-10, 20));
    var spinAnimationName = (Math.random() < 0.5) ? "clockwiseSpin" : "counterclockwiseSpinAndFlip";
    cloudDiv.style.webkitAnimationName = "fade, float";
    image.style.webkitAnimationName = spinAnimationName + ", astronaut_anim";
    var fadeAndfloatDuration = durationValue(randomFloat(130, 150));
    var spinDuration = durationValue(randomFloat(50, 100));
    cloudDiv.style.webkitAnimationDuration = fadeAndfloatDuration + ", " + fadeAndfloatDuration;
    image.style.webkitAnimationDuration = spinDuration + ", " + fadeAndfloatDuration;
    cloudDiv.appendChild(image);
    return cloudDiv;
}

function createAstar() {
    var starDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "UniAW/Images/Weather/moon/star" + randomInteger(1, NUMBER_OF_LIGHT_IMAGES) + ".png";
    starDiv.style.top = pixelValue(randomInteger(0, 70));
    starDiv.style.left = pixelValue(randomInteger(10, 310));
    starDiv.style.webkitAnimationName =  "star_anim";
    starDiv.style.webkitAnimationDuration = durationValue(randomInteger(5, 20));
	starDiv.style.webkitAnimationDelay = durationValue(randomInteger(1, 10));
    starDiv.appendChild(image);
    return starDiv;
}

function createAbackground() {
    var image = document.createElement("img");
    image.id = "starsBG";	
    image.src = "UniAW/Images/Weather/moon/starsBG.png";
    return image;
}

function createAmeteor() {
    var dropDiv = document.createElement("div");
    var image = document.createElement("img");
	var meteorNumber = randomInteger(1, NUMBER_OF_METEOR_IMAGES);
    image.src = "UniAW/Images/Weather/moon/meteor" + meteorNumber + ".png";
    dropDiv.style.top = pixelValue(randomInteger(-10, 70));
    dropDiv.style.left = pixelValue(randomInteger(0, 320));
    dropDiv.style.webkitAnimationName = "fade2, drop" + meteorNumber;
    var fadeAndDropDuration = durationValue(randomFloat(1, 2));
    dropDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
	dropDiv.style.webkitAnimationDelay = durationValue(randomInteger(1, 7));
    dropDiv.appendChild(image);
    return dropDiv;
}