/****************************
*     theme translation     *
*   Version 1.0 01.05.2013  *
*     created by oldster    *
*    http://itheming.de/    *
****************************/
switch (language) {
	case "en": { 
		var this_date_name_array = ["0", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th",
		"8th", "9th", "10th","11th", "12th", "13th", "14th", "15th", "16th", "17th", "18th", "19th",
		"20th","21st", "22nd", "23rd", "24th", "25th", "26th", "27th" ,"28th", "29th" ,"30th", "31st"]
		var this_weekday_name_array=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday",
		"Saturday"];
		var this_month_name_array=["January","February","March","April","May","June","July","August",
		"September","October","November","December"];
		var windDirection =['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW',
		'W', 'WNW', 'NW', 'NNW', 'N'];
		break;
	 }
	case "ge": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		var this_weekday_name_array=["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag",	
		"Samstag"];
		var this_month_name_array=["Januar","Februar","M�rz","April","Mai","Juni","Juli","August",
		"September","Oktober","November","Dezember"];
		var weatherNow =["Tornado","Tropischer Sturm","Orkan","Heftiges Gewitter","Gewitter",
		"Regen und Schnee","Regen und Eisregen","Schnee und Eisregen","Gefrierender Nieselregen",
		"Nieselregen","Gefrierender Regen","Schauer","Schauer","Schneeschauer","Leichte Schneeschauer",
		"St \u00FCrmiger Schneefall","Schnee","Hagel","Eisregen","Staub","Neblig","Dunst","Staubig","St\u00FCrmisch",
		"Windig","Kalt","Bew\u00F6lkt","Gr\u00F6&#223;tenteils bew\u00F6lkt","Gr\u00F6&#223;tenteils bew\u00F6lkt","Teilweise bew\u00F6lkt",
		"Teilweise bew\u00F6lkt","Klar","Sonnig","Sch\u00F6n","Sch\u00F6n","Regen und Hagel","Hei&szlig;","Einzelne Gewitter",
		"Vereinzelte Gewitter","Vereinzelte Gewitter","Vereinzelte Schauer","Starker Schneefall",
		"Vereinzelte Schneeschauer","Starker Schneefall","Teilweise bew\u00F6lkt","Sp\u00E4ter Schauer",
		"Schneeschauer","Einzelne Gewitterschauer","N/A"];
		var windDirection =['N', 'NNO', 'NO', 'ONO', 'O', 'OSO', 'SO', 'SSO', 'S', 'SSW', 'SW', 'WSW',
		'W', 'WNW', 'NW', 'NNW', 'N'];
		break;	
	}
	case "fr": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		var this_weekday_name_array=["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi",	
		"Samedi"];
		var this_month_name_array=["Janvier","F�vrier","Mars","Avril","Mai","Juin","Juillet","Ao�t",
		"Septembre","Octobre","Novembre","D�cembre"];
		var weatherNow =["Tornade","Orage Tropical","Ouragan","Orages","Orages","Pluie et Neige",
		"Pluie et Verglas","Neige et Verglas","Brouillard Vergla�ant","Pluie","Pluie Vergla�ante",
		"Averses","Averses","Bourrasques de neige","Petites chutes de neige","Chutes de neige - Vent",
		"Neige","Gr�le","Verglas","Non communiqu�","Brumeux","Brume","Non communiqu�","Non communiqu�",
		"Vent","Froid","Nuageux","Tr�s Nuageux","Nuageux","Passages nuageux","Passages nuageux",
		"Ciel Clair","Ensoleill�","Clair","Beau Temps","Pluie et Gr�le m�lang�es","Tr�s Chaud",
		"Passages nuageux avec orages","Orages et �claircies","Orages et �claircies",
		"Pluies et �claircies","Chute de neige importante","Petite chutes de neige",
		"Chute de neige importante","Partiellement couvert","Tonnerre","Chutes de neige",
		"Tonnerre et �claircies","Pas d'info",]; 
		var windDirection =['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSO', 'SO', 'OSO',
		'O', 'ONO', 'NO', 'NNO', 'N'];		
		break;
	}	
		case "sp": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		var this_weekday_name_array=["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];
		var this_month_name_array=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Juliot","Agosto","Septiembre"," Octubre","Novimbre","Decimbre"];
		
		var weatherNow =["Soleado","Llovizna","Nieve fuerte","Luvia fuerte","Lluvia y nieve","Mezcla de lluvia y nieve","Despejado","Mayormente soleado",
		"Parcialmente soleado","Intermitente nublado","Sol brumoso","Bruma","Mayormente nublado","Nublado","Niebla","Chubascos","Parcialmente soleado con chubascos",
		"Tormentas electricas","Tormenta electrica","Mayormente nublado con tormentas de chubascos","Parcialmente soleado con tormentas de chubascos","Lluvia ligera",
		"Lluvia","Rafagas","Mayormente nublado con rafagas","Parcialmente soleado con rafagas","Rafagas de nieve","Precipitaciones de nieve","Nieve","Mayormente nublado con nieve",
		"Hielo","Aguanieve","Lluvia bajo cero","Mezcla de lluvia y nieve","Caluroso","Frio","Vientoso","Despejado","Mayormente despejado","Parcialmente despejado","Bruma",
		"Parcialmente nublado con chubascos","Mayormente nublado con chubascos","Parcialmente nublado con tormentas de chubascos","Neblina","Nieve ligera","Ligeras precipitaciones de nieve",
		"Precipitaciones de lluvia","Bruma","Mezcla de lluvia y aguanieve","Mezcla de nieve y aguanieve","Tormentas electricas severas","Huracan","Tormenta tropical","Tornado",
		"Llovizna helada","Viento y nieve","Granizo","Polvareda","Humeado","Tempestuoso","Mezcla de lluvia y granizo","Tormentas electricas aisladas","Tormentas aisladas",
		"Tormentas electricas dispersas","Chubascos dispersos","Precipitaciones de nieve dispersas","LLuvia y tormenta ligera","No disponible","Acumulacion de nieve y viento",
		"Precipitaciones de lluvia ligera","Truenos","Mayormente nublado y ventoso","Tormentas de arena","Chubascos y viento","Arena","Tormentas de arena y ventoso",]; 

		 
		var windDirection =['N', 'N-NO', 'NO', 'O-NO', 'O', 'O-SO', 'SO', 'S-SO', 'S', 'S-SE', 'SE', 'E-SE', 'E', 'E-NE', 'NE', 'N-NE', 'N'];
		break;			
			
	}
}

function ForecastDayNames(day){
	switch (language) {
		case "ge": {
			switch (day) {
				case "Mon": { return "Montag" }
				case "Tue": { return "Dienstag" }
				case "Wed": { return "Mittwoch" }
				case "Thu": { return "Donnerstag" }
				case "Fri": { return "Freitag" }
				case "Sat": { return "Samstag" }
				case "Sun": { return "Sonntag" }
			}
		}
		case "fr": {
			switch (day) {
				case "Mon": { return "Lundi" }
				case "Tue": { return "Mardi" }
				case "Wed": { return "Mercredi" }
				case "Thu": { return "Jeudi" }
				case "Fri": { return "Vendredi" }
				case "Sat": { return "Samedi" }
				case "Sun": { return "Dimanche" }				
			}
		}
		case "sp": {
			switch (day) {
				case "Mon": { return "Lun" }
				case "Tue": { return "Mar" }
				case "Wed": { return "Mie" }
				case "Thu": { return "Jue" }
				case "Fri": { return "Vie" }
				case "Sat": { return "Sab" }
				case "Sun": { return "Dom" }
			}
		}
	}
	return day;
}

