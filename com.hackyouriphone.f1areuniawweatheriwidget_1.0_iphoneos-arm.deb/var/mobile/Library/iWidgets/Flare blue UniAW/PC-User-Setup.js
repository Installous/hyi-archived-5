/****************************

*	  Basic_theme created by oldster	    *

*     Pallet LS UniAW small-touch forecast modified by hell7    *

****************************/

var locale		 = 641683;	// WOEID - only numbers
var nextWeather = 60*60*1000;  // first numerol = mins
var gps_weather  = false;     // false No GPS Weather
var uniAW		 = true;	 // UniAW 6.0 from Ian Nicoll (oldster version)
var language = 'en'; // en-English de-Deutsch fr-France sp-Spain it-Italian
var weather_unit = 'f';      // cELSIUS - fAHRENHEIT 
var hour24		 = false;     // false 12h am/pm

// Setup UniAW6
var ShowWiper = false; // true or false, true to display the wiper in wet weather conditions.
var ShowRainbow = false; /* true or false, true to display the rainbow animation in daytime
"Showers" weather conditions.*/
var FullScreenFogHaze = true; /* true or false, set to true to make the fog/haze animations
full screen, set to false and they are only in top half of screen.*/
var Sun_Moon_from_right_to_left = false; /* true or false. set to true to have the sun/moon
animations start from the right side of the screen. */
var ShowBalloon = true; /* true or false , to show or hide hot air balloon in certain weather conditions. */
var Number_Of_Balloons = "3"; /* minumum 1, maximum 5. */

/****************************

*	 Here is the end my friend,lol	    *

****************************/






