  /* Done by Dacal mod by frenchitouch */ 
 /* Thx to @schnedi for the refresh code */
       /** TWITTER @frenchitouch **/

/* *************************************** */
/* The following scripts will allow you to fine tune */
/* *************************************** */


/* *************************************** */
/* ************* Weather  **************** */

// Use www.weather.com to find your weathercode
// For example searching for Milan Italy will get you this URL
// http://www.weather.com/weather/right-now/Milan+Italy+ITXX0042
// The last part ITXX0042 is the weathercode to use in "var locale"


//you not have (GPS) "myLocation" download from cydia "GPS Weather Lockscreen" by crazyvivek(iOS 4.x - 5.0.1) or search on Google the version compatible with iOS 5.1.1 or 6.x contact me via cydia for more support or talk with me on TWITTER @DemoneLatino

/* *************************************** */
  /* ******** Weather Icons  *********** */

var IconSet = "frenchitouch";  // add your own set

var iconExt = ".png"  // icons extension

var updateInterval = 5;  // in minutes

