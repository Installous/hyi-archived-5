var iconSet = "Gold"; // Gold or Black
var twentyfourhour = true; 
var pad = true; 
