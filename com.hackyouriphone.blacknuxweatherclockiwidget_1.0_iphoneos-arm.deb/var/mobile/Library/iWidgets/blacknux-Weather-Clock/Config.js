/*







Config File Weather







*/

var Clock = "12h";		  // choose between "12h" or "24h"


var lang = "en";	       // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) for english


var gps = true; 	      // Requires MyLocation app


var locale = 588630;	       // Yahoo Weather (used if gps set to false or myLocation.txt file not found)



var tempUnit = "f";	       // f for fahrenheit



var IconSet = "Clima";	    // add your own set




var updateInterval = 30;       // in minutes