switch (Clock_Options) {
		case "Magenta":
			document.getElementById("DefaultStyle").href = "Styles/magenta.css"
		break;
		case "Formal":
			document.getElementById("DefaultStyle").href = "Styles/formal.css"
		break;
		case "BnW":
			document.getElementById("DefaultStyle").href = "Styles/bnw.css"
		break;
		case "Gold":
			document.getElementById("DefaultStyle").href = "Styles/gold.css"
		break;
		case "Diamond":
			document.getElementById("DefaultStyle").href = "Styles/diamond.css"
		break;
		case "Maroon":
			document.getElementById("DefaultStyle").href = "Styles/maroon.css"
		break;
		case "Grunge":
			document.getElementById("DefaultStyle").href = "Styles/grunge.css"
		break;
}

var BG_Options = "Vintage"; // OPTIONS: "BlackBG" or "RedStripesBG" or "Red" or "Abstract" or "DarkAbstract" or "Carbon" or "Hex" or "Vintage" or "Wood"
switch (BG_Options) {
		case "Abstract":
			document.getElementById("screens").src = "Images/Wallpapers/Abstract.png"
		break;
}

if(Shadow == true){
	document.querySelector("body").style.webkitFilter = "drop-shadow(0px 3px 3px #111)";
}

if(Invert == true){
	document.querySelector("body").style.webkitFilter = "invert(100%)";
}

if(InvertPlusShadow == true){
	document.querySelector("body").style.webkitFilter = "invert(100%) drop-shadow(0px 3px 3px #111)";
}

if(Grayscale == true){
	document.querySelector("body").style.webkitFilter = "grayscale(100%)";
}

if(GrayscalePlusShadow == true){
	document.querySelector("body").style.webkitFilter = "grayscale(100%) drop-shadow(0px 3px 3px #111)";
}

if(White == true){
	document.querySelector("body").style.webkitFilter = "brightness(0%) invert(100%)";
}

if(WhitePlusShadow == true){
	document.querySelector("body").style.webkitFilter = "brightness(0%) invert(100%) drop-shadow(0px 3px 3px #111)";
}


