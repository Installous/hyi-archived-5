var MainColor = "White";
var SecondaryColor = "Orange";
var AlignLeft = false;
var AlignCenter = false;
var ZoomLevel = 90;
