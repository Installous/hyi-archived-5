var WidgetColor = "White";
var WeatherZoom = 150;
var DarkIcon = false;
var OwnWallpaper = true;
var HideAnimation = true;
