Ambriel SB Weather by Flybritn/ibniaffa/VicDaMonki  Ported tp iPad by LiQuiD





*******************************************************************************************************

   

 *Set weather location
use ifile or ssh to var/stash/themes/Ambriel SB Weather/ open Wallpaper.html
look for this line

var locale = "38301" //e.g.   <---change 38301 to your zipcode or weather code




to get your weather code visit http://www.edg3.co.uk/snippets/weather-location-codes/


******************************************************************************************************

Change the clock to 24 hour format.

go into ( Aspire iPad AnyWall LS Weather ) wich ever one you using, open up the html file scroll down untill you see

function updateClock ( )

then look for this

var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";


currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;


currentHours = ( currentHours == 0 ) ? 12 : currentHours;

you want to change it so it looks like this below

var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";


currentHours = ( currentHours > 24 ) ? currentHours - 12 : currentHours;


currentHours = ( currentHours == 0 ) ? 12 : currentHours;