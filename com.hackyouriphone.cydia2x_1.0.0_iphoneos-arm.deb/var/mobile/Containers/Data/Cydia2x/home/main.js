// Cydia2x
// (c) Copyright Castyte 2019

var motdel = document.querySelector('#motd')
var featuredl = document.querySelector('#featured')

// MOTD
fetch('https://castyte.js.org/cydia2x/motd').then(res => {
    if(!res.ok) return;
    res.text().then(txt => motdel.innerHTML = txt);
}).catch(e => {
    motdel.innerHTML = 'No internet connection. Some services may not work.'
    document.querySelector('#featuredheader').remove();
    featuredl.remove();
})

// Featured
// fetch('https://castyte.js.org/cydia2x/featured.json').then(res => {
//     if(!res.ok) return;
//     res.text().then(txt => motdel.innerHTML = txt);
// })


fetch("https://castyte.js.org/cydia2x/featured.json").then(res => {
    if(!res.ok) return;
    res.json().then(f => {
        f.forEach((el) => {
            var li = document.createElement("li")
            var pkg = document.createElement("a")
            pkg.href = `cydia://package/${el.id}~cydia2x-repo~${el.repo}`
            pkg.setAttribute('role', "button")
            pkg.target = '_blank'
            pkg.innerText = el.name
            featuredl.appendChild(li)
            li.appendChild(pkg)
        })
    })
})