const sources = cydia.getAllSources();
var srcs = ""
for(source in sources){
    srcs += sources[source].rooturi+'\n'
}

const srcsel = document.querySelector('#sources');
fetch('https://castyte.js.org/cydia2x/sources.json').then(res => {if(!res.ok) return; return res.json()}).then(sources => sources.forEach(el => {
    if(srcs.includes(el.url)) return;
    var li = document.createElement("li")
    var src = document.createElement("button")
    src.type = 'submit'
    if(el.dist){
        src.setAttribute('onclick', 'addrepo("'+el.name+'","'+el.url+'","'+el.dist+'",["'+el.comp+'"])')
    } else {
        src.setAttribute('onclick', 'addrepo("'+el.name+'","'+el.url+'")')
    }
    src.innerText = el.name;
    srcsel.appendChild(li)
    li.appendChild(src)
}))

var showSources = function(){
    document.querySelector('#content').innerHTML = '<ul><li><p>'+srcs+'</p></li></ul>';
}

var addrepo = function(name,url,dist,comp){
    if(confirm("Add Source '"+name+"'?")){
        if(dist){
            cydia.addSource(url,dist,comp);
        } else {
            cydia.addTrivialSource(url);
        }
        cydia.refreshSources();
        window.setTimeout(function(){cydia.unload();},0);
    }
};

document.addEventListener('CydiaReloadData',function(){window.location.reload()});