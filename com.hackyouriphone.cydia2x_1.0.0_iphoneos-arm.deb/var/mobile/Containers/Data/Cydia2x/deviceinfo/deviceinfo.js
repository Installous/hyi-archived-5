// Cydia2x
// (c) Copyright Castyte 2019

document.querySelector('#useragent').innerHTML = navigator.userAgent;
document.querySelector('#ecid').innerHTML = cydia.ecid;
document.querySelector('#model').innerHTML = cydia.model;
document.querySelector('#firmware').innerHTML = cydia.firmware;
document.querySelector('#udid').innerHTML = cydia.device;