// Configuration Clock //



	var ampm = true;	  // change to true to display 12h clock


// Configuration Language //



	var French = false;	// change to true to display date in French

	var German = false;	 // change to true to display date in German

	var Spanish = false;	 // change to true to display date in Spanish

	var Italian = false;	 // change to true to display date in Italian,  SET ALL TO FALSE TO SET TO ENGLISH