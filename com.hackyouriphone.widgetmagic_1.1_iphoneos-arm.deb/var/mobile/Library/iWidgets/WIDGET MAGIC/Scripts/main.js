var updateWeatherEvery = updateInterval*60*1000;

var xmldata = false;

var postal;

var refreshLocationTimer;

var updateTimer = 0;

var iconSet = 77;

var zip;

var tsize = 58;

var tpos = 102;

switch (lang) {

case "cn":
		var days=["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
		var months=['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];

var tsize = 32;

var tpos = 125;

break;

case "fr":

	var days = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];

	var months=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];

break;

case "de":

	var days = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];

	var months=["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];		

break;

case "da":

	var days = ["S&Oslash;ndag","Mandag","Tirsdag","Onsdag","Torsdag","Fredag","L&Oslash;rdag"];

	var months=["Januar","Februar","Marts","April","Maj","Juni","Juli","August","September","Oktober","November","December"];		

break;

case "sp":

	var days = ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];

	var months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

break;

case "it":

	var days = ["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"];

	var months=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];

break;

case "tr":

	var days = ["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"];

	var months=['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];

break;


default: 

	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

	var months=["January","February","March","April","May","June","July","August","September","October","November","December"];

break;

}

function updateClock() { 

var currentTime = new Date();

var currentHours = currentTime.getHours();

var year = currentTime.getFullYear();

var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();

var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();

var currentDate = currentTime.getDate();

timeOfDay = ( currentHours < 12 ) ? "am" : "pm";



if (Clock == "24h") {

	timeOfDay = "";

	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;

	currentTimeString = currentHours + ":" + currentMinutes;

       document.getElementById("hour").innerHTML = currentHours;

       document.getElementById("minute").innerHTML = currentMinutes;

       document.getElementById("second").innerHTML = currentSeconds;

       document.getElementById("ampm").innerHTML = timeOfDay;

document.getElementById("newdate").innerHTML = currentDate + ". " + months[currentTime.getMonth()]

	}

if (Clock == "12h") {

	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

	currentHours = ( currentHours == 0 ) ? 12 : currentHours;

currentHours = ( currentHours < 10 ? "":"" ) + currentHours;

	currentTimeString = currentHours + ":" + currentMinutes;

       document.getElementById("hour").innerHTML = currentHours;

       document.getElementById("minute").innerHTML = currentMinutes;

       document.getElementById("second").innerHTML = currentSeconds;

       document.getElementById("ampm").innerHTML = timeOfDay;

document.getElementById("newdate").innerHTML = months[currentTime.getMonth()] + " " + currentDate

}

document.getElementById("year").innerHTML = year;

document.getElementById("weekday").innerHTML = days[currentTime.getDay()];

document.getElementById("date").innerHTML = currentDate;

document.getElementById("month").innerHTML = months[currentTime.getMonth()];





if (currentTime.getTime() - updateTimer >= updateWeatherEvery) {

	if (updateTimer == 0) {

		if (gps == true) { UpdateLocation(); } else { validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal); }

		} else {

		weatherRefresherTemp(zip);

		}

	updateTimer = currentTime.getTime();

	}

}

 

function init(){

document.getElementById("cityname").innerHTML = "Loading...";



updateClock();

setInterval("updateClock();", 1000);

}



function setPostal(obj){

	if (obj.error == false){

		if(obj.cities.length > 0) {

			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")

			convertWoeid();

			}

			else

			{

			document.getElementById("cityname").innerHTML="Locale ?!";

			}

		}

		else

		{

		document.getElementById("cityname").innerHTML="Locale ?!";

		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));

		}

}



function weatherRefresherTemp(zip){

	fetchWeatherData(dealWithWeather, zip);

}



function validateWeatherLocation (location, callback) {

	var obj = {error:false, errorString:null, cities: new Array};

	obj.cities[0] = {zip: location};

	callback (obj);

}



function dealWithWeather(obj){

	if (obj.error == false){

		document.getElementById("cityname").innerHTML = obj.city;

		document.getElementById("weatherIcon").src="Images/"+iconSet+"/"+obj.icon+".png";



	      if (tempUnit == "c") {

		document.getElementById("temp").innerHTML=obj.temp + "&#176;C";}

	      if (tempUnit == "f") {

		document.getElementById("temp").innerHTML=obj.temp + "&#176;F";}



		switch (lang) {
		
		case "cn":
		translatedesc=obj.description.toLowerCase();

			if (translatedesc=='sunny') {document.getElementById("desc").innerHTML='阳光明媚'; }
			if (translatedesc=='drizzle') {document.getElementById("desc").innerHTML='蒙蒙细雨'; }
			if (translatedesc=='heavy snow') {document.getElementById("desc").innerHTML='大雪纷飞'; }
			if (translatedesc=='heavy rain') {document.getElementById("desc").innerHTML='倾盆大雨'; }
			if (translatedesc=='rain and snow') {document.getElementById("desc").innerHTML='雨雪霏霏'; }
			if (translatedesc=='mixed rain and snow') {document.getElementById("desc").innerHTML='雨雪霏霏'; }
			if (translatedesc=='fair') {document.getElementById("desc").innerHTML='天朗气清';}
			if (translatedesc=='mostly sunny') {'document.getElementById("desc").innerHTML=风和日丽';}
			if (translatedesc=='partly sunny') {document.getElementById("desc").innerHTML='日丽风清';}
			if (translatedesc=='intermittent clouds') {document.getElementById("desc").innerHTML='云淡清';}
			if (translatedesc=='hazy sunshine') {document.getElementById("desc").innerHTML='日暖烟';}
			if (translatedesc=='haze') {document.getElementById("desc").innerHTML='十面霾伏';}
			if (translatedesc=='mostly cloudy') {document.getElementById("desc").innerHTML='浮云蔽日';}
			if (translatedesc=='cloudy') {document.getElementById("desc").innerHTML='乌云蔽日';}
			if (translatedesc=='fog') {document.getElementById("desc").innerHTML='云迷雾锁';}
			if (translatedesc=='showers') {document.getElementById("desc").innerHTML='疾风骤雨';}
			if (translatedesc=='partly sunny with showers') {document.getElementById("desc").innerHTML='晴空骤雨';}
			if (translatedesc=='thunderstorms') {document.getElementById("desc").innerHTML='电闪雷鸣';}
			if (translatedesc=='thunderstorm') {document.getElementById("desc").innerHTML='雷雨交加';}
			if (translatedesc=='mostly cloudy with thunder showers') {document.getElementById("desc").innerHTML='风潇雨晦';	   }
			if (translatedesc=='partly cloudy with thunder showers') {document.getElementById("desc").innerHTML='风雨如晦';	  }
			if (translatedesc=='light rain') {document.getElementById("desc").innerHTML='和风细雨';	      }
			if (translatedesc=='rain') {document.getElementById("desc").innerHTML= '细雨霖铃'; }
			if (translatedesc=='flurries') {document.getElementById("desc").innerHTML='流风回雪';  }
			if (translatedesc=='mostly cloudy with flurries') {document.getElementById("desc").innerHTML='云雪成欢';	  }
			if (translatedesc=='partly sunny with flurries') {document.getElementById("desc").innerHTML='晴雪初飞';	  }
			if (translatedesc=='snow flurries') {document.getElementById("desc").innerHTML='俄而雪骤';	  }
			if (translatedesc=='snow showers') {document.getElementById("desc").innerHTML='雨雪霏霏';	    }
			if (translatedesc=='snow') {document.getElementById("desc").innerHTML='大雪纷飞'; }
			if (translatedesc=='mostly cloudy with snow') {document.getElementById("desc").innerHTML='闲云弄雪';    }
			if (translatedesc=='ice') {document.getElementById("desc").innerHTML='冰天雪地'; }
			if (translatedesc=='sleet') {document.getElementById("desc").innerHTML='雨雪霏霏';	  }
			if (translatedesc=='freezing rain') {document.getElementById("desc").innerHTML='凄风冷雨';	    }
			if (translatedesc=='rain and snow mixed') {document.getElementById("desc").innerHTML='雨雪霏霏';	   }
			if (translatedesc=='hot') {document.getElementById("desc").innerHTML='骄阳似火'; }
			if (translatedesc=='cold') {document.getElementById("desc").innerHTML='天寒地冻'; }
			if (translatedesc=='windy') {document.getElementById("desc").innerHTML='风和日丽';	  }
			if (translatedesc=='clear') {document.getElementById("desc").innerHTML='晴空万里'; }
			if (translatedesc=='mostly clear') {document.getElementById("desc").innerHTML='风清云净';	     }
			if (translatedesc=='partly cloudy') {document.getElementById("desc").innerHTML='云淡风轻';	  }
			if (translatedesc=='hazy') {document.getElementById("desc").innerHTML='烟雾缭绕'; }
			if (translatedesc=='partly cloudy with showers') {document.getElementById("desc").innerHTML='雨霁云消';	      }
			if (translatedesc=='mostly cloudy with showers') {document.getElementById("desc").innerHTML='断雨残云';	  }
			if (translatedesc=='party cloudy with thunder showers') {document.getElementById("desc").innerHTML='雷雨交加';   }
			if (translatedesc=='foggy') {document.getElementById("desc").innerHTML='大雾迷茫';	  }
			if (translatedesc=='light snow') {document.getElementById("desc").innerHTML='流风回雪'; }
			if (translatedesc=='light snow showers') {document.getElementById("desc").innerHTML='流风回雪'; }		 
			if (translatedesc=='rain shower') {document.getElementById("desc").innerHTML='大雨滂沱';	   }
			if (translatedesc=='light drizzle') {document.getElementById("desc").innerHTML='和风细雨';	  }
			if (translatedesc=='mixed rain and sleet') {document.getElementById("desc").innerHTML='雨雪霏霏';	    }
			if (translatedesc=='mixed snow and sleet') {document.getElementById("desc").innerHTML='雨雪纷纷';	    }
			if (translatedesc=='severe thunderstorms') {document.getElementById("desc").innerHTML='电闪雷鸣';	    }
			if (translatedesc=='hurricane') {document.getElementById("desc").innerHTML='狂风暴雨';    }
			if (translatedesc=='tropical storm') {document.getElementById("desc").innerHTML='热带风暴';    }
			if (translatedesc=='tornado') {document.getElementById("desc").innerHTML='风卷残云';    }
			if (translatedesc=='freezing drizzle') {document.getElementById("desc").innerHTML='寒风冷雨';    }
			if (translatedesc=='blowing snow') {document.getElementById("desc").innerHTML='狂风暴雪'; }
			if (translatedesc=='hail') {document.getElementById("desc").innerHTML='天降冰雹'; }
			if (translatedesc=='dust') {document.getElementById("desc").innerHTML='飞沙走石';	    }
			if (translatedesc=='somky') {document.getElementById("desc").innerHTML='烟雾弥漫';	  }
			if (translatedesc=='blustery') {document.getElementById("desc").innerHTML='风起云涌';    }
			if (translatedesc=='mixed rain and hail') {document.getElementById("desc").innerHTML='冰雹带雨';	   }
			if (translatedesc=='isolated thunderstorms') {document.getElementById("desc").innerHTML='霹雳列缺';    }
			if (translatedesc=='isolated thundershowers') {document.getElementById("desc").innerHTML='霹雳列缺';    }
			if (translatedesc=='scattered thunderstorms') {document.getElementById("desc").innerHTML='电闪雷鸣';    }
			if (translatedesc=='scattered showers') {document.getElementById("desc").innerHTML='急风骤雨';    }
			if (translatedesc=='scattered snow showers') {document.getElementById("desc").innerHTML='骤雪初歇';    }
			if (translatedesc=='light rain with thunder') {document.getElementById("desc").innerHTML='雷雨交加';    }
			if (translatedesc=='not available') {document.getElementById("desc").innerHTML='自行判断';	  }
			if (translatedesc=='drifting snow/windy') {document.getElementById("desc").innerHTML='西门吹雪';	   }
			if (translatedesc=='light rain shower') {document.getElementById("desc").innerHTML='骤雨初歇'; }
			if (translatedesc=='thunder') {document.getElementById("desc").innerHTML='雷电交加'; }
			if (translatedesc=='mostly cloudy/windy') {document.getElementById("desc").innerHTML='风卷残云'; }
			if (translatedesc=='sandstorm') {document.getElementById("desc").innerHTML='飞沙走砾'; }
			if (translatedesc=='squalls/windy') {document.getElementById("desc").innerHTML='狂风肆虐'; }
			if (translatedesc=='sand') {document.getElementById("desc").innerHTML='尘土飞扬'; }
			if (translatedesc=='sandstorm/windy') {'document.getElementById("desc").innerHTML=飞沙走石'; }
			if (translatedesc=='squalls') {document.getElementById("desc").innerHTML='狂风肆虐'; }
		break;		
		

		case "fr":
			translatedesc=obj.description.toLowerCase();

			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Brouillard';	}
			
			if (translatedesc=='cloudy/windy') { document.getElementById("desc").innerHTML='nuageux et venteux'; }

			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Ensoleill&eacute;'; }

			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruine'; }

			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Fortes chutes de neige'; }

			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Fortes averses'; }

			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige'; }

			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es'; }

			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Ciel d&eacute;gag&eacute;';    }

			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Quelques nuages';	  }

			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Partiellement nuageux';   }

			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuages &eacute;parses';	 }

			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;rement voil&eacute;';	}

			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Brume'; }

			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux';	 }

			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuageux';    }

			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Brouillard';	  }

			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Averses';	}

			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleil et averses';    }

			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Orages';    }

			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Orage';    }

			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et fortes averses';	  }

			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Soleil et fortes averses';    }

			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re pluie';	  }

			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pluie';    }

			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Averses de neige';	}

			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux avec neige';   }

			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Soleil et averses de neige';    }

			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Averses de neige';    }

			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Averses de neige';    }

			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neige';    }

			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et neige';    }

			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Glace';	}

			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Verglas';    }

			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Pluie vergla&ccedil;ante';	 }

			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es';	}

			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Chaud';	  }

			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Froid';   }

			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vent';    }

			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Clair';    }

			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Tr&egrave;s clair';	}

			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Partiellement nuageux';	 }

			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Brume';    }

			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et averses';	}

			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et averses';	  }

			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et fortes averses';	 }

			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Brouillard';	 }

			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Flocons de neige'; }

			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;res chutes de neige'; }        

			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Averses';    }

			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re bruine';	  }

			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Pluie et verglas';    }

			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Neige et verglas';    }

			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Gros orages';	 }

			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Ouragan';	  }

			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Orage tropical';    }

			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornade';	}

			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Buine vergla&ccedil;ante';	  }

			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Rafales de neige'; }

			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Gr&ecirc;le'; }

			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Poussi&eacute;reux';	}

			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Brumeux';    }

			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Temp&ecirc;te';    }

			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Pluie et Gr&ecirc;le m&eacute;l&eacute;es';    }

			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Orages isol&eacute;s';    }

			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Averses isol&eacute;s';    }

			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Orages &eacute;parses';    }

			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Averses &eacute;parses';	 }

			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Chutes de neige &eacute;parses';    }

			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pluie l&eacute;g&egrave;re et &eacute;clairs';    }

			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Non disponible';    }

			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Neige poudreuse et vent';    }

			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re averse'; }

			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tonnerre'; }

			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et vent'; }

			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable'; }

			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Rafales de vent'; }

			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Sable'; }

			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable et vent'; }

			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Rafales'; }

		break;

		case "de":

			translatedesc=obj.description.toLowerCase();

if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Meist bewölkt und windig'; }


			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado!'; }
			
			if (translatedesc=='cloudy/windy') { document.getElementById("desc").innerHTML='Bewölkt u. Windig'; }

			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Leichter Schneefall'; }

			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropischer Sturm'; }

			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Wirbelsturm'; }

			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Schwere Gewitter'; }

			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Gewitter'; }

			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Gewitter'; }


			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Regen und Schnee'; }

			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Regen und Schnee'; }

			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Graupelschauer'; }

			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }

			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Gefrierender Nieselregen'; }

			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Nieselregen'; }

			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Gefrierender Regen'; }

			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Schauer'; }

			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Schneegest&ouml;ber'; }

			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }

			if (translatedesc=='light snow grains') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }

			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Schneetreiben'; }

			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Schnee'; }

  if (translatedesc=='snow shower') { document.getElementById("desc").innerHTML='Schneeschauer';}

			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Hagel'; }

			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }

			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Staubig'; }

			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebelig'; }

			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Dunstschleier'; }

			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Dunstig'; }

			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='St&uuml;rmisch'; }

			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Windig'; }

			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Kalt'; }

			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Bew&ouml;lkt'; }

			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Meist Bew&ouml;lkt'; }

			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt'; }

			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Klar'; }

			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Sonnig'; }

			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Heiter'; }

			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Regen und Hagel'; }

			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Heiss'; }

			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='&Ouml;rtliche Gewitter'; }

			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Vereinzelte Gewitter'; }

			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Vereinzelte Schauer'; }

			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Starker Schneefall'; }

			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Vereinzelte Schneeschauer'; }

			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt'; }

			if (translatedesc=='thundershowers') { document.getElementById("desc").innerHTML='Gewitter'; }

			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Scheeschauer'; }

			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Ouml;rtliche Gewitterschauer'; }

			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Leichte Regenschauer'; }

			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='nicht verfuegbar'; }

			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Schauer'; }

			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Teilweise Sonnig'; }

			if (translatedesc=='ground fog') { document.getElementById("desc").innerHTML='Bodennebel'; }

			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Leichter Nieselregen'; }

			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Leichter Regen'; }

			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Nebel'; }

			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebel'; }

			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Regen'; }

			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Regenschauer'; }

			if (translatedesc=='severe thunderstorm/windy') { document.getElementById("desc").innerHTML='Schwere Gewitter/Windig'; }

		break;

case "da":

			translatedesc=obj.description.toLowerCase();

			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Tåge';	  }

			if (translatedesc=='cloudy/windy') { document.getElementById("desc").innerHTML='uklar og blæsende'; }

			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado!'; }

			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropisk Storm'; }

			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Tornado'; }

			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Kraftig Regn'; }

			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Torden'; }

			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Storm'; }

			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Regn og Sne'; }

			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Regn og Slud'; }

			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Sne og Sludn'; }

			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Frost T&aring;ge Regn'; }

			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='T&aring;ge Regn'; }

			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Isslag'; }

			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Regnbyger'; }

			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Sne Storm'; }

			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Let Snefald'; }

			if (translatedesc=='light snow grains') { document.getElementById("desc").innerHTML='Let Snefald'; }

			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Bl&aelig;sende Snefald'; }

			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Sne'; }

			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Hagl'; }

			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Slud'; }

			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='St&oslash;vet'; }

			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='T&aring;get'; }

			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Diset'; }

			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Diset'; }

			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Stormende'; }

			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Bl&aelig;sende'; }

			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Koldt'; }

			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Skyet'; }

			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Mest Skyet'; }

			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Delvis skyet'; }

			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Klart'; }

			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Solrigt'; }

			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='KLart'; }

			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Regn og Hagl'; }

			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Varmt'; }

			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Enkelte tordenbyger'; }

			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Spredte Tordenbyger'; }

			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Enkelte byger'; }

			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='St&AElig;rkt Snefald'; }

			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Spredte Snebyger'; }

			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Delvis Overskyet'; }

			if (translatedesc=='thundershowers') { document.getElementById("desc").innerHTML='Torden'; }

			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Snebyger'; }

			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Enkelte Tordenbyger'; }

			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Lette Regnbyger'; }

			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Ingen Info'; }

			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Regnbyger'; }

			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Delvis Sol'; }

			if (translatedesc=='ground fog') { document.getElementById("desc").innerHTML='T&aring;get'; }

			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Sm&aring; Regn'; }

			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Let Regn'; }

			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='T&aring;ge'; }

			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='T&aring;ge'; }

			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Regn'; }

			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Regnbyger'; }

			if (translatedesc=='severe thunderstorm/windy') { document.getElementById("desc").innerHTML='Kraftig Vind'; }

		break;


		case "sp":

			translatedesc=obj.description.toLowerCase();

			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Niebla';    }
			
			if (translatedesc=='cloudy/windy') { document.getElementById("desc").innerHTML='nublado y ventoso'; }

			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleado'; }

			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Llovizna'; }

			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Nieve fuerte'; }

			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Luvia fuerte'; }

			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Lluvia y nieve'; }

			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve'; }

			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Despejado';    }

			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='May. soleado';	  }

			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parc. soleado';  }

			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Intermitente nublado';	 }

			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sol brumoso';	}

			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Bruma'; }

			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='May. nublado';  }

			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nublado';    }

			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Niebla';   }

			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Chubascos';	}

			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Parc. soleado con chubascos';    }

			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas';    }

			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tormenta electrica';	}

			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='May. nublado con tormentas de chubascos';   }

			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Parc. soleado con tormentas de chubascos';   }

			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Lluvia ligera';	  }

			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Lluvia';    }

			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Rafagas';	}

			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='May. nublado con rafagas';   }

			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parc. soleado con rafagas';    }

			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Rafagas de nieve';    }

			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve';    }

			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Nieve';    }

			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='May. nublado con nieve';    }

			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Hielo';	}

			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Aguanieve';	}

			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Lluvia bajo cero';	 }

			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve';	}

			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caluroso';	  }

			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Frio';	 }

			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vientoso';    }

			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Despejado';	}

			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='May. despejado';	}

			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Par. despejado';	 }

			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Bruma';    }

			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Parc. nublado con chubascos';	}

			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='May. nublado con chubascos';	  }

			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parc. nublado con tormentas de chubascos';  }

			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Neblina';	 }

			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Nieve ligera'; }

			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Ligeras precipitaciones de nieve'; }	 

			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia';    }

			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruma';    }

			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Mezcla de lluvia y aguanieve';	  }

			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Mezcla de nieve y aguanieve';	 }

			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas severas';	 }

			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Huracan';	  }

			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tormenta tropical';	 }

			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}

			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Llovizna helada';	  }

			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Viento y nieve'; }

			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Granizo'; }

			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvareda';	}

			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }

			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempestuoso';    }

			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Mezcla de lluvia y granizo';    }

			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas aisladas';    }

			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Tormentas aisladas';    }

			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas dispersas';    }

			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Chubascos dispersos';	 }

			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve dispersas';	  }

			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='LLuvia y tormenta ligera';	 }

			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }

			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Acumulacion de nieve y viento';	  }

			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia ligera';   }

			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Truenos'; }

			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='May. nublado y ventoso'; }

			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormentas de arena'; }

			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Chubascos y viento'; }

			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }

			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormentas de arena y ventoso'; }

		break;

		case "it":

			translatedesc=obj.description.toLowerCase();

			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Nebbia';    }
			
			if (translatedesc=='cloudy/windy') { document.getElementById("desc").innerHTML='nuvoloso e ventoso'; }

			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleggiato'; }

			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Pioggerella'; }

			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Forti nevicate'; }

			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Forti piogge'; }

			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Vevischio'; }

			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Misto pioggia e neve'; }

			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Sereno';    }

			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Molto soleggiato';	  }

			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parzialmente soleggiato';   }

			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	 }

			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sole coperto'; }

			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Nebbia'; }

			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Molto nuvoloso';	 }

			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuvoloso';	}

			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebbia';   }

			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Diluvio';	}

			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleggiato con pioggia';	 }

			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Fulmini';    }

			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tuoni';    }

			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Molto Nuvoloso con pioggia e fulmini';	  }

			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Possibili Piogge';    }

			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Pioggia leggera';   }

			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pioggia';    }

			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Nevischio'; }

			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Nuvoloso con nevischio';   }

			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parzialmente soleggiato con neve';    }

			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Raffiche di neve';    }

			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitazioni nevose';    }

			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neve';	  }

			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Molto nuvoloso con neve';	}

			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Ghiaccio';	}

			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Nevischio';	}

			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Grandine';	 }

			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pioggia e neve'; }

			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caldo';	  }

			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Freddo';   }

			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Ventoso';    }

			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Sereno';    }

			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Molto sereno';	}

			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso';	 }

			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Velato';    }

			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Cielo velato';	}

			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	  }

			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso con raffiche';	 }

			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebbiolina';	 }

			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Neve leggiera'; }

			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Poca neve'; }	  

			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Forti precipitazioni';	 }

			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Freddino';	 }

			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Misto pioggia e nevischio';    }

			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Misto neve e nevischio';    }

			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tuoni e fulmini';	 }

			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Uragano';	  }

			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tempesta tropicale';	  }

			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}

			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Grandine';	  }

			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Vento e neve'; }

			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Grandine'; }

			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvere';	}

			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }

			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempesa';	 }

			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='misto neve e grandine';	  }

			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Fulmini isolati';    }

			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Temporali isolati';	  }

			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tempesta di fulmini';    }

			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Tempesta di pioggia';	 }

			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Neve sparsa';    }

			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pioggia leggera con fulmini';    }

			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }

			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Troppa neve';	}

			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Piccole precipitazioni';	  }

			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tuoni'; }

			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Molto nuvoloso con vento'; }

			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormenta'; }

			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Pioggia e vento'; }

			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }

			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormenta ventosa'; }

		break;

case "tr":

			translatedesc=obj.description.toLowerCase();

if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Sis';	 }

			if (translatedesc=='cloudy/windy') { document.getElementById("desc").innerHTML='bulutlu ve rüzgarlı'; }

			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Güneşli'; }

			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Hafif Yağmur'; }

			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Yoğun Kar'; }

			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Çok Yağmurlu'; }

			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Yağmur ve Kar'; }

			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Karla Karışık Yağmur'; }

			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Açık';	  }

			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Çok Güneşli';	  }

			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Hafif Güneşli';   }

			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Parçalı Bulutlu';	 }

			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Puslu Güneşli'; }

			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Puslu'; }

			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Çok Bulutlu';	 }

			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Bulutlu';	}

			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Sisli';	 }

			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Sağanak';	}

			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Hafif Güneşli Yağmur';	 }

			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Gök Gürültülü';    }

			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Gök Gürültülü';    }

			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Gök Gürültülü Bulutlu';	  }

			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Gök Gürültülü Güneşli';	}

			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Hafif Yağmur';   }

			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Yağmurlu';    }

			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Esintili'; }

			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Çok Bulutlu Esintili';	}

			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Hafif Hüneşli Esintili';	  }

			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Kar Esintisi';    }

			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Kar Yağışlı';	 }

			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Karlı';   }

			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Çok Bulutlu ve Karlı';	}

			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Buzlu';	}

			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Sulu Kar';	}

			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Dondurucu Yağmur';	 }

			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Karla Karışık Yağmur'; }

			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Sıcak';	  }

			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Soğuk';   }

			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Rüzgarlı';    }

			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Açık';    }

			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Çok Açık';	}

			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Hafif Açık';	 }

			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Puslu';    }

			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Parçalı Bulutlu Sağanak'; }

			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Çok Bulutlu Sağanak';	  }

			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parçalı Bulutlu Gök Gürültülü';	 }

			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Sisli';	 }

			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Hafif Karlı'; }

			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Hafif Kar Yağışlı'; }	  

			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Sağanak Yağmur';  }

			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Hafif Yağmur';	 }

			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Sulusepken Yağmurlu';	 }

			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Sulusepken Karlı';    }

			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Yoğun Gök Gürültülü';	 }

			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Kasırga';	  }

			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropikal Fırtına';	  }

			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Hortum';	}

			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Dondurucu Hafif Yağmur';	  }

			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Rüzgarlı Kar'; }

			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Dolu Yağışı'; }

			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Tozlu'; }

			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Nemli';    }

			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Şiddetli Rüzgar';	 }

			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Dolu Karışık Yağmurlu';	  }

			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='İzole Gök Gürültülü';    }

			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='İzole Yağmurlu';	  }

			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Dağınık Gök Gürültülü';    }

			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Dağınık Yağmurlu';  }

			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Dağınık Kar Yağışlı';    }

			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Hafif Yağmurlu Gök Gürültülü';    }

			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Veri Yok';    }

			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Karlı Savurgan Rüzgar';	}

			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Hafif Sağanak Yağmurlu';	  }

			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Gök Gürültülü'; }

			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Çok Bulutlu Rüzgarlı'; }

			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Kum Fırtınası'; }

			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Uğultulu Rüzgar'; }

			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Kum'; }

			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Kumlu Rüzgar'; }

		break;


		default:		       

			document.getElementById("desc").innerHTML=obj.description;

		break;

		}

}

}



function findChild (element, nodeName) {

	var child;

	for (child = element.firstChild; child != null; child = child.nextSibling)

	{

		if (child.nodeName == nodeName)

			return child;

	}

	return null;

}



function convertWoeid () {

		var url = "http://weather.yahooapis.com/forecastrss?w="+postal+"&u=f";

		$.get(url, function(data) {

		zip = $(data).find('guid').text().split('_')[0];

		weatherRefresherTemp(zip);

		});

}



function fetchWeatherData (callback, zip) {

	var url="http://xml.weather.yahoo.com/forecastrss/" + zip + "_" + tempUnit + ".xml";

	var xml_request = new XMLHttpRequest();

	var requestTimer = setTimeout(function() {

	xml_request.abort();

	if (xmldata == false) { callback ({error:true}); } else {

	document.getElementById("coordinates").className = "TextColorRed"; 

	document.getElementById("coordinates").innerHTML = "[Offline]"; }

    }, 10000);

	xml_request.onload = function(e) {

	clearTimeout(requestTimer);

	xml_loaded(e, xml_request, callback);

	}

	xml_request.overrideMimeType("text/xml");

	xml_request.open("GET", url);

	xml_request.setRequestHeader("Cache-Control", "no-cache");

	xml_request.send(null);

	return xml_request;

}



function xml_loaded (event, request, callback) {

	if (request.responseXML)

	{

		var obj = {error:false, errorString:null};

		xmldata = true;

		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");

		if (gps == false) {

		if (city == "") { obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city"); }

		else { obj.city = city }

		} else { obj.city = city; }

		obj.chill = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");

		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");

		var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");

		obj.temp = conditionTag.getAttribute("temp");

		obj.icon = conditionTag.getAttribute("code");

		obj.description = conditionTag.getAttribute("text");

		var forecast = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");

		obj.todaylow = forecast.getAttribute("low");

		obj.todayhigh = forecast.getAttribute("high");

		if (obj.description == "Unknown") {

			obj.description = forecast.getAttribute("text");

			obj.icon = forecast.getAttribute("code");

		}

		if (obj.icon == 3200) obj.icon = 48;	

		callback (obj); 

	}

	else

	{

		callback ({error:true, errorString:"XML request failed. no responseXML"});

	}

}