iATS Alien READ-ME

Thank you for purchasing iATS Alien. This guide should help you with ANY issues you may have, and anything you cant find in here, ask in the thread on MMI!

I will start by addressing common topics and work down to more advanced customization options.


****SlideShows****

There are 4 different slideshows, all of which can be customized.  They are all located in "/Dreamboard/iATS Alien/Widgets/Slideshow Widgets/"

The "Auto Fit" Slideshow is the easiest one to personalize with your own images.  Simply replace the images located in "/Walls" with your own photos. The photos must be 320x480 or 640x960, and the filenames must be numbered 1.png, 2.png, 3.png, etc.

The other 3 Slideshows require the use of the included Template.psd for creating the Wall images.


****Weather****

The weather widgets in this theme are set to GPS mode by default, requiring CrazyIvek's GPS MyLocation app to work properly (available free on Cydia).

However, it is not too difficult to change the settings of the widgets to use a specified zip code. Using iFile or SSH, simply navigate to "Dreamboard/iATS Alien/Widgets/Weather Widgets" where you will find the weather widgets. In each widget you will find "config.js" files. When you open them with a text editor, you will see instructions on how to change from GPS to Static. You can also manually toggle F/C and other options using the config file.


****Sound Effects****

Download "DreamSounds" from Cydia to automatically enable the optional sound effects that are integrated into the theme.


****Clocks****

Clocks can be changed from 12hr to 24hr by navigating to the Widgets folder in the theme and opening the config.js file of the Clock widget you would like to change and instructions are inside.


****Changing RSS Feed****

Navigate to "/Dreamboard/iATS Alien/Widgets/RSS/" and open Widget.html with a text editor.  Find and replace "http://feeds.modmyi.com/home_all" with the url of the feed you would like to use instead. Respring to apply changes.


****Using Custom Apps in the Inner Launcher****

There are alternate category icons located in "/Dreamboard/iATS Alien/Images/Alt Category Icons". You can use any of these icons by simply replacing the ones located in "/Images."

Making the buttons launch different apps, however, is a little more complicated. Edit "Theme.plist" and search for the app BundleID you want to replace (for instance, if you want to replace Safari with Chrome, you will search for "com.apple.safari"). Now, just replace every instance of that app's BundleID with the one you want to use instead (in this scenario, replace every instance of "com.apple.safari" with "com.google.chrome.ios") Respring and the changes should take effect.


****MAKING ICON AND WIDGET CHANGES STAY****

If for some reason your icons and widget options do not stick, you will need to navigate to "/DreamBoard/iATS Alien/Theme.plist" and change the permissions of the file to "Owner: Mobile" and allow permissions to Read, Write and Execute.


Thank you sincerely for purchasing iATS Alien! I will update this ReadMe whenever I think of any other useful information or if I recieve any good suggestions.