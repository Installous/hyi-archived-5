var ColorAmount = 3;
var color1 = "#f44336";
var color2 = "#fdd835";
var color3 = "#1e88e5";
var color4 = "Black";
var color5 = "Brown";
var BackgroundColor = "Pink";
