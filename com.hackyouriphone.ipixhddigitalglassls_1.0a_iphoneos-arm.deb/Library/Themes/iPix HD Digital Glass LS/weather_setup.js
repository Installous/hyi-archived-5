// Set the the name of your city, state or town as you would like it to appear on your lockscreen.
var locName="London, UK";


// Enter your Zip or Postal Code for UK, US or Canada. For other countries please enter city name.
var loc="E12DA";


// Set to C for weather in celsius or F for farenheit.
var tempUnit="c";


//Choose colour, available colours are red, blue, purple, gold, green, turquoise or black.
var colour_scheme="purple"; 