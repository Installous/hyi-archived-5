// Translation file for UniAW6.2 by Ian Nicoll, with credit to Dacal


// TRANSLATION FOR MAIN ELEMENTS

switch (lang) {
	case "cn":
		var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
		var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
		var hightext = "最高 : ";
		var lowtext = "最低 : ";
		var sunrisetext = "日出";
		var sunsettext = "日落";
		var feelsliketext = "Feels like : ";
		var pressuretext = "最高 : ";	
		var lastupdatetext = "上次更新 : ";
		var visibilitytext = "能见度 : ";
		var humiditytext = "湿度 : ";
		var windtext = "风向 : ";
	break;
	case "fi":
		var days = ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"];
		var months = ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kesäkuu", "Heinäkuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"];
		var hightext = "Korkein : ";
		var lowtext = "Alin : ";
		var sunrisetext = "Aamu";
		var sunsettext = "Yö";
		var feelsliketext = "Feels like : ";
		var pressuretext = "Paine : ";	
		var lastupdatetext = "Päivitetään : ";
		var visibilitytext = "Näkyvyys : ";
		var humiditytext = "Ilmankosteus : ";
		var windtext = "Tuuli : ";
    break;	
	case "fr":
		var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
		var months = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre"];
		var hightext = "Max : ";
		var lowtext = "Min : ";
		var sunrisetext = "Lever";
		var sunsettext = "Coucher";
		var feelsliketext = "Ressentie : ";
		var lastupdatetext = "Mise à jour : ";
		var humiditytext = "Humidité : ";	
		var visibilitytext = "Visibilité : ";	
		var pressuretext = "Pression : ";
		var windtext = "Vent : ";
    break;
	case "ge":
		var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
		var months = ["Januar", "Februar", "Maerz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
		var hightext = "Hoch : ";
		var lowtext = "Tief : ";
		var sunrisetext = "Morgen";
		var sunsettext = "Abend";
		var feelsliketext = "Feels like : ";
		var lastupdatetext = "Letztes Update : ";
		var visibilitytext = "Sichtweite : ";
		var humiditytext = "Luftfeuchte : ";
		var pressuretext = "Luftdruck : ";
		var windtext = "Wind : ";	
	break;
	case "nl":
		var days = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
		var months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];
		var hightext = "Hoog : ";
		var lowtext = "Laag : ";
		var sunrisetext ="Ochtend";
		var sunsettext = "Nacht";
		var feelsliketext = "Feels like : ";
		var lastupdatetext = "Laatste Update : ";
		var humiditytext = "Vochtigheid : ";
		var visibilitytext = "Zichtbaarheid : ";	
		var pressuretext = "Druk : ";
		var windtext = "Wind : ";
	break;
	case "sp":
		var days = ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"];
		var months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
		var hightext = "Alto : ";
		var lowtext = "Bajo : ";
		var sunrisetext ="Mañana";
		var sunsettext = "Noche";
		var feelsliketext = "Feels like : ";
		var lastupdatetext = "Actualizado : ";
		var humiditytext = "Humedad : ";
		var visibilitytext = "Visibilidad : ";
		var pressuretext = "Presion : ";
		var windtext = "Viento : ";
    break;
	case "it":
		var days = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
		var months = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
		var hightext = "Alto : ";
		var lowtext = "Basso : ";
		var sunrisetext ="Alba";
		var sunsettext = "Tramonto";
		var feelsliketext = "Feels like : ";
		var lastupdatetext = "Attuale : ";
		var humiditytext = "Umidita : ";
		var visibilitytext = "Visibilita : ";
		var pressuretext = "Pressione : ";
		var windtext = "Vento : ";	
    break;
	case "ru":
		var days = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
		var months = ['Января','Февраля','Марта','Апреля','Мая','Июня','Июля','Августа','Сентября','Октября','Ноября','Декабря'];
		var hightext = "привет : ";
		var lowtext = "вот : ";
		var sunrisetext ="утро";
		var sunsettext = "закат";
		var feelsliketext = "Feels like : ";
		var lastupdatetext = "обновлены в : ";
		var humiditytext = "Влажность : ";
		var visibilitytext = "видимость : ";
		var pressuretext = "давление : ";
		var windtext = "ветер : ";
	break;
	default: 
		var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		var hightext = "Hi : ";
		var lowtext = "Lo : ";
		var sunrisetext ="Sunrise";
		var sunsettext = "Sunset";
		var feelsliketext = "Feels like : ";
		var lastupdatetext = "Last update : ";
		var humiditytext = "Humidity : ";
		var visibilitytext = "Visibility : ";
		var pressuretext = "Pressure : ";
		var windtext = "Wind : ";
	break;
}


var WeatherDesc = [
	"Tornado",
	"Tropical Storm",
	"Hurricane",
	"Severe Thunderstorms",
	"Thunderstorms",
	"Mixed Rain and Snow",
	"Mixed Rain and Sleet",
	"Mixed Snow and Sleet",
	"Freezing Drizzle",
	"Drizzle",
	"Freezing Rain",
	"Showers",
	"Showers",
	"Snow Flurries",
	"Light Snow Showers",
	"Blowing Snow",
	"Snow",
	"Hail",
	"Sleet",
	"Dust",
	"Foggy",
	"Haze",
	"Smoky",
	"Blustery",
	"Windy",
	"Cold",
	"Cloudy ",
	"Mostly Cloudy",
	"Mostly Cloudy",
	"Partly Cloudy",
	"Partly Cloudy",
	"Clear",
	"Sunny",
	"Fair",
	"Fair",
	"Mixed Rain and Hail",
	"Hot",
	"Isolated Thunderstorms",
	"Scattered Thunderstorms",
	"Scattered Thunderstorms",
	"Scattered Showers",
	"Heavy Snow",
	"Scattered Snow Showers",
	"Heavy Snow",
	"Partly Cloudy",
	"Thundershowers",
	"Snow Showers",
	"Isolated Thundershowers",
	"Not Available"
];

var MoonDesc = [
	"Not Used",
	"New Moon",
	"Waxing Crescent",
	"Waxing Crescent",
	"Waxing Crescent",
	"Waxing Crescent",
	"Waxing Crescent",
	"First Quarter",
	"Waxing Gibbous",
	"Waxing Gibbous",
	"Waxing Gibbous",
	"Waxing Gibbous",
	"Waxing Gibbous",
	"Waxing Gibbous",
	"Full Moon",	
	"Waning Gibbous",
	"Waning Gibbous",
	"Waning Gibbous",
	"Waning Gibbous",
	"Waning Gibbous",
	"Waning Gibbous",
	"Last Quarter",
	"Waning Crescent",
	"Waning Crescent",
	"Waning Crescent",
	"Waning Crescent",
	"Waning Crescent",
	"Waning Crescent"
];

// TRANSLATION FOR WEATHER CONDITIONS (NOT AVAILABLE FOR NATIVE)
function Translate(desc) {
var translatedesc = desc.toLowerCase();		
switch (lang) {
		case "cn":
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='阳光明媚'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='蒙蒙细雨'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='大雪纷飞'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='倾盆大雨'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='雨雪霏霏'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='雨雪霏霏'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='天朗气清';	  }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='风和日丽';	       }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='日丽风清';	 }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='云淡风清';	}
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='日暖生烟';        }
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='十面霾伏'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='浮云蔽日';   }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='乌云蔽日';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='云迷雾锁';	    }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='疾风骤雨';    }
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='晴空骤雨';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='电闪雷鸣';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='雷雨交加'; }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='风潇雨晦';	 }
			if (translatedesc=='partly cloudy with thunder showers') { document.getElementById("desc").innerHTML='风雨如晦';	}
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='和风细雨';	    }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='细雨霖铃'; }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='流风回雪';  }
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='云雪成欢';	}
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='晴雪初飞';	}
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='俄而雪骤';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='雨雪霏霏';	  }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='大雪纷飞'; }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='闲云弄雪';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='冰天雪地'; }
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='雨雪霏霏';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='凄风冷雨';      }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='雨雪霏霏';	 }
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='骄阳似火'; }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='天寒地冻'; }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='风和日丽';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='晴空万里'; }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='风清云净';	   }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='云淡风轻'; 	}
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='烟雾缭绕'; }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='雨霁云消';	    }
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='断雨残云';	}
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='雷雨交加';   }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='大雾迷茫';    }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='流风回雪'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='流风回雪'; }	       
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='大雨滂沱';	 }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='和风细雨';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='雨雪霏霏';	  }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='雨雪纷纷';	  }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='电闪雷鸣';	  }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='狂风暴雨';    }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='热带风暴';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='风卷残云';    }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='寒风冷雨';    }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='狂风暴雪'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='天降冰雹'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='飞沙走石';	  }
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='烟雾弥漫';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='风起云涌';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='冰雹带雨';	 }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='霹雳列缺';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='霹雳列缺';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='电闪雷鸣';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='急风骤雨';    }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='骤雪初歇';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='雷雨交加';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='自行判断';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='西门吹雪';	 }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='骤雨初歇'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='雷电交加'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='风卷残云'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='飞沙走砾'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='狂风肆虐'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='尘土飞扬'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='飞沙走石'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='狂风肆虐'; }
			return desc;							
		break;		
		case "ru":
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Солнечно'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Изморось'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Сильный снег'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Сильный дождь'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Дождь со снегом'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Дождь со снегом'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Ясно';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Небольшая облачность';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Переменная облачность';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Прерывистая облачность';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Солнце и туман';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Туман'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Небольшая облачность';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Облачно';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Туман';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Дождь';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Солнце и дождь';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Бури';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Буря';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Облачно дождь с громом';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Солнце дождь с громом';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Небольшой дождь';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Дождь';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Порывы';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Облачно с порывами';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Солнце и порывы';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Снег с порывами';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Дождь со снегом';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Снег';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Облачно со снегом';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Лед';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Дождь со снегом';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Ледяной дождь';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Дождь и снег';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Горячий';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Холодный';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Ветер';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Ясно';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Ясно';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Переменная облачность';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Туман';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Облачно с дождем';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Солнечно с дождем';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Облачно с грозой';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Туман';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Небольшой снег'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Небольшой снег с дождем'; }       
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Ливень';    }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Мелкий дождь';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Дождь и мокрый снег';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Снег и мокрый снег';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Гроза';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Ураган';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Горячая буря';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Торнадо';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Изморозь';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Снежные заряды'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Град'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Пыль';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Туман';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Бурный';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Дождь и град';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Изолированные грозы';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Изолированные грозы с дождем';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Рассеянные грозы';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Рассеянный дождь';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Рассеянный снег с дождем';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Небольшой дождь с грозой';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Недоступно';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Снег/Ветер';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Слабый дождь';	  }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Гром'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Переменная облачность/Ветер'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Песчанная буря'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Всплеск/Ветер'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Песок'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Песочная буря/Ветер'; }
			return desc;
		break;									
		case "it":
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleggiato'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Pioggerella'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Forti nevicate'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Forti piogge'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Vevischio'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Misto pioggia e neve'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Sereno';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Molto soleggiato';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parzialmente soleggiato';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sole coperto';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Nebbia'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Molto nuvoloso';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuvoloso';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebbia';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Diluvio';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleggiato con pioggia';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Fulmini';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tuoni';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Molto Nuvoloso con pioggia e fulmini';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Possibili Piogge';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Pioggia leggera';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pioggia';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Nevischio';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Nuvoloso con nevischio';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parzialmente soleggiato con neve';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Raffiche di neve';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitazioni nevose';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neve';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Molto nuvoloso con neve';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Ghiaccio';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Nevischio';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Grandine';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pioggia e neve';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caldo';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Freddo';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Ventoso';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Sereno';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Molto sereno';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Velato';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Cielo velato';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso con raffiche';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebbiolina';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Neve leggiera'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Poca neve'; }       
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Forti precipitazioni';    }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Freddino';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Misto pioggia e nevischio';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Misto neve e nevischio';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tuoni e fulmini';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Uragano';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tempesta tropicale';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Grandine';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Vento e neve'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Grandine'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvere';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempesa';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='misto neve e grandine';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Fulmini isolati';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Temporali isolati';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tempesta di fulmini';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Tempesta di pioggia';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Neve sparsa';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pioggia leggera con fulmini';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Troppa neve';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Piccole precipitazioni';	  }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tuoni'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Molto nuvoloso con vento'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormenta'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Pioggia e vento'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormenta ventosa'; }
			return desc;
		break;
		case "fi":
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Aurinkoista'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Tihkusadetta'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Rankkaa lumisadetta'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Rankkasade'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='R&auml;nt&auml;&auml;'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Vesisadetta ja r&auml;nt&auml;&auml;'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Selke&auml;&auml;';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Melko selke&auml;&auml;';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Puolipilvist&auml;';	  }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Ajoittaisia pilvi&auml;';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Utuista auringonpaistetta';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Utuista';	}
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Enimm&auml;kseen pilvist&auml;';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Pilvist&auml;';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Sumua';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Sadekuuroja';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Puolipilvist&auml; ja sadekuuroja';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Ukkosmyrskyj&auml;';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Ukkosta';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Ukkoskuuroja';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Ukkoskuuroja';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Tihkusadetta';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Sadetta';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Lumisadetta';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Pilvist&auml; ja lumisadetta';	  }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Aurinkoista ja lumisadetta';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Lumisadetta';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Lumikuuroja';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Lumisadetta';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Melko pilvist&auml; ja lumisadetta';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Rakeita';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='R&auml;nt&auml;&auml;';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='J&auml;&auml;t&auml;v&auml;&auml; sadetta';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Vesi ja lumisadetta';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Hellett&auml;';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='kylm&auml;&auml;';	  }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Tuulista';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Selke&auml;&auml;';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Enimm&auml;kseen selke&auml;&auml;';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Puolipilvist&auml;';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Utuista';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Osittaisia sadekuuroja';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Pilvistä ja sadekuuroja';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Puolipilvist&auml; ja ukkoskuuroja';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Sumuista';    }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Heikkoa lumisadetta'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Heikkoja lumikuuroja'; }	
			if (translatedesc=='light snow shower') { document.getElementById("desc").innerHTML='Heikkoja lumikuuroja'; }
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Sadekuuroja';    }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Osittaista tihkusadetta';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Vesi ja r&auml;nt&auml;sadetta';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Lumi ja r&auml;nt&auml;sadetta';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Rankkoja ukkoskuuroja';    }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Py&ouml;rremyrsky';    }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Trooppinen myrsky';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornaado';    }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='J&auml;&auml;t&auml;v&auml;&auml; tihkusadetta';    }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Lumituisku'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Rakeita'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='P&ouml;lyist&auml;';    }
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Utuista';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Ei tietoja';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Vesisadetta ja raekuuroja';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Paikallisia ukkoskuuroja';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Paikallisia ukkoskuuroja';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Hajanaisia ukkoskuuroja';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Hajanaisia sadekuuroja';    }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Hajanaisia lumikuuroja';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Kevyit&auml; ukkoskuuroja';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Ei tietoja';    }
			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Sadetta l&auml;hell&auml;'; }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Lumipyry&auml;';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Kevyiyt&auml; sadekuuroja'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Ukkosta'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Enimm&auml;kseen tuulista'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Hiekkamyrsky'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Puuskaista tuulta'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Kuivaa tuulta'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTM= 'Tuulista'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Puuskaista tuulta'; }
			return desc;
		break;
		case "nl":
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Lichte Sneeuwval'; }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado!'; }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropische Storm'; }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Wervelwind'; }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Zware Onweersbuien'; }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Onweersbuien'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Regen en Sneeuw'; }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Regen en Ijzel'; }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Sneeuw en Ijzel'; }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Bevriezende Motregen'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Motregen'; }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Ijzel'; }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Buien'; }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Sneeuwvlagen'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Lichte Sneeuwbuien'; }
			if (translatedesc=='light snow grains') { document.getElementById("desc").innerHTML='Lichte Sneeuwbuien'; }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Sneeuw Drift'; }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Sneeuw'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Hagel'; }
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Ijzel'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Stoffig'; }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Mistig'; }
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Wazig'; }
			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Wazig'; }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Stormachtig'; }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Winderig'; }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Koud'; }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Bewolkt'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Algemeen Bewolkt'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Gedeeltelijk Bewolkt'; }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Helder'; }
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Zonnig'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Bewolkt Weer'; }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Regen en Hagel'; }
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Heet'; }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Geisoleerde Onweersbuien'; }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Verspreide Onweersbuien'; }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Verspreide Buien'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Zware Sneeuw'; }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Verspreide Sneeuwbuien'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Gedeeltelijk Bewolkt'; }
			if (translatedesc=='thundershowers') { document.getElementById("desc").innerHTML='Onweersbuien'; }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Sneeuwbuien'; }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Geisoleerde Onweersbuien'; }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Lichte Regenbuien'; }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='niet beschikbaar'; }
			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Lokale Regenbuien'; }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Gedeeltelijk Zonnig'; }
			if (translatedesc=='ground fog') { document.getElementById("desc").innerHTML='Grondmist'; }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Lichte Motregen'; }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Lichte Regen'; }
			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Mist'; }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Mist'; }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Regen'; }
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Regenbui'; }
			if (translatedesc=='severe thunderstorm/windy') { document.getElementById("desc").innerHTML='Zware Onweersbui/Winderig'; }
			return desc;
		break;
		case "fr":
			if (translatedesc=='sunny') { return 'Ensoleill&eacute;'; }
			if (translatedesc=='drizzle') { return 'Bruine'; }
			if (translatedesc=='heavy snow') { return 'Fortes chutes de neige'; }
			if (translatedesc=='heavy rain') { return 'Fortes averses'; }
			if (translatedesc=='rain and snow') { return 'Pluie et neige'; }
			if (translatedesc=='mixed rain and snow') { return 'Pluie et neige m&eacute;l&eacute;es'; }
			if (translatedesc=='fair') { return 'Ciel d&eacute;gag&eacute;';    }
			if (translatedesc=='mostly sunny') { return 'Tr&egrave;s ensoleill&eacute;';	  }
			if (translatedesc=='partly sunny') { return 'Partiellement nuageux';	  }
			if (translatedesc=='intermittent clouds') { return 'Nuages &eacute;parses';	 }
			if (translatedesc=='hazy sunshine') { return 'L&eacute;g&egrave;rement voil&eacute;';	}
			if (translatedesc=='haze') { return 'Brume';	}
			if (translatedesc=='mostly cloudy') { return 'Tr&egrave;s nuageux';	 }
			if (translatedesc=='cloudy') { return 'Nuageux';    }
			if (translatedesc=='fog') { return 'Brouillard';	  }
			if (translatedesc=='showers') { return 'Averses';	}
			if (translatedesc=='partly sunny with showers') { return 'Soleil et averses';    }
			if (translatedesc=='thunderstorms') { return 'Orages';    }
			if (translatedesc=='thunderstorm') { return 'Orage';    }
			if (translatedesc=='mostly cloudy with thunder showers') { return 'Tr&egrave;s nuageux et fortes averses';	  }
			if (translatedesc=='partly sunny with thunder showers') { return 'Soleil et fortes averses';    }
			if (translatedesc=='light rain') { return 'L&eacute;g&egrave;re pluie';	  }
			if (translatedesc=='rain') { return 'Pluie';    }
			if (translatedesc=='flurries') { return 'Averses de neige';	}
			if (translatedesc=='mostly cloudy with flurries') { return 'Tr&egrave;s nuageux avec neige';	  }
			if (translatedesc=='partly sunny with flurries') { return 'Soleil et averses de neige';    }
			if (translatedesc=='snow flurries') { return 'Averses de neige';    }
			if (translatedesc=='snow showers') { return 'Averses de neige';    }
			if (translatedesc=='snow') { return 'Neige';    }
			if (translatedesc=='mostly cloudy with snow') { return 'Tr&egrave;s nuageux et neige';    }
			if (translatedesc=='ice') { return 'Glace';	}
			if (translatedesc=='sleet') { return 'Verglas';    }
			if (translatedesc=='freezing rain') { return 'Pluie vergla&ccedil;ante';	 }
			if (translatedesc=='rain and snow mixed') { return 'Pluie et neige m&eacute;l&eacute;es';	}
			if (translatedesc=='hot') { return 'Chaud';	  }
			if (translatedesc=='cold') { return 'Froid';	  }
			if (translatedesc=='windy') { return 'Vent';    }
			if (translatedesc=='clear') { return 'Clair';    }
			if (translatedesc=='mostly clear') { return 'Tr&egrave;s clair';	}
			if (translatedesc=='partly cloudy') { return 'Partiellement nuageux';	 }
			if (translatedesc=='hazy') { return 'Brume';    }
			if (translatedesc=='partly cloudy with showers') { return 'Partiellement nuageux et averses';	}
			if (translatedesc=='mostly cloudy with showers') { return 'Tr&egrave;s nuageux et averses';	  }
			if (translatedesc=='party cloudy with thunder showers') { return 'Partiellement nuageux et fortes averses';	 }
			if (translatedesc=='foggy') { return 'Brouillard';    }
			if (translatedesc=='light snow') { return 'Flocons de neige'; }
			if (translatedesc=='light snow showers') { return 'L&eacute;g&egrave;res chutes de neige'; }		
			if (translatedesc=='rain shower') { return 'Averses';    }
			if (translatedesc=='light drizzle') { return 'L&eacute;g&egrave;re bruine';    }
			if (translatedesc=='mixed rain and sleet') { return 'Pluie et verglas';    }
			if (translatedesc=='mixed snow and sleet') { return 'Neige et verglas';    }
			if (translatedesc=='severe thunderstorms') { return 'Gros orages';    }
			if (translatedesc=='hurricane') { return 'Ouragan';    }
			if (translatedesc=='tropical storm') { return 'Orage tropical';    }
			if (translatedesc=='tornado') { return 'Tornade';    }
			if (translatedesc=='freezing drizzle') { return 'Bruine vergla&ccedil;ante';    }
			if (translatedesc=='blowing snow') { return 'Rafales de neige'; }
			if (translatedesc=='hail') { return 'Gr&ecirc;le'; }
			if (translatedesc=='dust') { return 'Poussi&eacute;reux';    }
			if (translatedesc=='smoky') { return 'Brumeux';    }
			if (translatedesc=='blustery') { return 'Temp&ecirc;te';    }
			if (translatedesc=='mixed rain and hail') { return 'Pluie et Gr&ecirc;le m&eacute;l&eacute;es';    }
			if (translatedesc=='isolated thunderstorms') { return 'Orages isol&eacute;s';    }
			if (translatedesc=='isolated thundershowers') { return 'Averses isol&eacute;s';    }
			if (translatedesc=='scattered thunderstorms') { return 'Orages &eacute;parses';    }
			if (translatedesc=='scattered showers') { return 'Averses &eacute;parses';    }
			if (translatedesc=='scattered snow showers') { return 'Chutes de neige &eacute;parses';    }
			if (translatedesc=='light rain with thunder') { return 'Pluie l&eacute;g&egrave;re et &eacute;clairs';    }
			if (translatedesc=='not available') { return 'Non disponible';    }
			if (translatedesc=='drifting snow/windy') { return 'Neige poudreuse et vent';    }
			if (translatedesc=='light rain shower') { return 'L&eacute;g&egrave;re averse'; }
			if (translatedesc=='thunder') { return 'Tonnerre'; }
			if (translatedesc=='mostly cloudy/windy') { return 'Tr&egrave;s nuageux et vent'; }
			if (translatedesc=='sandstorm') { return 'Temp&ecirc;te de sable'; }
			if (translatedesc=='squalls/windy') { return 'Rafales de vent'; }
			if (translatedesc=='sand') { return 'Sable'; }
			if (translatedesc=='sandstorm/windy') { return 'Temp&ecirc;te de sable et vent'; }
			if (translatedesc=='squalls') { return 'Rafales'; }
			if (translatedesc=='am clouds/pm sun') { return "Nuageux le matin/Ensoleill&eacute; l'apr&egrave;s midi"; }
			if (translatedesc=='am sun/pm clouds') { return "Ensoleill&eacute; le matin/Nuageux l'apr&egrave;s midi"; }
			if (translatedesc=='showers in the vicinity') { return "Averses &eacute;parses"; }
		break;
		case "ge":
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Sonnig'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Nieselregen'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Starker Schneefall'; }	
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Starker Regenschauer'; }	
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Regen und Schnee'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Regen und Schnee'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Heiter'; }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Meist Sonnig';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Teilweise Sonnig';	  }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Wechselnd Bew&ouml;lkt';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Dunstiger Sonnenschein;';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Dunstschleier'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Meist Bew&ouml;lkt'; }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Bew&ouml;lkt'; }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Sonnig mit Regenschauern';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Bew&ouml;lkt mit Gewitterschauern';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Wechselnd bew&ouml;lkt mit Gewitterschauer';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Leichter Regen'; }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Regen'; }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Windst%F6%DFe';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Bew&ouml;lkt mit Windst%F6%DFe';	  }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Teilweise Sonnig mit Windst%F6%DFe';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Schneegest&ouml;ber'; }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Scheeschauer'; }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Schnee'; }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Bew&ouml;lkt mit Schneeschauern';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Gl%E4tte';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Gefrierender Regen'; }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Schneeregen';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Heiss'; }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Kalt'; }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Windig'; }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Klar'; }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Meist Klar';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Nebelig';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt mit Regen';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Stark Bew&ouml;lkt mit Regen';	  }
			if (translatedesc=='partly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt mit Gewitter';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebelig'; }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Leichter Schneefall'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Regenschauer'; }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Leichter Nieselregen'; }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Graupelschauer'; }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Schwere Gewitter'; }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Wirbelsturm'; }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropischer Sturm'; }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado!'; }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Gefrierender Nieselregen'; }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Schneetreiben'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Hagel'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Staubig'; }
			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Dunstig'; }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='St&uuml;rmisch'; }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Regen und Hagel'; }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='&Ouml;rtliche Gewitter'; }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Vereinzelte Gewitter'; }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Vereinzelte Schauer'; }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Vereinzelte Schneeschauer'; }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Vereinzelte Regenschauer mit Gewitter';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='nicht verfuegbar'; }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Heftiges Schneegest%F6ber';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Leichte Regenschauer'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Donner'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Stark Bew&ouml;lkt und Windig'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Sandsturm'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='St&uuml;rmisch'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Staubig'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Sandsturm'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Sturmb%F6en'; }
			if (translatedesc=='light snow grains') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='thundershowers') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Ouml;rtliche Gewitterschauer'; }
			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Teilweise Sonnig'; }
			if (translatedesc=='ground fog') { document.getElementById("desc").innerHTML='Bodennebel'; }
			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='severe thunderstorm/windy') { document.getElementById("desc").innerHTML='Schwere Gewitter/Windig'; }
			return desc;
		break;
		case "sp":
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleado'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Llovizna'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Nieve fuerte'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Luvia fuerte'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Lluvia y nieve'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Despejado';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Mayormente soleado';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parcialmente soleado';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Intermitente nublado';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sol brumoso';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Bruma'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Mayormente nublado';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nublado';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Niebla';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Chubascos';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con chubascos';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tormenta electrica';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Mayormente nublado con tormentas de chubascos';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con tormentas de chubascos';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Lluvia ligera';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Lluvia';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Rafagas';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Mayormente nublado con rafagas';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parcialmente soleado con rafagas';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Rafagas de nieve';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Nieve';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Mayormente nublado con nieve';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Hielo';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Aguanieve';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Lluvia bajo cero';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caluroso';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Frio';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vientoso';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Despejado';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Mayormente despejado';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parcialmente despejado';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Bruma';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con chubascos';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Mayormente nublado con chubascos';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con tormentas de chubascos';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Neblina';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Nieve ligera'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Ligeras precipitaciones de nieve'; }       
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia';    }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruma';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Mezcla de lluvia y aguanieve';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Mezcla de nieve y aguanieve';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas severas';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Huracan';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tormenta tropical';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Llovizna helada';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Viento y nieve'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Granizo'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvareda';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempestuoso';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Mezcla de lluvia y granizo';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas aisladas';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Tormentas aisladas';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas dispersas';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Chubascos dispersos';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve dispersas';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='LLuvia y tormenta ligera';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Acumulacion de nieve y viento';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia ligera';	  }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Truenos'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Mayormente nublado y ventoso'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormentas de arena'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Chubascos y viento'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormentas de arena y ventoso'; }
			return desc;
		break;
		default: 
			return desc;
		break;
	}
}

function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
    case "Today": { return "Today"; }
    case "Tonight": { return "Tonight"; }
	}
}
