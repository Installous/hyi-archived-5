var forecastdisplay = false;

var updateFileTimer = "";

var obj = new Array;

var where = "";

var whereOld = "";

var filename = "";

var meteorTimer;

var time_to_change_wall;

var dayhour;

var nighthour;

var iPhoneType = "iPh5"; // Leave this alone. It's an iWidget it doesn't matter 



if (ChangeClick == false) { var touchmode = "touchstart"; } else { var touchmode = "click"; }

// Set a time out for all ajax requests, desactivate the cache.

$.ajaxSetup({timeout: 8000, cache: false}); 





// WEATHER CONDITIONS

var Conditions = [

	"thunderstorm",

	"thunderstorm",

	"showers_cloud",

	"thunderstorm",

	"thunderstorm",

	"sleet",

	"sleet",

	"sleet",

	"sleet",

	"showers_cloud",

	"sleet",

	"rain",

	"showers_cloud",

	"snow",

	"snow",

	"snow",

	"snow",

	"hail",

	"sleet",

	"fog",

	"fog",

	"haze",

	"fog",

	"wind",

	"wind",

	"frost",

	"cloud",

	"mostlycloudy",

	"mostlycloudy",

	"partlycloudy",

	"partlycloudy",

	"clear",

	"clear",

	"fair",

	"fair",

	"sleet",

	"clear",

	"thunderstorm",

	"thunderstorm",

	"thunderstorm",

	"showers_cloud",

	"snow",

	"snow",

	"snow",

	"partlycloudy",

	"thunderstorm",

	"snow",

	"thunderstorm",

	"blank"];



function init() {

updateClock();

StartTouch();

setInterval(updateClock, 1000);

if (DemoMode == false) { updateWeather(); } else { Demo(); }



if (WeatherWalls == false) {

	document.getElementById("weatherWall").style.display = "none";

	} else {

	document.getElementById("Layer").style.display = "none";

}	



if (ShowClockDate == false) {			    document.getElementById("DigitalClock").style.display = "none";

document.getElementById("date").style.display = "none"; }



if (ShowWiper == false) { document.getElementById("wiperContainer").style.display = "none"; }

}



function Demo() {

	document.getElementById("city").innerHTML = "City";

	document.getElementById("desc").innerHTML = WeatherTest;

	document.getElementById("temp").innerHTML="12" + "&#176;";

	

	where = WhereTest;

	loadjscssfile ("Weather/"+iPhoneType, WeatherTest, "css");

	loadjscssfile ("Weather/"+iPhoneType, WeatherTest, "js");



document.getElementById("weatherWall").src="Images/WeatherWalls/" + where + "_" + WeatherTest +".jpg";

}



function StartTouch() {

el = document.getElementById("TouchLayer");

el.addEventListener(touchmode, touchEnd, false);	

}



function touchEnd(event) {

	event.preventDefault();

	if (forecastdisplay == false) {

	document.getElementById('forecast').className = "forecastMoveUp";

	forecastdisplay = true;

	} else {

	document.getElementById('forecast').className = "forecastMoveDown";

	forecastdisplay = false;

	}

}



function updateClock() {

	var currentTime = new Date();

	var currentHours = currentTime.getHours();

	var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();

	var currentDate = currentTime.getDate() < 10 ? '' + currentTime.getDate() : currentTime.getDate();

	time_to_change_wall = currentHours + currentMinutes/60;

	timeOfDay = ( currentHours < 12 ) ? "am" : "pm";



	if (ampm == false) {

		timeOfDay = "";

		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;

		currentTimeString = currentHours + ":" + currentMinutes;

	} else {

		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

	//	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;

		currentHours = ( currentHours == 0 ) ? 12 : currentHours;

		currentTimeString = currentHours + ":" + currentMinutes;

	}

		

	document.getElementById("clock").innerHTML = currentTimeString;

	document.getElementById("ampm").innerHTML = timeOfDay;

	document.getElementById("date").innerHTML = days[currentTime.getDay()] + ", " + months[currentTime.getMonth()] + " " + currentDate;



		

	// DAY OR NIGHT CHANGE

	if (dayhour != null) {

		if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { var whereTmp = "night";	} else { var whereTmp = "day"; }

		if (whereTmp != where) { dealWithWeather(obj); } // Refresh the weather for day/night condition.

	}

}



function dealWithWeather(obj) {

// TIME INFO...

document.getElementById("lastupdate").innerHTML = lastupdatetext + currentTimeString + timeOfDay;

document.getElementById("xmlupdate").innerHTML = "📡 " + obj.updatetimestring;



// MAIN INFORMATION

var sunriseh = parseInt(obj.sunrise.split(':')[0]) + GMT;

var sunrisem = obj.sunrise.split(':')[1];

var sunseth = parseInt(obj.sunset.split(':')[0]) + GMT;

var sunsetm = obj.sunset.split(':')[1];

dayhour = sunriseh + parseInt(sunrisem)/60;

nighthour = sunseth + parseInt(sunsetm)/60;

DurationOfDay = nighthour - dayhour;

DurationOfNight = 24 - DurationOfDay;

		

if (ampm == false) {

	var sunriseh = ( sunriseh < 10 ? "0" : "" ) + sunriseh;

	var sunseth = ( sunseth < 10 ? "0" : "" ) + sunseth;

	var sunrise = sunriseh + ":" + sunrisem;		

	var sunset = sunseth + ":" + sunsetm;

	} else {

	var timeOfSunset = ( sunseth < 12 ) ? "am" : "pm";

	var timeOfSunrise = ( sunriseh < 12 ) ? "am" : "pm";

	sunriseh = ( sunriseh > 12 ) ? sunriseh - 12 : sunriseh;

	sunriseh = ( sunriseh == 0 ) ? 12 : sunriseh;

	sunseth = ( sunseth > 12 ) ? sunseth - 12 : sunseth;

	sunseth = ( sunseth == 0 ) ? 12 : sunseth;

	var sunrise = sunriseh + ":" + sunrisem + " " + timeOfSunrise;	

	var sunset = sunseth + ":" + sunsetm + " " + timeOfSunset;

}



// CHANGE THE BACKGROUND FOR DAY OR NIGHT CONDITION

if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { where = "night"; } else { where = "day"; }

document.getElementById("Layer").src = "Images/Layer/Layer_" + where +".png";



document.getElementById("moon").style.backgroundImage = "url(Images/Weather/moon/" + obj.moonphase + ".png)";

document.getElementById("city").innerHTML = obj.city;

document.getElementById("temp").innerHTML = obj.temp + "&#176;";

document.getElementById("highlowtemp").innerHTML = "H: " + obj.high[0] + "\&#176" + " / " + "L: " + obj.low[0]	+ "\&#176";

document.getElementById("desc").innerHTML = WeatherDesc[obj.icon];

document.getElementById("sunrise").innerHTML = sunrisetext + " - " + sunrise;

document.getElementById("sunset").innerHTML = sunsettext + " - " + sunset;



document.getElementById("Day1").innerHTML = days[obj.dayofweek[1]-1].substring(0, 3);

document.getElementById("Day2").innerHTML = days[obj.dayofweek[2]-1].substring(0, 3);

document.getElementById("Day3").innerHTML = days[obj.dayofweek[3]-1].substring(0, 3);

document.getElementById("Day4").innerHTML = days[obj.dayofweek[4]-1].substring(0, 3);

document.getElementById("Day1Icon").src = "Images/Icon Sets/" + iconSet + "/" + obj.code[1] + ".png";

document.getElementById("Day1HiLo").innerHTML = obj.low[1] + "&#176;/ " + obj.high[1] + "&#176;";

document.getElementById("Day2Icon").src = "Images/Icon Sets/" + iconSet + "/" + obj.code[2] + ".png";

document.getElementById("Day2HiLo").innerHTML = obj.low[2] + "&#176;/ " + obj.high[2] + "&#176;";

document.getElementById("Day3Icon").src = "Images/Icon Sets/" + iconSet + "/" + obj.code[3] + ".png";

document.getElementById("Day3HiLo").innerHTML = obj.low[3] + "&#176;/ " + obj.high[3] + "&#176;";

document.getElementById("Day4Icon").src = "Images/Icon Sets/" + iconSet + "/" + obj.code[4] + ".png";

document.getElementById("Day4HiLo").innerHTML = obj.low[4] + "&#176;/ " + obj.high[4] + "&#176;";



if ( AnimatedWeather == true ) { LaunchAnimations(); } else {

document.getElementById("StaticWeather").src = "Images/Static/"+AdjustIcon(obj.icon, where)+".png"; }



document.getElementById("weatherWall").src="Images/WeatherWalls/" + where + "_" + Conditions[obj.icon] +".jpg";

		

}



function updateWeather() {

jQuery.get('file:///private/var/mobile/Documents/widgetweather.xml', function(data) {

// jQuery.get('widgetweather.xml',function(data) {



obj.updatetimestring = $(data).find('updatetimestring').text();



if (updateFileTimer != obj.updatetimestring) {

	obj.high = new Array;

	obj.low  = new Array;

	obj.code = new Array;

	obj.daynumber = new Array;

	obj.dayofweek = new Array;

	obj.time24hour = new Array;

	obj.htemp = new Array;

	obj.hcode = new Array;

	obj.hpop = new Array;

	obj.hwhere = new Array;



	$(data).find('currentcondition').each( function() {

		obj.city =$(this).find('name').text();	  

		obj.temp = $(this).find('temp').text(); 

		obj.icon = $(this).find('code').text();

		obj.observationtime = $(this).find('observationtime').text();

		obj.sunset = $(this).find('sunsettime').text();

		obj.sunrise = $(this).find('sunrisetime').text();

		obj.tempUnit = $(this).find('celsius').text();

		obj.moonphase = $(this).find('moonphase').text()*1;

	});



		var i=0;

		$(data).find('day').each( function() {

			obj.high[i] =$(this).find('high').text();

			obj.low[i] = $(this).find('low').text();

			obj.code[i] = $(this).find('code').text();	

			obj.daynumber[i] = $(this).find('daynumber').text();	

			obj.dayofweek[i] = $(this).find('dayofweek').text();

			i++;

		});



	updateFileTimer = obj.updatetimestring;

	dealWithWeather(obj);

}

}).fail(function() {

	document.getElementById("xmlupdate").innerHTML = "No XML file !";

});



refreshTimer = setTimeout(updateWeather, 20*1000);

}



// WORKAROUND FOR CORRECT ICONS IN ALL SITUATIONS AND TWELVE HOUR FORMAT*



function AdjustIcon(icon, whereTmp) {

	switch(whereTmp) {

		case "day":

			if (icon == 27) { icon = 28; }

			if (icon == 29) { icon = 30; }	

			if (icon == 31) { icon = 32; }	

			if (icon == 33) { icon = 34; }

		break;

		case "night":

			if (icon == 28) { icon = 27; }

			if (icon == 30) { icon = 29; }	

			if (icon == 32) { icon = 31; }	

			if (icon == 34) { icon = 33; }

		break;

	}

	return icon;

}



function TwelveHourForecast(hour) {

	if (ampm == true) { 

		hour = parseInt(hour.split(':')[0]);

		var timeOfhour = ( hour < 12 ) ? "AM" : "PM";

		hour = ( hour > 12 ) ? hour - 12 : hour;

		hour = ( hour == 0 ) ? 12 : hour;

		hour = hour + " " + timeOfhour;

	}

	return hour;

}



function LaunchAnimations() {

	// POSITION OF SUN/MOON

	if (where == "night") {

		if (time_to_change_wall < dayhour) { time_to_change_wall = time_to_change_wall +24 };

		pTranslate = parseInt(((time_to_change_wall - nighthour)/ DurationOfNight)*320);

		document.getElementById("moon").style.webkitTransform = "translateX("+pTranslate+"px)";

		document.getElementById("moonray").style.webkitTransform = "translateX("+pTranslate+"px)";					

	} else {

		pTranslate = parseInt(((time_to_change_wall - dayhour)/ DurationOfDay)*320);

		document.getElementById("sun").style.webkitTransform = "translateX("+pTranslate+"px)";

		document.getElementById("sunray").style.left = pTranslate - 160 + "px"; 				

	}

	

	if (filename == "") {

		filename = Conditions[obj.icon];

		whereOld = where;

		loadjscssfile ("Weather/"+iPhoneType, filename, "css");

		loadjscssfile ("Weather/"+iPhoneType, filename, "js");

	} else {

		if ((Conditions[obj.icon] != filename ) || (where != whereOld)) {

			whereOld = where;

			clearInterval(meteorTimer);

			delelement("starContainer");

			delelement("meteorContainer");

			delelement("wiperContainer");

			delelement("windContainer");

			delelement("frameContainer");

			delelement("cloudContainer");

			delelement("dropContainer");

			delelement("circleContainer");

			replacejscssfile("Weather/"+iPhoneType, filename, Conditions[obj.icon], "css");

			replacejscssfile("Weather/"+iPhoneType, filename, Conditions[obj.icon], "js");

			filename = Conditions[obj.icon];	

		}

	} 

}



function delelement(elem) {

var element = document.getElementById(elem);

while (element.firstChild) { element.removeChild(element.firstChild); }

}



function loadjscssfile(url, filename, filetype){

if (filetype=="js") {

	var fileref = document.createElement("script");

	fileref.type = "text/javascript";

	fileref.charset = "utf-8";

	fileref.src = "JavaScript/" + url + "/" + filename + ".js";

 }

if (filetype=="css") {

	var fileref = document.createElement("link");

	fileref.rel = "stylesheet";

	fileref.href = "Css/" + url + "/" + filename + ".css";

	fileref.type = "text/css";

	fileref.media = "screen";

 }

document.getElementsByTagName("head")[0].appendChild(fileref);

}



function createjscssfile(url, filename, filetype){

if (filetype=="js") {

	var fileref = document.createElement("script");

	fileref.type = "text/javascript";

	fileref.charset = "utf-8";

	fileref.src = "JavaScript/" + url + "/" + filename + ".js";

 }

if (filetype=="css") {

	var fileref = document.createElement("link");

	fileref.rel = "stylesheet";

	fileref.href = "Css/" + url + "/" + filename + ".css";

	fileref.type = "text/css";

	fileref.media = "screen";

 }

return fileref;

}



function replacejscssfile(url, oldfilename, newfilename, filetype){

var targetelement = (filetype=="js")? "script" : (filetype=="css")? "link" : "none";

var targetattr = (filetype=="js")? "src" : (filetype=="css")? "href" : "none";

var allsuspects = document.getElementsByTagName(targetelement);

for (var i = allsuspects.length; i>=0; i--) { 

		if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(oldfilename)!=-1) {

			var newelement = createjscssfile(url, newfilename, filetype);

			allsuspects[i].parentNode.replaceChild(newelement, allsuspects[i]);

			}

	}

}



