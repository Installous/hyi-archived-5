// WIDGET WEATHER iOS7 styled //

// includes work by Dacal primarily, Marty McFly and Durben //



var WeatherWalls = true;

var iconSet = "spils";							

var ChangeClick = true; 				     

var GMT = 0;					// Adjust sunset/sunrise time if necessary (for me, in Tunisia, Yahoo don't report it correctly ;).



/*

FOR TESTING PURPOSE ONLY - Don't touch for normal use.

*/

var DemoMode = false;

var WeatherTest = "showers_cloud";

var WhereTest = "day";





