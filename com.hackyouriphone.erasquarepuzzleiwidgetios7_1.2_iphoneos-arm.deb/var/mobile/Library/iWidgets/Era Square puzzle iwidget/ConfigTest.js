// WIDGET WEATHER iOS7 styled //

// includes work by Dacal primarily, Marty McFly and Durben mod by cocco26//



var lang = "en";



/*  LANGUAGES:

(it) for Italian

(fi) for Finland

(nl) for Dutch

(fr) for french

(ge) for german

(sp) for spanish

(cn) for Chinese

(ru) for Russian

(en) or for english

*/

						       

var ChangeClick = true; 				      

var updateInterval = 10; // in minutes.



var ampm = true; // true for 12h format.

var iconSet = "spils";

var ShowClockDate = true;// true to display time and date



var GMT = 0; // Adjust sunset/sunrise time if necessary (for me, in Tunisia, Yahoo don't report it correctly ;).



var AnimatedWeather = true; // True for animated weather.



var WeatherWalls = true; // True for weather walls, false for a day or night picture with static iOS 7 realistic weather icons over top



var DropRain = true; // True for classic rain drop



var ShowWiper = true;  // show or hide wiper during rain condition



/*

FOR TESTING PURPOSE ONLY - Don't touch for normal use.

*/

var DemoMode = false;

var WeatherTest = "thunderstorm";

var WhereTest = "night";

