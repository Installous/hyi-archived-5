Thank you for purchasing SmartHD!

With this PSD file you can create your own SmartHD icons!
Why? AppIconMasks doesn't apply to Cydia-App icons. Thats why you need to create them on your own.
Just open the PSD file, place your icon under the border, cut off the edges 
and save it inside of the "Bundles" folder with the right Bundle ID. 

If you need help, contact me via Twitter: http://twitter.com/CallMeFisk
