/*

Configuration here !

Done by Dacal - Modded by ChrisGraphiX

For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)

*/





var Clock = "24h";		  // choose between "12h" or "24h"

var lang = "fr";	       // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) for english





var gps = false;		// Requires MyLocation app

var locale = 603733;	      // Yahoo Weather (used if gps set to false or myLocation.txt file not found)

var tempUnit = "c";	       // f for fahrenheit

var IconSet = "gears";	    // add your own set

var updateInterval = 15;       // in minutes