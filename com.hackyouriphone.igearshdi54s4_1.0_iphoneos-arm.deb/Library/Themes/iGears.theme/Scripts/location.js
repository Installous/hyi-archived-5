var prevlatitude = "";
var prevlongitude = "";
var zipCode="";
var woeid;
var textLat;
var textLong;
var refreshWeatherTimer;

function UpdateLocation() {
refrechLocationTimer = setTimeout("UpdateLocation()", 20*1000);
jQuery.get('file:///private/var/mobile/Documents/myLocation.txt', function(appdata) {
//jQuery.get('myLocation.txt', function(appdata) {
var myvar = appdata;
var substr = appdata.split('\n');
var templatitude=(substr[0]).split('=');
var templongitude=(substr[1]).split('=');
var latitude = $.trim(templatitude[1]);
var longitude = $.trim(templongitude[1]);

if (prevlatitude != latitude || prevlongitude != longitude) {
	clearTimeout(refreshWeatherTimer);
	clearTimeout(refreshWeatherTimerNormal);
	if (latitude < 0) { textLat = Math.round(latitude*100)/100 + "\u00B0" + "S"; }
	else if (latitude > 0){ textLat = Math.round(latitude*100)/100 + "\u00B0" + "N"; }
	else { textLat = Math.round(latitude*100)/100 + "\u00B0"; }
	if (longitude < 0) { textLong = Math.round(longitude*100)/100 + "\u00B0" + "W"; }
	else if (longitude > 0) { textLong = Math.round(longitude*100)/100 + "\u00B0" + "E"; }
	else { textLong = Math.round(longitude*100)/100 + "\u00B0"; }
	prevlatitude = latitude;
	prevlongitude = longitude;

	// GET WOEID FOR THE NEW LOCATION
	var url = "http://where.yahooapis.com/geocode?location=" + latitude + "+" + longitude + "&gflags=R&flags=J";
	$.getJSON(url, function(data) {
	found = data.ResultSet.Found; // Check if coordinates return a valid localization.

	if ( found == 1) {
		woeid = data.ResultSet.Results[0].woeid;
		city = data.ResultSet.Results[0].city;

		// GET OLD LOCALE FROM WOEID
		var url = "http://weather.yahooapis.com/forecastrss?w="+woeid+"&u=f";
		$.get(url, function(data) {
		title = $(data).find('title').text(); // Check if a city is found.
		
		if (title != "Yahoo! Weather - ErrorCity not found") {
			zipCode = $(data).find('guid').text().split('_')[0];
			city = $(data).find('location').attr('city');
			document.getElementById("cityname0").innerHTML = city;
			document.getElementById("cityname").style.display='none';
			gps = true;
			fetchWeatherData(dealWithWeather, zipCode);
			var refreshWeatherTimer = setInterval('fetchWeatherData(dealWithWeather, zipCode)', updateWeatherEvery); // Refresh weather as specified in Config.js.
		} else {
			if ( xmldata == false ) {  // Back to locale, but keep the 20s refresh for GPS localization.
			gps = false;
			validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
			} else {
			document.getElementById("cityname0").innerHTML = city; // Refresh the city name and keep the last weather info.
			document.getElementById("coordinates").style.color="#DCDCDC";
			document.getElementById("coordinates").innerHTML = " [" + textLat + " " + textLong + "]";
			}
		}
		}).error(function() {
		if (xmldata == false) {
		dealWithWeather ({error:true});
		}
		else {
		document.getElementById("coordinates").style.color = "red"; 
		document.getElementById("coordinates").innerHTML = "[Offline]";
		}
		});
	} else {
		if ( xmldata == false) { // No data. Keep weather or back to locale, maintain the 20s refresh for GPS localization.
		gps = false;
		validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
		} else {
		document.getElementById("coordinates").style.color = "red"; 
		document.getElementById("coordinates").innerHTML = "[Offline]";
		}
	}
	}).error(function() {
		if (xmldata == false) {
		dealWithWeather ({error:true});
		}
		else {
		document.getElementById("coordinates").style.color = "red"; 
		document.getElementById("coordinates").innerHTML = "[Offline]";
		}
	}); 
}
}).error(function() {
clearTimeout(refrechLocationTimer); // No myLocation.txt file. Completly stop GPS mode.
gps = false;
validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
}); 

}
