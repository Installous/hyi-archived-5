/*
	Image Cross Fade Redux
	Version 1.0
	Last revision: 02.15.2006
	steve@slayeroffice.com

	Rewrite of old code found here: http://slayeroffice.com/code/imageCrossFade/index.html
*/

window.addEventListener?window.addEventListener('load',so_init,false):window.attachEvent('onload',so_init);

var d=document, imgs = new Array(), zInterval = null, current=0, pause=false;

function so_init()
{
	if(!d.getElementById || !d.createElement)return;

	css = d.createElement('link');
	css.setAttribute('href','slideshow2.css');
	css.setAttribute('rel','stylesheet');
	css.setAttribute('type','text/css');
	d.getElementsByTagName('head')[0].appendChild(css);

	imgs = d.getElementById('rotator').getElementsByTagName('img');
	for(i=1;i<imgs.length;i++) imgs[i].xOpacity = 0;
	imgs[0].style.display = 'block';
	imgs[0].xOpacity = .99;

	setTimeout(so_xfade,3000);
}

function so_xfade()
{
	cOpacity = imgs[current].xOpacity;
	nIndex = imgs[current+1]?current+1:0;
	nOpacity = imgs[nIndex].xOpacity;

	cOpacity-=.05;
	nOpacity+=.05;

	imgs[nIndex].style.display = 'block';
	imgs[current].xOpacity = cOpacity;
	imgs[nIndex].xOpacity = nOpacity;

	setOpacity(imgs[current]);
	setOpacity(imgs[nIndex]);

	if(cOpacity<=0)
	{
		imgs[current].style.display = 'none';
		current = nIndex;
		setTimeout(so_xfade,3000);
	}
	else
	{
		setTimeout(so_xfade,50);
	}

	function setOpacity(obj)
	{
		if(obj.xOpacity>.99)
		{
			obj.xOpacity = .99;
			return;
		}

		obj.style.opacity = obj.xOpacity;
		obj.style.MozOpacity = obj.xOpacity;
		obj.style.filter = 'alpha(opacity=' + (obj.xOpacity*100) + ')';
	}
}

function fnc() {
	var reloj=new Date();
	var str="";
	//para 12 horas 
	tipo="AM";
	doce=reloj.getHours();
	if(doce>12) {
		if(doce==13)doce=1; else if(doce==14)doce=2; else if(doce==15)doce=3; else if(doce==16)doce=4; else if(doce==17)doce=5; else if(doce==18)doce=6; else if(doce==19)doce=7; else if(doce==20)doce=8; else if(doce==21)doce=9; else if(doce==22)doce=10; else if(doce==23)doce=11;
		tipo="PM";
	} else if(doce==0)doce=12; else if(doce==12)tipo="PM";
	mins=reloj.getMinutes();
	if(mins<10)mins="0"+mins;
	secs=reloj.getSeconds();
	if(secs<10)secs="0"+secs;
	str=doce+":567657"+mins+":"+secs+" "+tipo;
	document.getElementById("reloj").innerHTML=str;
	window.setTimeout("fnc()",1000);
}

var this_date_timestamp = new Date()	



var this_weekday = this_date_timestamp.getDay()    

var this_date = this_date_timestamp.getDate()	 

var this_month = this_date_timestamp.getMonth()    

var this_year = this_date_timestamp.getYear()	 



// -->

function init ( )

{

  timeDisplay = document.createTextNode ( "" );

  document.getElementById("clock").appendChild ( timeDisplay );

}



function updateClock ( )

{

  var currentTime = new Date ( );



  var currentHours = currentTime.getHours ( );

  var currentMinutes = currentTime.getMinutes ( );
  

  // Convert the hours component to 12-hour format if needed

  // currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;



  // Convert an hours component of "0" to "12"

  currentHours = ( currentHours == 0 ) ? 12 : currentHours;



  // Pad the minutes and hourss with leading zeros, if required

  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;

  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;



  // Compose the string for display

  var currentTimeString = currentHours;

  var currentTimeString2 = currentMinutes;



  // Update the time display

  document.getElementById("clock").firstChild.nodeValue = currentTimeString;

  document.getElementById("clock2").firstChild.nodeValue = currentTimeString2;

}



function calendarDate ( )

{

var this_date_name_array = new Array ("0", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27" ,"28", "29" ,"30", "31")

var this_weekday_name_array = new Array("Sun","Mon","Tue","Wed","Thu","Fri","Sat")

var this_month_name_array = new Array("January","February","March","April","May","June","July","August","September","October","November","December") //predefine month names

var this_date_timestamp = new Date()	  
var this_weekday = this_date_timestamp.getDay()    
var this_date = this_date_timestamp.getDate()	 
var this_month = this_date_timestamp.getMonth()

var month = this_date_timestamp.getMonth();

document.getElementById("date").firstChild.nodeValue = this_date_name_array[this_date]//concat long date string

document.getElementById("weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday]//concat long date string

document.getElementById("month").firstChild.nodeValue = this_month_name_array[this_month]//concat long date string

}



/*****************************************************************************
Presentaci�n de Im�genes (SlideShow) por Tunait!
Actualizado el 28/12/2003 - 10/2011
Si quieres usar este script en tu sitio eres libre de hacerlo con la condici�n de que permanezcan intactas estas l�neas, osea, los cr�ditos.

http://javascript.tunait.com
tunait@yahoo.com 
******************************************************************************/
var segundos = 4 //cada cuantos segundos cambia la imagen
var dire = "fotos" //directorio o ruta donde est�n las im�genes

var imagenes=new Array()
imagenes[0]="foto1.jpg"
imagenes[1]="foto2.jpg"
imagenes[2]="foto3.jpg"
imagenes[3]="foto4.jpg"
imagenes[4]="foto5.jpg"

if(dire != "" && dire.charAt(dire.length-1) != "/")
{dire = dire + "/"}

var preImagenes = new Array()
	for (pre = 0; pre < imagenes.length; pre++){
		preImagenes[pre] = new Image()
		preImagenes[pre].src = dire + imagenes[pre]
	}
cont=0
function presImagen(){
	document.foto.src= dire + imagenes[cont]
	subeOpacidad()
	if (cont < imagenes.length-1)
		{cont ++}
	else
		{cont=0}
	tiempo=window.setTimeout('bajaOpacidad()',segundos*1000)
}
var iex = navigator.appName=="Microsoft Internet Explorer" ? true : false;
var fi = iex?'filters.alpha.opacity':'style.opacity'
var opa = iex ? 100 : 1;
function bajaOpacidad(){
	eval(opa)
	if(opa >= 0){
		cambia()
		opa -= iex?10:0.1;
		setTimeout('bajaOpacidad()',50)
	}
	else{presImagen()}
}

function subeOpacidad(){
	opaci = iex?100:1;
	if(opa <= opaci){
		cambia()
		opa += iex?10: 0.1;
		setTimeout('subeOpacidad()',10)
	}
}
function cambia(){
	eval('document.foto.' + fi + ' = opa')
}
var tiempo
function inicio(){
	clearTimeout(tiempo)
	bajaOpacidad()
}


