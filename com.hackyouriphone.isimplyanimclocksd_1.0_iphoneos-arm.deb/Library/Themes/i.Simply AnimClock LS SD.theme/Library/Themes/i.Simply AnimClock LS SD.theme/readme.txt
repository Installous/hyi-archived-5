----------------------------------------------------------------------------
i.Simply AnimClock LS, a theme by Dark-Naruto - Credits to storyr
----------------------------------------------------------------------------

Installation

   1. Download, unzip.

   2. Copy i.Simply AnimClock LS.theme folder to this location on your device:

      -> /private/var/stash/Themes.xxxxxx/

   3. Activate the theme in Winterboard settings

      -> SummerBoard can be off, unless you intend to use the Icons folder

Settings

   1. Change weather location, units, clock format, etc.

      -> edit file: i.Simply AnimClock LS.theme/settings.xml
   2. Change the text on the bottom: 
      -> edit file: i.Simply AnimClock LS.theme/LockBackground.html. Search and replace "SLIDE TO ENTER" by your own text

Credits

   1. Widget by Storyr 
   2. "plain weather" icons by ~MerlinTheRed (http://merlinthered.deviantart.com)


----------------------------------------------------------------------------
License

   The i.Simply AnimClock LS is created on the Heavy Metal HD theme and themePump (both by storyr) are licensed 
   under the Creative Commons Attribution-NonCommercial-ShareAlike 
   3.0 Unported License. To view a copy of this license, visit 
   http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter 
   to:  Creative Commons
        171 Second Street, Suite 300
        San Francisco, CA, 94105, USA

   Permissions beyond the scope of this license may be available by 
   emailing storyr@venusware.net
----------------------------------------------------------------------------
