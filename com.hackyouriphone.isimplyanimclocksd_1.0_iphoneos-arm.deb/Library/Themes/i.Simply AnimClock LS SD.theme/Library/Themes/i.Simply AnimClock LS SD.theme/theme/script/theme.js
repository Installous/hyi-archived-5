//*********************************************************************
//
//   i.Simply AnimClock LS -  an original iPhone theme by Dark-Naruto - Credits to storyr
//
//*********************************************************************
//   License
//
//   The i.Simply AnimClock LS theme is created on theHeavy Metal HD theme and themePump (both by storyr) are licensed 
//   under the Creative Commons Attribution-NonCommercial-ShareAlike 
//   3.0 Unported License. To view a copy of this license, visit 
//   http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter 
//   to:  Creative Commons
//        171 Second Street, Suite 300
//        San Francisco, CA, 94105, USA
//
//   Permissions beyond the scope of this license may be available by 
//   emailing storyr@venusware.net
//*********************************************************************

// themePump time refresh
function onPumpTimeRefresh(data, settings) {
   if (data.second == "59") {
      cycle(".right");
      if (data.minute == "59") {
         cycle(".left");
      }
   }
}

// cycle the specified clock "arm"
function cycle(side) {
   $(".gear" + side).removeClass("cycle");
   $(".flash" + side).removeClass("burn");
   setTimeout(function () {
      $(".gear" + side).addClass("cycle");
      $(".flash" + side).addClass("burn");
   }, 0);
}

// themePump refresh starting
function onPumpRefreshStart() {
   // show the update indicator
   $(".updateInd").removeClass("off");
}

// themePump refresh finished
function onPumpRefreshEnd() {
   // hide the update indicator
   setTimeout(function () { $(".updateInd").addClass("off"); }, 500);
   // for the bottom panel, fit the contents
   $(".panelbottom").contents().stretch({ max: 14 } );
}
