confirm("FujiForever", "Are you sure you want to respring?", c => {
	if(c) device.respring();
});