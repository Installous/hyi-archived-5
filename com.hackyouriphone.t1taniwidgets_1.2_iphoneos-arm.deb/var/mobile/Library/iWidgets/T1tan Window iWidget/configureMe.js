  /* Done by Dacal mod by DemoneLatino */ 
       /** TWITTER @DemoneLatino **/


//you not have (GPS) "myLocation" download from cydia "GPS Weather Lockscreen" by crazyvivek(iOS 4.x - 7.x)contact me via cydia for more support or talk with me on TWITTER @DemoneLatino

var updateInterval = 5;  // refresh weather in minutes.

var iconSet = "DemoneWeather"  // add your own set

var iconExt = ".jpg"  // icons extension

var useRealFeel = false; // true or false

var source = 'yahooWeather' // Don't touch here!