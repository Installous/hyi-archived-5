var updateFileTimer = "";
var obj = new Array;
var where = "";
var time_to_change_wall;
var dayhour;
var nighthour;

// Set a time out for all ajax requests, desactivate the cache.
$.ajaxSetup({timeout: 8000, cache: false}); 


function init() {
updateClock();
setInterval(updateClock, 1000);
updateWeather();
}


function dealWithWeather(obj) {
// TIME INFO...

// lastupdate is set as display none in the css. It shows the time the widget last checked the xml file for an update
document.getElementById("lastupdate").innerHTML = currentTimeString + timeOfDay;

// xmlupdate is the time that the xml updated with new information for location and weather
document.getElementById("xmlupdate").innerHTML = lastupdatetext + obj.updatetimestring.slice(11);


// SUNSET SUNRISE INFORMATION
var sunriseh = parseInt(obj.sunrise.split(':')[0]) + GMT;
var sunrisem = obj.sunrise.split(':')[1];
var sunseth = parseInt(obj.sunset.split(':')[0]) + GMT;
var sunsetm = obj.sunset.split(':')[1];
dayhour = sunriseh + parseInt(sunrisem)/60;
nighthour = sunseth + parseInt(sunsetm)/60;
		
if (ampm == false) {
	var sunriseh = ( sunriseh < 10 ? "0" : "" ) + sunriseh;
	var sunseth = ( sunseth < 10 ? "0" : "" ) + sunseth;
	var sunrise = sunriseh + ":" + sunrisem;		
	var sunset = sunseth + ":" + sunsetm;
	} else {
	var timeOfSunset = ( sunseth < 12 ) ? "am" : "pm";
	var timeOfSunrise = ( sunriseh < 12 ) ? "am" : "pm";
	sunriseh = ( sunriseh > 12 ) ? sunriseh - 12 : sunriseh;
	sunriseh = ( sunriseh == 0 ) ? 12 : sunriseh;
	sunseth = ( sunseth > 12 ) ? sunseth - 12 : sunseth;
	sunseth = ( sunseth == 0 ) ? 12 : sunseth;
	var sunrise = sunriseh + ":" + sunrisem + " " + timeOfSunrise;	
	var sunset = sunseth + ":" + sunsetm + " " + timeOfSunset;
}

// CHANGE THE BACKGROUND FOR DAY OR NIGHT CONDITION
if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { where = "night"; } else { where = "day"; }

// ADJUST THE HOURLY FORECAST FOR THE RIGHT SUNSET/SUNRISE TIME
for (i=0; i < 12; i++) {
	if ((parseInt(obj.time24hour[i].split(':')[0]) < Math.round(dayhour)) || (parseInt(obj.time24hour[i].split(':')[0]) >= Math.round(nighthour))) {
		obj.hwhere[i] = "night";
		} else {
		obj.hwhere[i] = "day";
	}
}

// ATMOSPHERIC INFORMATION Needs to be toggled on in settings Widget Weather in order to use

if (Distance_In_Miles == true) {
	var convertD = 0.621371;
	var visibilityunit = "miles";
	var windspeedunit = "mph";
} else {
	var convertD = 1;
	var visibilityunit = "km";
	var windspeedunit = "km/h";
}

if (Inches_Of_Mercury == true) {
	var convertP = 33.8638864;
	var pressureunit = "Inches Hg";
} else {
	var convertP = 1;
	var pressureunit = "mb";
}

document.getElementById("visibility").innerHTML = visibilitytext + Math.round(obj.visibility*convertD) + " " + visibilityunit;
document.getElementById("pressure").innerHTML = pressuretext + Math.round(obj.pressure/convertP) + " " + pressureunit;
document.getElementById("humidity").innerHTML = humiditytext + obj.humidity + "%";
direction = parseFloat(obj.direction);

			if (direction <= 360) obj.direction = "N";

			if (direction < 348.75) obj.direction = "N-NW"; 	

			if (direction < 326.25) obj.direction = "NW";		

			if (direction < 303.75) obj.direction = "W-NW";

			if (direction < 281.25) obj.direction = "W";		

			if (direction < 258.75) obj.direction = "W-SW"; 	

			if (direction < 236.25) obj.direction = "SW";

			if (direction < 213.75) obj.direction = "S-SW"; 	

			if (direction < 191.25) obj.direction = "S";		

			if (direction < 168.75) obj.direction = "S-SE";

			if (direction < 146.25) obj.direction = "SE";		

			if (direction < 123.75) obj.direction = "E-SE"; 	

			if (direction < 101.25) obj.direction = "E";		

			if (direction < 78.75) obj.direction = "E-NE";		

			if (direction < 56.25) obj.direction = "NE";

			if (direction < 33.75) obj.direction = "N-NE";		

			if (direction < 11.25) obj.direction = "N";

			if (direction == 0) obj.direction = "No wind";



			if (direction == 0) {

							document.getElementById("wind").innerHTML = windtext + obj.direction;			  

								} else {

								document.getElementById("wind").innerHTML = windtext + Math.round(obj.windspeed*convertD) + " " + windspeedunit + "-" + obj.direction ; }	       

if (obj.rising == 0) document.getElementById('rising').innerHTML= "&larr;&rarr;";
if (obj.rising == 1) document.getElementById('rising').innerHTML= "&uarr;";
if (obj.rising == 2) document.getElementById('rising').innerHTML= "&darr;";
		
// END ATMOSPHERIC INFORMATION

// NEIGHBORHOOD LOCATION INFORMATION needs to be toggled on in settings Widget Weather to use Neighborhood, County, Country 
// State Code, Country Code and Zip or Postal Code are also available but need to be written in the html and css and remove the double slash from in front below. Use the Id to call the elements

document.getElementById("neighborhood").innerHTML = obj.neighborhood;
document.getElementById("county").innerHTML = obj.county;
document.getElementById("country").innerHTML = obj.country;
//document.getElementById("countrycode").innerHTML = obj.countrycode;
//document.getElementById("statecode").innerHTML = obj.statecode;
//document.getElementById("postalcode").innerHTML = obj.postalcode;

// END NEIGHBORHOOD LOCATION

// MAIN WEATHER INFORMATION 

document.getElementById("city").innerHTML = obj.city;
document.getElementById("state").innerHTML = obj.state;
document.getElementById("temp").innerHTML = obj.temp + "&#176;";
document.getElementById("RealFeel").innerHTML = feelsliketext + obj.RealFeel + "&#176;";
document.getElementById("highlowtemp").innerHTML = hightext + obj.high[0] + "\&#176" + " / " + lowtext + obj.low[0]  + "\&#176";
document.getElementById("Day0Icon").src = "Icon Sets/"+iconSet+"/"+AdjustIcon(obj.icon, where)+".png";
document.getElementById("desc").innerHTML = WeatherDesc[obj.icon];
document.getElementById("sunrise").innerHTML = sunrisetext + " - " + sunrise;
document.getElementById("sunset").innerHTML = sunsettext + " - " + sunset;
document.getElementById("woeid").innerHTML = "Woeid : " + obj.woeid;
document.getElementById("zip").innerHTML = "Zip : " + obj.locationid;
document.getElementById("MoonIcon").src = "Icon Sets/Moon/"+obj.moonphase+".png";
document.getElementById("moonphase").innerHTML = MoonDesc[obj.moonphase];


// DAILY FORECAST
document.getElementById("Day1").innerHTML=days[obj.dayofweek[1]-1].substring(0);
document.getElementById("Day1Icon").src="Icon Sets/"+iconSet+"/"+obj.code[1]+".png";
document.getElementById("Day1HiLo").innerHTML=obj.high[1]+ "&#176;/ "+obj.low[1]+ "&#176;";
document.getElementById("Day2").innerHTML=days[obj.dayofweek[2]-1].substring(0);
document.getElementById("Day2Icon").src="Icon Sets/"+iconSet+"/"+obj.code[2]+".png";
document.getElementById("Day2HiLo").innerHTML=obj.high[2]+ "&#176;/ "+obj.low[2]+ "&#176;";
document.getElementById("Day3").innerHTML=days[obj.dayofweek[3]-1].substring(0);
document.getElementById("Day3Icon").src="Icon Sets/"+iconSet+"/"+obj.code[3]+".png";
document.getElementById("Day3HiLo").innerHTML=obj.high[3]+ "&#176;/ "+obj.low[3]+ "&#176;";
document.getElementById("Day4").innerHTML=days[obj.dayofweek[4]-1].substring(0);
document.getElementById("Day4Icon").src="Icon Sets/"+iconSet+"/"+obj.code[4]+".png";
document.getElementById("Day4HiLo").innerHTML=obj.high[4]+ "&#176;/ "+obj.low[4]+ "&#176;";
document.getElementById("Day5").innerHTML=days[obj.dayofweek[5]-1].substring(0);
document.getElementById("Day5Icon").src="Icon Sets/"+iconSet+"/"+obj.code[5]+".png";
document.getElementById("Day5HiLo").innerHTML=obj.high[5]+ "&#176;/ "+obj.low[5]+ "&#176;"; 
}

function updateClock() {
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
	var currentDate = currentTime.getDate() < 10 ? '' + currentTime.getDate() : currentTime.getDate();
	time_to_change_wall = currentHours + currentMinutes/60;
	timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

	if (ampm == false) {
		timeOfDay = "";
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentTimeString = currentHours + ":" + currentMinutes;
	} else {
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentTimeString = currentHours + ":" + currentMinutes;
	}
		
	document.getElementById("clock").innerHTML = currentTimeString;
	document.getElementById("ampm").innerHTML = timeOfDay;
	document.getElementById("date").innerHTML = days[currentTime.getDay()] + ", " + months[currentTime.getMonth()] + " " + currentDate;

		
	// DAY OR NIGHT CHANGE
	if (dayhour != null) {
		if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { var whereTmp = "night";	} else { var whereTmp = "day"; }
		if (whereTmp != where) { dealWithWeather(obj); } // Refresh the weather for day/night condition.
	}
}

function updateWeather() {
//To enable with the tweak remove the double slash in front of jQuery below

jQuery.get('file:///private/var/mobile/Documents/widgetweather.xml', function(data) {

//This is for testing only. To use as a widget with the tweak add a double slash in front of jQuery below along with the step above

//jQuery.get('widgetweather.xml',function(data) {

obj.updatetimestring = $(data).find('updatetimestring').text();

if (updateFileTimer != obj.updatetimestring) {
	obj.high = new Array;
	obj.low  = new Array;
	obj.code = new Array;
	obj.daynumber = new Array;
	obj.dayofweek = new Array;
	obj.time24hour = new Array;
	obj.htemp = new Array;
	obj.hcode = new Array;
	obj.hpop = new Array;
	obj.hwhere = new Array;

	$(data).find('currentcondition').each( function() {
		obj.city =$(this).find('name').text();
		obj.state =$(this).find('state').text();
		obj.neighborhood =$(this).find('extraLocNeighborhood').text();
		obj.county =$(this).find('extraLocCounty').text();
		obj.country =$(this).find('extraLocCountry').text();
		obj.countrycode =$(this).find('extraLocCountryCode').text();
		obj.statecode =$(this).find('extraLocStateCode').text();
		obj.postalcode =$(this).find('extraLocUzip').text();
		obj.woeid = $(this).find('woeid').text();
		obj.locationid = $(this).find('locationid').text();	
		obj.temp = $(this).find('temp').text(); 
		obj.icon = $(this).find('code').text();
		obj.observationtime = $(this).find('observationtime').text();
		obj.sunset = $(this).find('sunsettime').text();
		obj.sunrise = $(this).find('sunrisetime').text();
		obj.tempUnit = $(this).find('celsius').text();
		obj.moonphase = $(this).find('moonphase').text()*1;
		obj.pressure = $(this).find('pressure').text();
		obj.humidity = $(this).find('humidity').text(); 
		obj.rising = $(this).find('rising').text()*1;		
		obj.visibility = $(this).find('visibility').text();
		obj.RealFeel = $(this).find('chill').text();
		obj.direction = $(data).find('direction').text();
		obj.windspeed = Math.round($(data).find('speed').text());
		obj.unitsdistance = $(this).find('unitsdistance').text();
		obj.unitspressure = $(this).find('unitspressure').text();
		obj.unitsspeed = $(this).find('unitsspeed').text();
		obj.unitstemperature = $(this).find('unitstemperature').text(); 
	});

	var i=0;
	$(data).find('day').each( function() {
		obj.high[i] =$(this).find('high').text();
		obj.low[i] = $(this).find('low').text();
		obj.code[i] = $(this).find('code').text();	
		obj.daynumber[i] = $(this).find('daynumber').text();	
		obj.dayofweek[i] = $(this).find('dayofweek').text();
		i++;
	});

	var h=0;	
	$(data).find('hour').each( function() {
	obj.htemp[h] = $(this).find('temp').text();
	obj.hcode[h] = $(this).find('code').text();
	obj.hpop[h] = Math.round($(this).find('percentprecipitation').text());	
	obj.time24hour[h] = $(this).find('time24hour').text();
	h++;
	});

	updateFileTimer = obj.updatetimestring;
	dealWithWeather(obj);
}
}).fail(function() {
	document.getElementById("xmlupdate").innerHTML = "No XML file !";
});

refreshTimer = setTimeout(updateWeather, 20*1000);
}

// WORKAROUND FOR CORRECT ICONS IN ALL SITUATIONS AND TWELVE HOUR FORMAT* YOU NEED TO LEAVE THE DAY NIGHT FIX AND SUNRISE SUNSET INFORMATION IN SO ICONS DISPLAY. EVEN IF YOU DO NOT SHOW THEM IN A WIDGET

function AdjustIcon(icon, whereTmp) {
	switch(whereTmp) {
		case "day":
			if (icon == 27) { icon = 28; }
			if (icon == 29) { icon = 30; }	
			if (icon == 31) { icon = 32; }	
			if (icon == 33) { icon = 34; }
		break;
		case "night":
			if (icon == 28) { icon = 27; }
			if (icon == 30) { icon = 29; }	
			if (icon == 32) { icon = 31; }	
			if (icon == 34) { icon = 33; }
		break;
	}
	return icon;
}

function TwelveHourForecast(hour) {
	if (ampm == true) { 
		hour = parseInt(hour.split(':')[0]);
		var timeOfhour = ( hour < 12 ) ? "AM" : "PM";
		hour = ( hour > 12 ) ? hour - 12 : hour;
		hour = ( hour == 0 ) ? 12 : hour;
		hour = hour + " " + timeOfhour;
	}
	return hour;
}
