var forecastdisplay = true;

function touchEnd(event) {
	event.preventDefault();
	if (forecastdisplay == false) {
		document.getElementById('TouchForecast').className = "forecastMoveDown";
		document.getElementById('ImagePlace').className = "";
		forecastdisplay = true;
	} else {
		document.getElementById('TouchForecast').className = "forecastMoveUp";
		document.getElementById('ImagePlace').className = "blurry";
		forecastdisplay = false;
	}
	}
