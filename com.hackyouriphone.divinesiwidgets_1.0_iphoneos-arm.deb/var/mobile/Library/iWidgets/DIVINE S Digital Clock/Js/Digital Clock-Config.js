

/*---------------------------------- Display Language Options ----------------------------------*/

/*
var English = true;
var French = false;
var German = false;
var Italian = false;
var Spanish = false;
var Dutch = false;
*/

/*---------------------------------- Calendar Display Option 1 ----------------------------------*/

var DisplayDayMonthDate = false;
var DisplayDayMonth = false;
var DisplayDay = true;
var DisplayDayDate = false;
var DisplayMonthDate = false;
var DisplayDateMonth = false;
var DisplayYear = false;

/*-------------Calendar Display Option 2, Set here if you want the date before the month or after ----------------------------------*/

var DisplayDateMonthAlt = false;
var DisplayMonthDateAlt = true;




var DisplayDayMonthDateAlt = false;
var DisplayDayMonthAlt = false;
var DisplayDayAlt = false;
var DisplayDayDateAlt = false;
var DisplayYearAlt = false;
var DisplayDateAlt = false;