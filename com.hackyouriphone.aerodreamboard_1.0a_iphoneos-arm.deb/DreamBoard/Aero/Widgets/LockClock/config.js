// 12 Hour Code (change to true for 12Hour) 
var twelvehour = true;

function updateClock() {
    var currentTime = new Date();
	var month = "January February March April May June July August September October November December".split(/\s/);
	var day = "Sunday Monday Tueday Wednesday Thursday Friday Saturday".split(/\s/);
    var currentYear = currentTime.getYear();
    var currentMonth = month[currentTime.getMonth()];
    var currentDay = day[currentTime.getDay()];
    var currentDate = currentTime.getDate();
    var currentHours = currentTime.getHours();
    var currentHour = currentTime.getHours();
    var currentMinutes = currentTime.getMinutes();
	if(currentYear < 1000){ currentYear += 1900; }
	if(currentYear == 101){ currentYear = 2001; }
    currentHours = (currentHours < 10 ? "0" : "") + currentHours;
    currentMinutes = (currentMinutes < 10 ? "0" : "") + currentMinutes;
    if (currentHours == 00 && currentMinutes == 00) {
	calendarDate();
    };
	document.getElementById("date").innerText = currentDay + ", " + currentMonth + " " + currentDate;
    if (twelvehour) {
	    document.getElementById("time").innerText = currentHour + ":" + currentMinutes + " AM";
	if (currentHours > 12) {
	    var currentHour = currentHours - 12;
		    document.getElementById("time").innerText = currentHour + ":" + currentMinutes + " PM";
	};
	if (currentHours == 12) {
	    var currentHour = 12;
		    document.getElementById("time").innerText = currentHour + ":" + currentMinutes + " PM";
	};
	if (currentHours == 0) {
	    var currentHour = 12;
		    document.getElementById("time").innerText = currentHour + ":" + currentMinutes + " AM";
	};
    }
};
