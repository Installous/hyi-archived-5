/*

==========================
Endroid Weather Widget
==========================

Wynd.

*/
//localStorage.setItem("zip", 77429)
window.onload = onLoad;
var MiniIcons =[
"tstorm3",			//0		tornado
"tstorm3",			//1		tropical storm
"tstorm3",			//2		hurricane
"tstorm3",			//3		severe thunderstorms
"tstorm3",			//4		thunderstorms
"sleet",			//5		mixed rain and snow
"sleet",			//6		mixed rain and sleet
"sleet",			//7		mixed rain and sleet
"sleet",			//8		freezing drizzle
"light_rain",		//9		drizzle
"sleet",			//10	freezing rain
"showers",			//11	showers
"showers",			//12	showers
"snow1",			//13	snow flurries
"snow1",			//14	light snow showers
"snow4",			//15	blowing snow
"snow4",			//16	snow
"hail",				//17	hail
"sleet",			//18	sleet
"fog",				//19	dust
"fog",				//20	foggy
"fog",				//21	haze
"fog",				//22	smokey
"windy",			//23	blustery
"windy",			//24	windy
"windy",			//25	cold
"overcast",			//26	cloudy
"cloudy4_night",	//27	mostly cloudy (night)
"cloudy4",			//28	mostly cloudy (day)
"cloudy1_night",	//29	partly cloudy (night)
"cloudy1",			//30	partly cloudy (day)
"sunny_night",		//31	clear (night)
"sunny",			//32	sunny
"sunny_night",		//33	fair (night)
"sunny",			//34	fair (day)
"hail",				//35	mixed rain and hail
"sunny",			//36	hot
"tstorm1",			//37	isolated thunderstorms
"tstorm1",			//38	scattered thunderstorms
"tstorm1",			//39	scattered thunderstorms
"showers",			//40	scattered showers
"snow5",			//41	heavy snow
"snow3",			//42	scattered snow showers
"snow5",			//43	heavy snow
"cloudy1",			//44	partly cloudy
"tstorm3",			//45	thundershowers
"snow1",			//46	snow showers
"tstorm1",			//47	isolated thunderstorms
"dunno"];			//3200	not available
var locale;
var updateInterval = 10;
var postal;
document.ontouchmove = function(event) {
	event.preventDefault();
}
function checkZip(){
	//see if zipcode is still the same, otherwise reload the weather
	if(localStorage.getItem("zip")!=locale){
		onLoad();
	}else{
		setTimeout(checkZip, 500);
	}
}
function onLoad(){
	if(localStorage.getItem("zip")==null)
		//if no zip code, then try again later
		setTimeout(onLoad, 500);
	else{
		//sets based on the localstorage cache
		document.getElementById("city").innerText=localStorage.getItem("cachecity");
		document.getElementById("desc").innerText=localStorage.getItem("cachedesc");
		document.getElementById("temp").innerText=localStorage.getItem("cachetemp");
		document.getElementById("high").innerText=localStorage.getItem("cachehigh");
		document.getElementById("low").innerText=localStorage.getItem("cachelow");
		document.getElementById("weatherIcon").src=localStorage.getItem("cacheicon");
		//sets zipcode to the localstorage value
		locale= localStorage.getItem("zip");
		//icon animation
		document.getElementById('icon').style.webkitTransform='scale(0)';
		document.getElementById('icon').style.opacity=0;
		//gets the weather
		validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
		//animation
		setTimeout("document.getElementById('icon').style.webkitTransform='scale(1)';",500);
		setTimeout("document.getElementById('icon').style.opacity=1;",500);
		//checks to see if the zip was changed
		checkZip();
	}
}
function setPostal(obj){	
	if (obj.error == false){
		if(obj.cities.length > 0){
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%");
			weatherRefresherTemp();
		}else{
			document.getElementById("city").innerText="Not Found";
		}
	}else{
		document.getElementById("city").innerText=obj.errorString;
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
	}
}
function dealWithWeather(obj){
	document.getElementById("city").innerText=obj.city;
	document.getElementById("desc").innerText=obj.description;
	document.getElementById("temp").innerText=obj.temp+"�";
	document.getElementById("high").innerText=obj.high+"�";
	document.getElementById("low").innerText=obj.low+"�";
	document.getElementById("weatherIcon").src="/private/var/mobile/Library/DreamBoard/Aero/Widgets/Weather/Icons"+"/"+MiniIcons[obj.icon]+".png";
	//stores cache values
	localStorage.setItem("cachecity", obj.city);
	localStorage.setItem("cachedesc", obj.description);
	localStorage.setItem("cachetemp", (obj.temp+"�"));
	localStorage.setItem("cachehigh", (obj.high+"�"));
	localStorage.setItem("cachelow", (obj.low+"�"));
	localStorage.setItem("cacheicon",("/private/var/mobile/Library/DreamBoard/Aero/Widgets/Weather/Icons"+"/"+MiniIcons[obj.icon]+".png"));	
}
function weatherRefresherTemp(){
	fetchWeatherData(dealWithWeather,postal);
	setTimeout(onLoad, 60*1000*updateInterval);
}
function constructError (string)
{
	return {error:true, errorString:string};
}
function findChild (element, nodeName)
{
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}
function fetchWeatherData (callback, zip)
{
	url="http://weather.yahooapis.com/forecastrss?u=f&p=";
	var xml_request = new XMLHttpRequest();
	xml_request.onload = function(e) {xml_loaded(e, xml_request, callback);}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url+zip);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null); 
	return xml_request;
}
function xml_loaded (event, request, callback)
{
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city");
		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill"); 	
		conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text"); 
		var div = document.createElement("div");
		div.innerHTML = request.responseText;
		var list = div.getElementsByTagName("yweather:forecast");
		// high and low, from yahoo weather
		obj.high = list[0].getAttribute("high");
		obj.low = list[0].getAttribute("low");
		callback (obj); 
	}else{
		callback ({error:true, errorString:"XML request failed. no responseXML"});
	}
}
function validateWeatherLocation (location, callback)
{
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location};
	callback (obj);
}