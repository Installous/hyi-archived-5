// 12 Hour Code (change to true for 12Hour) 
var twelvehour = true;

function updateClock() {
    var currentTime = new Date();
    var currentHours = currentTime.getHours();
    var currentHour = currentTime.getHours();
    var currentMinutes = currentTime.getMinutes();
    currentHours = (currentHours < 10 ? "0" : "") + currentHours;
    currentMinutes = (currentMinutes < 10 ? "0" : "") + currentMinutes;
    if (currentHours == 00 && currentMinutes == 00) {
	calendarDate();
    };
    if (twelvehour) {
	    document.getElementById("time").innerText = currentHour + ":" + currentMinutes + " AM";
	if (currentHours > 12) {
	    var currentHour = currentHours - 12;
		    document.getElementById("time").innerText = currentHour + ":" + currentMinutes + " PM";
	};
	if (currentHours == 12) {
	    var currentHour = 12;
		    document.getElementById("time").innerText = currentHour + ":" + currentMinutes + " PM";
	};
	if (currentHours == 0) {
	    var currentHour = 12;
		    document.getElementById("time").innerText = currentHour + ":" + currentMinutes + " AM";
	};
    }
};
