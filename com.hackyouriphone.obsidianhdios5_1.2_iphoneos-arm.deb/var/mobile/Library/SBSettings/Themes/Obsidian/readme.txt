The SBSettings themes should be placed in the <Stash/Library/SBSettings/Themes> directory and activated through the settings. You can also move and rename a respring image to the main SBSettings folder from the main theme folder in the download.  

Thanks for your support, let me know if you have any trouble :)

ENJOY!!