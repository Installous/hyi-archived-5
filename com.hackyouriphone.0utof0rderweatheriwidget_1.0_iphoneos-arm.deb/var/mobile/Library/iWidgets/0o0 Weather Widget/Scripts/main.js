var updateFileTimer = "";
var obj = new Array;
var where = "";
var time_to_change_wall;
var dayhour;
var nighthour;
var forecastdisplay = false;
var ampm = false;   //Don't change. Use Widget Weather settings.
var ChangeClick = true; // Don't touch unless you are testing on computer


// Set a time out for all ajax requests, desactivate the cache.
$.ajaxSetup({timeout: 8000, cache: false}); 


function init() {
updateClock();
setInterval(updateClock, 1000);
updateWeather();

if (ChangeClick == false) {
	document.getElementById("TouchLayer").addEventListener("touchend", touchEnd, false);
	} else {       document.getElementById("TouchLayer").addEventListener("click", touchEnd, false);
	}
}

function touchEnd(event) {
	if ( forecastdisplay == false ) {	       document.getElementById('widget').className = "WidgetMoveUp";
document.getElementById('forecast').className = "ForecastShow";
		forecastdisplay = true;
		} else {	       document.getElementById('widget').className = "WidgetMoveDown";
document.getElementById('forecast').className = "ForecastHide";
		forecastdisplay = false;
		}
}


function dealWithWeather(obj) {
// TIME INFO
document.getElementById("xmlupdate").innerHTML = lastupdatetext + obj.updatetimestring.slice(11, 16);

// MAIN INFORMATION
var sunriseh = parseInt(obj.sunrise.split(':')[0]) + GMT;
var sunrisem = obj.sunrise.split(':')[1];
var sunseth = parseInt(obj.sunset.split(':')[0]) + GMT;
var sunsetm = obj.sunset.split(':')[1];
dayhour = sunriseh + parseInt(sunrisem)/60;
nighthour = sunseth + parseInt(sunsetm)/60;
		
if (ampm == false) {
	var sunriseh = ( sunriseh < 10 ? "0" : "" ) + sunriseh;
	var sunseth = ( sunseth < 10 ? "0" : "" ) + sunseth;
	var sunrise = sunriseh + ":" + sunrisem;		
	var sunset = sunseth + ":" + sunsetm;
	} else {
	var timeOfSunset = ( sunseth < 12 ) ? "am" : "pm";
	var timeOfSunrise = ( sunriseh < 12 ) ? "am" : "pm";
	sunriseh = ( sunriseh > 12 ) ? sunriseh - 12 : sunriseh;
	sunriseh = ( sunriseh == 0 ) ? 12 : sunriseh;
	sunseth = ( sunseth > 12 ) ? sunseth - 12 : sunseth;
	sunseth = ( sunseth == 0 ) ? 12 : sunseth;
	var sunrise = sunriseh + ":" + sunrisem + " " + timeOfSunrise;	
	var sunset = sunseth + ":" + sunsetm + " " + timeOfSunset;
}

// CHANGE THE BACKGROUND FOR DAY OR NIGHT CONDITION
if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { where = "night"; } else { where = "day"; }

// City Name Display Option

var cityname = obj.city;
switch (UseExtraLocation) {
	case "city":
	if ((obj.extraLocCity != null) && (obj.extraLocCity != "")) { cityname = obj.extraLocCity; }
	break;
	case "neighborhood":
	if ((obj.extraLocNeighborhood != null) && (obj.extraLocNeighborhood != "")) { cityname = obj.extraLocNeighborhood; }
	else if ((obj.extraLocCounty != null) && (obj.extraLocCounty != "")) { cityname = obj.extraLocCounty; }
	break;
}

document.getElementById("city").innerHTML = cityname;
document.getElementById("temp").innerHTML = obj.temp + "&#176;";
document.getElementById("high").innerHTML = hightext + obj.high[0] + "&#176;";
document.getElementById("low").innerHTML = lowtext + obj.low[0] + "&#176;";
document.getElementById("Day0Icon").src = "Icon Sets/"+iconSet+"/"+AdjustIcon(obj.icon, where)+".png";
document.getElementById("desc").innerHTML = WeatherDesc[obj.icon];
document.getElementById("sunrise").innerHTML = sunrisetext + " - " + sunrise;
document.getElementById("sunset").innerHTML = sunsettext + " - " + sunset;

// DAILY FORECAST
document.getElementById("Day1").innerHTML=days[obj.dayofweek[1]-1].substring(0);
document.getElementById("Day1Icon").src="Icon Sets/"+iconSet+"/"+obj.code[1]+".png";
document.getElementById("Day1HiLo").innerHTML=obj.high[1]+ "&#176;/ "+obj.low[1]+ "&#176;";
document.getElementById("Day2").innerHTML=days[obj.dayofweek[2]-1].substring(0);
document.getElementById("Day2Icon").src="Icon Sets/"+iconSet+"/"+obj.code[2]+".png";
document.getElementById("Day2HiLo").innerHTML=obj.high[2]+ "&#176;/ "+obj.low[2]+ "&#176;";
document.getElementById("Day3").innerHTML=days[obj.dayofweek[3]-1].substring(0);
document.getElementById("Day3Icon").src="Icon Sets/"+iconSet+"/"+obj.code[3]+".png";
document.getElementById("Day3HiLo").innerHTML=obj.high[3]+ "&#176;/ "+obj.low[3]+ "&#176;";
document.getElementById("Day4").innerHTML=days[obj.dayofweek[4]-1].substring(0);
document.getElementById("Day4Icon").src="Icon Sets/"+iconSet+"/"+obj.code[4]+".png";
document.getElementById("Day4HiLo").innerHTML=obj.high[4]+ "&#176;/ "+obj.low[4]+ "&#176;";
document.getElementById("Day5").innerHTML=days[obj.dayofweek[5]-1].substring(0);
document.getElementById("Day5Icon").src="Icon Sets/"+iconSet+"/"+obj.code[5]+".png";
document.getElementById("Day5HiLo").innerHTML=obj.high[5]+ "&#176;/ "+obj.low[5]+ "&#176;"; 
}

function updateClock() {
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
	var currentDate = currentTime.getDate() < 10 ? '' + currentTime.getDate() : currentTime.getDate();
	time_to_change_wall = currentHours + currentMinutes/60;
	timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

	if (ampm == false) {
		timeOfDay = "";
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentTimeString = currentHours + ":" + currentMinutes;
	} else {
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
//		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentTimeString = currentHours + ":" + currentMinutes;
	}
		
	document.getElementById("clock").innerHTML = currentTimeString;
	if (lang == "en") {	document.getElementById("date").innerHTML = days[currentTime.getDay()].substring(0) + ", " + months[currentTime.getMonth()].substring(0, 3) + " " + currentDate; }
	else { document.getElementById("date").innerHTML = days[currentTime.getDay()].substring(0); + " " + currentDate + " " + months[currentTime.getMonth()].substring(0, 3); }

		
	// DAY OR NIGHT CHANGE
	if (dayhour != null) {
		if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { var whereTmp = "night";	} else { var whereTmp = "day"; }
		if (whereTmp != where) { dealWithWeather(obj); } // Refresh the weather for day/night condition.
	}
}

function updateWeather() {
jQuery.get('file:///private/var/mobile/Documents/widgetweather.xml', function(data) {
//jQuery.get('widgetweather.xml',function(data) {

obj.updatetimestring = $(data).find('updatetimestring').text();

if (updateFileTimer != obj.updatetimestring) {
	obj.high = new Array;
	obj.low  = new Array;
	obj.code = new Array;
	obj.daynumber = new Array;
	obj.dayofweek = new Array;
	obj.time24hour = new Array;

	$(data).find('currentcondition').each( function() {
		obj.city =$(this).find('name').text();	   
		obj.extraLocCity = $(this).find('extraLocCity').text();
		obj.extraLocNeighborhood = $(this).find('extraLocNeighborhood').text();
		obj.extraLocCounty = $(this).find('extraLocCounty').text();
		obj.temp = $(this).find('temp').text(); 
		obj.icon = $(this).find('code').text();
		obj.observationtime = $(this).find('observationtime').text();
		obj.sunset = $(this).find('sunsettime').text();
		obj.sunrise = $(this).find('sunrisetime').text();
		obj.tempUnit = $(this).find('celsius').text();
	});

	$(data).find('settings').each( function() {
		obj.timehour = $(this).find('timehour').text();
		ampm = (obj.timehour == "24h") ? false : true;	
	});

	 var i=0;
	$(data).find('day').each( function() {
		obj.high[i] =$(this).find('high').text();
		obj.low[i] = $(this).find('low').text();
		obj.code[i] = $(this).find('code').text();	
		obj.daynumber[i] = $(this).find('daynumber').text();	
		obj.dayofweek[i] = $(this).find('dayofweek').text();
		i++;
	});

	updateFileTimer = obj.updatetimestring;
	dealWithWeather(obj);
}
}).fail(function() {
	document.getElementById("xmlupdate").innerHTML = "No XML file !";
});

refreshTimer = setTimeout(updateWeather, 20*1000);
}

// WORKAROUND FOR CORRECT ICONS IN ALL SITUATIONS AND TWELVE HOUR FORMAT*

function AdjustIcon(icon, whereTmp) {
	switch(whereTmp) {
		case "day":
			if (icon == 27) { icon = 28; }
			if (icon == 29) { icon = 30; }	
			if (icon == 31) { icon = 32; }	
			if (icon == 33) { icon = 34; }
		break;
		case "night":
			if (icon == 28) { icon = 27; }
			if (icon == 30) { icon = 29; }	
			if (icon == 32) { icon = 31; }	
			if (icon == 34) { icon = 33; }
		break;
	}
	return icon;
}


