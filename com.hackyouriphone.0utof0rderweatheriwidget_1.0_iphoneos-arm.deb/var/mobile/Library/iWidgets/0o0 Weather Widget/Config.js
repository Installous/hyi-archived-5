// WIDGET WEATHER Forecast Edition //
// By Widget Weather Team //
	   
					      
var GMT = 0;					// Adjust sunset/sunrise time if necessary

