var MainColor = "Black";
var SecondColor = "linear-gradient(to left, #7474bf, #348ac7)";
var DarkIcon = true;
var ZoomLevel = 90;