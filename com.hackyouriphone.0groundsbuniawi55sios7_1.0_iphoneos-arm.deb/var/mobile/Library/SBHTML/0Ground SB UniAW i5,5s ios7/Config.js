// UniAW6.4SB By Ian Nicoll and Dacal



/*  LANGUAGES LIST:

(it) for Italian

(fi) for Finland

(nl) for Dutch

(fr) for french

(ge) for german

(sp) for spanish

(cn) for Chinese

(ru) for Russian

(en) or for english

*/



var lang = "en"; /* Choose from the list above.

Note: Not all weather condition translations have been done yet. */



var gps = true;

var updateInterval = 15; // in minutes.

var useAccuweather =true; // false for Yahoo.

var useRealFeelForForecast = false; // set to false if using Yahoo.

var Yahoo_Code = "623261";

//var Accuweather_Code = "ASI|PH|RP115|GUADALUPE|"; // See "ReadMe" file.

var Accuweather_Code = "ASI|CN|CH006|ZHUHAI|";



var sunmoon_position_refresh = true; // true to update the moon/sun position & twilight effect every minute.

var twilight = true; // Twilight effects around sunrise/sunset times.



var Hide_All_Weather_Info = false; // for "animations only" set to "true"

var Hide_WeatherInfo_Background = false; // for "animations only" set to "true"

var Hide_Forecast_Background = true; // for "animations only" set to "true"

var Hide_Forecast = true; // for "animations only" set to "true"

var showDock = false; // for "animations only" set to "false"



var Wallpaper_options = "weatherwalls"; // slideshow, timedwalls, daynightwalls, weatherwalls or none (default background);



var AnalogClock = false; // for "animations only" set to "false"

var AnalogClock_Calendar =true; // for "animations only" set to "false"

var DigitalClock = true;

var SecDisplay = false; // digital clock only.

var Single_Line_Date = false;



var ampm =false; // for digital clock & Last Update.



var Second_Hand_Options = "big";	 // big, small, both or none.

var Second_Hand_Sweep = true;



var No_Internet_logo = true; // true to show logo when offline.

var logo_color = "glass"; // blue, gold, silver or glass.



var tempUnit = "c"; // "f" for fahrenheit.

var useRealFeel = false; // for main temperature + Hi/Lo.



var GMT = 0; // adjust for summertime.



var Strong_Wind = 0; // Wind speed required to activate wind effects.



var SunsetSunrise = true;



var ShowAstronaut =false;



var ShowWiper = true;



var ShowRainbow = true;



var Show_Birds = false;

var V_Formation_Birds = true;



var UseCityGPS = false; // Use the GPS localization (if available).

var UseNeighborhood = false; // Use neighborhood (or state) for Cyty name.



var Reverse_Hi_Lo = false; // Display Hi temperatures first in the 4 day forecast.

var iconSet = "HTC"; // HTC, DB, spils, stardock, or semitrans.



var ShowBigBalloons = false;

var Number_Of_Big_Balloons = 3; // no limit.

var ShowSmallBalloons = false;

var Number_Of_Small_Balloons = 3; // no limit.

var Cloudy_Balloons = true;



var DropRain = true;	

var RainDropsAndCircles = true;



var FullScreenFogHaze = true;

var FullScreenClouds = false;



var wind_effects = "none"; // leaves, dandelion, windmill or none.

var White_Dandelion_Seeds_During_Night = false;

var White_Dandelion_Flowers_During_Night = false;



var frost_effect = true; // frost effect when your temp hits 0C or 32F.



var DacalSun = true;

var sun_moon_arc = false;

var Sun_Moon_from_right_to_left = false;



var PicNumber = 15; //for SlideShow.

var PicExt = "jpg"; // jpg or png.

var SlideSpeed = 10; // in seconds.



var DemoMode = false;

var WeatherTest = "partlycloudy"; // choose from list below.

var WindTest = 40; // set higher than "strong_wind" value to activate.

var tempTest = 61; // To see frost effect in demo mode set this to zero or below.

var sunrise_demo = "6:00"; // IN 24 HOURS FORMAT !

var sunset_demo = "20:00"; // IN 24 HOURS FORMAT !



/* WEATHER CONDITIONS LIST FOR DEMO MODE:

clear

cloud

fair

fog

frost

hail

haze

heavy_snow

mostlycloudy

partlycloudy

rain

showers_cloud

sleet

snow

snow_showers

thunderstorm

windy

*/



//END