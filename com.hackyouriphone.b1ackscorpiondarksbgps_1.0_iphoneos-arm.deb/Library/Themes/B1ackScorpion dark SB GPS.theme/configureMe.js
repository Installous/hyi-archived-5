  /* Done by Dacal mod by DemoneLatino */

/* *************************************** */
/* The following scripts will allow you to fine tune */
/* *************************************** */

/* *************************************** */
/* ************* CLOCK **************** */

var Clock = "24"; // <--- HERE 12 or 24 choose you,change "24" to "12" If you use "12H"

var Seconds = false; // true to enable seconds,"false" is better,battery eater!!

/* *************************************** */
/* ************* LANGUAGE **************** */
//Choose Languages:  
//(fr) for french; 
//(de) for german; 
//(es) for spanish;
//(it) for italian;
//(en) for english;

var Lang = "en" // <-- change here your language

/* *************************************** */
/* ************* Weather  **************** */

// Use www.weather.com to find your weathercode
// For example searching for Milan Italy will get you this URL
// http://www.weather.com/weather/right-now/Milan+Italy+ITXX0042
// The last part ITXX0042 is the weathercode to use in "var locale"

var locale = "ROXX0019" // leave "0" if you want to use the GPS or enter your code if you don't have GPS(myLocation) 

//you not have (GPS) "myLocation" download from cydia "GPS Weather Lockscreen" by crazyvivek(iOS 4.x - 5.0.1) or search on google the version compatible with iOS 5.1.1 or contact me via cydia for more support or talk with me on TWITTER @DemoneLatino

var Temp = "c";  //  "c" for Celsius / "f" for fahrenheit.

var updateInterval = 5;  // refresh weather in minutes.

var iconSet = "YahooIcons"  // add your own set

var iconExt = ".png"  // icons extension

var useRealFeel = false // true|false

var source = 'yahooWeather' // Don't touch here!