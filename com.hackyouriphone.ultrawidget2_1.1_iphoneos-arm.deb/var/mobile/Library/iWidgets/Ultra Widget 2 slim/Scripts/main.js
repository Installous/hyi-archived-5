
var updateWeatherEvery = updateInterval*60*1000;
var xmldata = false;
var postal;
var filename = "";
var where = "";
var whereOld = "";
var refreshLocationTimer;
var updateTimer = 0;
var zip;
var forecastdisplay = true;

switch (lang) {
case "fr":
	var days = ["Dim","Lun","Mar","Mer","Jeu","Ven","Sam"];
	var months=['Jan','Fev','Mar','Avr','Mai','Jui','Jui','Aou','Sep','Oct','Nov','Dec'];
break;
case "de":
	var days = ["Son","Mon","Die","Mit","Don","Fre","Sam"];
	var months=["Jan","Feb","Mar","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"];	    
break;
case "sp":
	var days = ["Dom","Lun","Mar","Mie","Jue","Vie","Sab"];
	var months=['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
break;
case "it":
	var days = ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
	var months=['Gen','Feb','Mar','Apr','Mag','Giu','Lug','Ago','Set','Ott','Nov','Dic'];
break;
default: 
	var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
	var months=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
break;
case "ja":
	var days = ["&#26085;&#26332;&#26085;","&#26376;&#26332;&#26085;","&#28779;&#26332;&#26085;","&#27700;&#26332;&#26085;","&#26408;&#26332;&#26085;","&#37329;&#26332;&#26085;","&#22303;&#26332;&#26085;"];
	var months=["1&#26376;","2&#26376;","3&#26376;","4&#26376;","5&#26376;","6&#26376;","7&#26376;","8&#26376;","9&#26376;","10&#26376;","11&#26376;","12&#26376;"];
break;
}
function updateClock() {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();
timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
if (ampm == false) {
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
	}
if (ampm == true) {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("hour").innerHTML = currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("ampm").innerHTML = timeOfDay;
document.getElementById("second").innerHTML = currentSeconds;
document.getElementById("year").innerHTML = currentYear;

if (lang == "am") {
	document.getElementById("weekday").innerHTML = days[currentTime.getDay()] ;
	document.getElementById("month").innerHTML = document.getElementById("weekday").innerHTML + " "+ months[currentTime.getMonth()] + " " + document.getElementById("date").innerHTML;
	document.getElementById("date").innerHTML = currentDate;
	} else {
	document.getElementById("weekday").innerHTML = days[currentTime.getDay()] ;
	document.getElementById("date").innerHTML = currentDate; // DONT WORRY ! IT'S NORMAL
	document.getElementById("month").innerHTML =  document.getElementById("weekday").innerHTML + " "+months[currentTime.getMonth()] + " " + document.getElementById("date").innerHTML;
	}

}
 
function sp(){
var opts = {
  lines: 10, // The number of lines to draw
  length: 0, // The length of each line
  width: 20, // The line thickness
  radius: 30, // The radius of the inner circle
  corners: 1, // Corner roundness (0..1)
  rotate: 0, // The rotation offset
  direction: 1, // 1: clockwise, -1: counterclockwise
  color: 'white', // #rgb or #rrggbb or array of colors
  speed: 1, // Rounds per second
  trail: 60, // Afterglow percentage
  shadow: false, // Whether to render a shadow
  hwaccel: false, // Whether to use hardware acceleration
  className: 'spinner', // The CSS class to assign to the spinner
  zIndex: 2e9, // The z-index (defaults to 2000000000)
  top: '75px', // Top position relative to parent in px
  left: '160px' // Left position relative to parent in px
};
var target = document.getElementById('spins');
var spinner = new Spinner(opts).spin(target);
$(target).data('spinner', spinner);
 			
if ( spn == false ) { 			
 			spinner.stop(); };
 			}
function touchEnd(event){
history.go(0);
}

function Battery() {

refreshBatteryTimer = setTimeout(Battery, 15*1000);

jQuery.get('file:///private/var/mobile/Library/BatteryStats.txt', function(appdata) {

var myvar = appdata;
var substr = appdata.split('\n');
var Level=substr[0].split(':')[1];
var State=substr[1].split(':')[1];

document.getElementById("LevelDisplay").innerHTML = Level +"% ";

var bsrc = "Images/" + barn + ".png"
document.getElementById("Batteryoverlay").src = bsrc;

var xyz = document.getElementById("BatteryIcon");
var fill = Level * (65/100);
$( "#BatteryIcon" ).animate({
width: fill,
}, 1000);

if( bfill === "cc" ) {
if( Level >= 0  && Level <= 17 )  {xyz.src = "Images/Battery Fills/6.png";}
if( Level >= 18  && Level <= 34 )  {xyz.src = "Images/Battery Fills/5.png";}
if( Level >= 35  && Level <= 50 )  {xyz.src = "Images/Battery Fills/4.png";}
if( Level >= 51  && Level <= 68 )  {xyz.src = "Images/Battery Fills/3.png";}
if( Level >= 69  && Level <= 83 )  {xyz.src = "Images/Battery Fills/2.png";}
if( Level >= 84  && Level <= 100 )  {xyz.src = "Images/Battery Fills/1.png";}}
else { xyz.src = "Images/Battery Fills/"+bfill+".png";}

if ( baty == false ) {document.getElementById("BatteryIcon").style.display='none';}
if ( baty == false ) {document.getElementById("Batteryoverlay").style.display='none';}
if ( baty == false ) {document.getElementById("LevelDisplay").style.display='none';}

});
jQuery.get('file:///private/var/mobile/Library/Stats/BatteryStats.txt', function(appdata) {

var myvar = appdata;
var substr = appdata.split('\n');
var Level=substr[0].split(':')[1];
var State=substr[1].split(':')[1];

document.getElementById("LevelDisplay").innerHTML = Level +"% ";

var bsrc = "Images/" + barn + ".png"
document.getElementById("Batteryoverlay").src = bsrc;

var xyz = document.getElementById("BatteryIcon");
var fill = Level * (65/100);
 $( "#BatteryIcon" ).animate({
    width: fill
  }, 1000);

if( bfill === "cc" ) {
if( Level >= 0  && Level <= 17 )  {xyz.src = "Images/Battery Fills/6.png";}
if( Level >= 18  && Level <= 34 )  {xyz.src = "Images/Battery Fills/5.png";}
if( Level >= 35  && Level <= 50 )  {xyz.src = "Images/Battery Fills/4.png";}
if( Level >= 51  && Level <= 67 )  {xyz.src = "Images/Battery Fills/3.png";}
if( Level >= 69  && Level <= 83 )  {xyz.src = "Images/Battery Fills/2.png";}
if( Level >= 84  && Level <= 100 )  {xyz.src = "Images/Battery Fills/1.png";}}
else { xyz.src = "Images/Battery Fills/"+bfill+".png";}

if ( baty == false ) {document.getElementById("BatteryIcon").style.display='none';}
if ( baty == false ) {document.getElementById("Batteryoverlay").style.display='none';}
if ( baty == false ) {document.getElementById("LevelDisplay").style.display='none';}
});
}
function weatherlaunch() {
if(gps==true){
jQuery.get('file:///private/var/mobile/Documents/myLocation.txt', function(appdata) {
//jQuery.get('myLocation.txt', function(appdata) {
var myvar = appdata;
var substr = appdata.split('\n');
var templatitude=(substr[0]).split('=');
var templongitude=(substr[1]).split('=');
var latitude = $.trim(templatitude[1]);
var longitude = $.trim(templongitude[1]);
city = latitude+","+longitude;
weather(city);
});}else{weather(city);}};
function weather(loc){
$.simpleWeather({
    location: loc,
    woeid: '',
    unit: tempUnit,
    success: function(weather) {
      temp = weather.temp+'&deg;'+weather.units.temp;
      city = weather.city;
      
		document.getElementById("city").className= TextColor;
		document.getElementById("desc").innerHTML = weather.currently;
		document.getElementById("city").innerHTML = city;
		document.getElementById("temp").innerHTML = temp;

		switch (lang) {
		case "fr":
			translatedesc=weather.currently.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Ensoleill&eacute;'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruine'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Fortes chutes de neige'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Fortes averses'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Ciel d&eacute;gag&eacute;';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Quelques nuages';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Partiellement nuageux';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuages &eacute;parses';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;rement voil&eacute;';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Brume'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuageux';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Brouillard';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Averses';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleil et averses';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Orages';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Orage';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et fortes averses';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Soleil et fortes averses';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re pluie';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pluie';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Averses de neige';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux avec neige';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Soleil et averses de neige';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neige';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et neige';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Glace';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Verglas';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Pluie vergla&ccedil;ante';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Chaud';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Froid';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vent';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Clair';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Tr&egrave;s clair';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Partiellement nuageux';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Brume';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et averses';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et averses';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et fortes averses';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Brouillard';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Flocons de neige'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;res chutes de neige'; } 
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Averses';    }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re bruine';	  }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Pluie et verglas';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Neige et verglas';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Gros orages';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Ouragan';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Orage tropical';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornade';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Buine vergla&ccedil;ante';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Rafales de neige'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Gr&ecirc;le'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Poussi&eacute;reux';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Brumeux';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Temp&ecirc;te';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Pluie et Gr&ecirc;le m&eacute;l&eacute;es';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Orages isol&eacute;s';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Averses isol&eacute;s';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Orages &eacute;parses';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Averses &eacute;parses';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Chutes de neige &eacute;parses';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pluie l&eacute;g&egrave;re et &eacute;clairs';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Non disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Neige poudreuse et vent';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re averse'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tonnerre'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et vent'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Rafales de vent'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Sable'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable et vent'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Rafales'; }
			break;
		case "de":
			translatedesc=weather.currently.toLowerCase();
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado!'; }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropischer Sturm'; }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Wirbelsturm'; }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Schwere Gewitter'; }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Regen und Schnee'; }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Graupelschauer'; }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Gefrierender Nieselregen'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Nieselregen'; }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Gefrierender Regen'; }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Schneegest&ouml;ber'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='light snow grains') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Schneetreiben'; }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Schnee'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Hagel'; }
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Staubig'; }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebelig'; }
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Dunstschleier'; }
			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Dunstig'; }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='St&uuml;rmisch'; }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Windig'; }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Kalt'; }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Bew&ouml;lkt'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Meist Bew&ouml;lkt'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt'; }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Klar'; }
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Sonnig'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Heiter'; }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Regen und Hagel'; }
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Heiss'; }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='&Ouml;rtliche Gewitter'; }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Vereinzelte Gewitter'; }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Vereinzelte Schauer'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Starker Schneefall'; }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Vereinzelte Schneeschauer'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt'; }
			if (translatedesc=='thundershowers') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Scheeschauer'; }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Ouml;rtliche Gewitterschauer'; }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Leichte Regenschauer'; }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='nicht verfuegbar'; }
			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Teilweise Sonnig'; }
			if (translatedesc=='ground fog') { document.getElementById("desc").innerHTML='Bodennebel'; }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Leichter Nieselregen'; }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Leichter Regen'; }
			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Regen'; }
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Regenschauer'; }
			if (translatedesc=='severe thunderstorm/windy') { document.getElementById("desc").innerHTML='Schwere Gewitter/Windig'; }
			break;
		case "sp":
			translatedesc=weather.currently.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleado'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Llovizna'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Nieve fuerte'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Luvia fuerte'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Lluvia y nieve'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Despejado';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Mayormente soleado';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parcialmente soleado';	 }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Intermitente nublado';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sol brumoso';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Bruma'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Mayormente nublado';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nublado';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Niebla';   }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Chubascos';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con chubascos';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tormenta electrica';	}
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Mayormente nublado con tormentas de chubascos';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con tormentas de chubascos';	  }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Lluvia ligera';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Lluvia';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Rafagas';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Mayormente nublado con rafagas';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parcialmente soleado con rafagas';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Rafagas de nieve';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Nieve';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Mayormente nublado con nieve';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Hielo';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Aguanieve';	}
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Lluvia bajo cero';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caluroso';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Frio';	 }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vientoso';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Despejado';	}
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Mayormente despejado';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parcialmente despejado';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Bruma';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con chubascos';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Mayormente nublado con chubascos';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con tormentas de chubascos';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Neblina';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Nieve ligera'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Ligeras precipitaciones de nieve'; }	 
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia';    }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruma';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Mezcla de lluvia y aguanieve';	  }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Mezcla de nieve y aguanieve';	 }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas severas';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Huracan';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tormenta tropical';	 }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Llovizna helada';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Viento y nieve'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Granizo'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvareda';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempestuoso';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Mezcla de lluvia y granizo';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas aisladas';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Tormentas aisladas';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas dispersas';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Chubascos dispersos';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve dispersas';	  }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='LLuvia y tormenta ligera';	 }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Acumulacion de nieve y viento';	  }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia ligera';   }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Truenos'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Mayormente nublado y ventoso'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormentas de arena'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Chubascos y viento'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormentas de arena y ventoso'; }
		break;
		case "it":
			translatedesc=weather.currently.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleggiato'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Pioggerella'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Forti nevicate'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Forti piogge'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Vevischio'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Misto pioggia e neve'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Sereno';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Molto soleggiato';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parzialmente soleggiato';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sole coperto'; }
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Nebbia'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Molto nuvoloso';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuvoloso';	}
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebbia';   }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Diluvio';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleggiato con pioggia';	 }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Fulmini';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tuoni';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Molto Nuvoloso con pioggia e fulmini';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Possibili Piogge';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Pioggia leggera';   }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pioggia';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Nevischio'; }
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Nuvoloso con nevischio';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parzialmente soleggiato con neve';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Raffiche di neve';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitazioni nevose';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neve';	  }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Molto nuvoloso con neve';	}
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Ghiaccio';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Nevischio';	}
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Grandine';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pioggia e neve'; }
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caldo';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Freddo';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Ventoso';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Sereno';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Molto sereno';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Velato';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Cielo velato';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso con raffiche';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebbiolina';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Neve leggiera'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Poca neve'; }	  
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Forti precipitazioni';	 }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Freddino';	 }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Misto pioggia e nevischio';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Misto neve e nevischio';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tuoni e fulmini';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Uragano';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tempesta tropicale';	  }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Grandine';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Vento e neve'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Grandine'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvere';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempesa';	 }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='misto neve e grandine';	  }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Fulmini isolati';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Temporali isolati';	  }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tempesta di fulmini';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Tempesta di pioggia';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Neve sparsa';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pioggia leggera con fulmini';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Troppa neve';	}
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Piccole precipitazioni';	  }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tuoni'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Molto nuvoloso con vento'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormenta'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Pioggia e vento'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormenta ventosa'; }
			break;
		case "en":		       
			translatedesc=weather.currently.toLowerCase();
			document.getElementById("desc").innerHTML=weather.currently.toLowerCase();
		break;
		case "ja":		       
			document.getElementById("desc").style.display="none";
		break;
		}		
     // WEATHER CONDITION OBVIOUSLY
      hilo1= weather.forecast[0].low+"&deg;/"+weather.forecast[0].high+"&deg;";
      hilo2= weather.forecast[1].low+"&deg;/"+weather.forecast[1].high+"&deg;";
      hilo3= weather.forecast[2].low+"&deg;/"+weather.forecast[2].high+"&deg;";
      hilo4= weather.forecast[3].low+"&deg;/"+weather.forecast[3].high+"&deg;";
      hilo5= weather.forecast[4].low+"&deg;/"+weather.forecast[4].high+"&deg;";
		document.getElementById("weathericon").src= "Icons/" + icons + "/" + weather.code +".png"; 
		document.getElementById("Day0Icon").src= "Icons/" + icons + "/" + weather.forecast[0].code +".png";
		document.getElementById("Day0HiLo").innerHTML=hilo1;
		document.getElementById("Day1Icon").src= "Icons/" + icons + "/" + weather.forecast[1].code +".png";
		document.getElementById("Day1HiLo").innerHTML=hilo2
		document.getElementById("Day2Icon").src= "Icons/" + icons + "/" + weather.forecast[2].code + ".png";
		document.getElementById("Day2HiLo").innerHTML=hilo3
		document.getElementById("Day3Icon").src= "Icons/" + icons + "/" + weather.forecast[3].code + ".png";
		document.getElementById("Day3HiLo").innerHTML=hilo4
		document.getElementById("Day4Icon").src= "Icons/" + icons + "/" + weather.forecast[4].code + ".png";
		document.getElementById("Day4HiLo").innerHTML=hilo5
		
		var transday0 = nameday(weather.forecast[0].day);
		document.getElementById("Day0").innerHTML= transday0;
		var transday1 = nameday(weather.forecast[1].day);
		document.getElementById("Day1").innerHTML= transday1;
		var transday2 = nameday(weather.forecast[2].day);
		document.getElementById("Day2").innerHTML= transday2;
		var transday3 = nameday(weather.forecast[3].day);
		document.getElementById("Day3").innerHTML= transday3;
		var transday4 = nameday(weather.forecast[4].day);
		document.getElementById("Day4").innerHTML= transday4;
$('#spins').data('spinner').stop();
Battery();
var liveweather = 
				[
				"thunderstorm",
				"thunderstorm",
				"thunderstorm",
				"thunderstorm",
				"thunderstorm",
				"sleet",
				"sleet",
				"sleet",
				"sleet",
				"showers_cloud",
				"sleet",
				"showers_cloud",
				"rain",
				"snow",
				"snow",
				"snow",
				"snow",
				"hail",
				"sleet",
				"fog",
				"fog",
				"Haze",
				"fog",
				"wind",
				"wind",
				"frost",
				"cloud",
				"partlymoon",
				"partlysunny",
				"partlymoon",
				"partlysunny",
				"moon",
				"sun",
				"partlymoon",
				"partlysunny",
				"sleet",
				"sun",
				"thunderstorm",
				"thunderstorm",
				"thunderstorm",
				"showers_cloud",
				"snow",
				"snow",
				"snow",
				"partlysunny",
				"thunderstorm",
				"snow",
				"thunderstorm",
				"blank"];
	
	document.getElementById("liveweatheriframe").src="Animations/"+liveweather[weather.code]+".html";
	if (hanim == true) { document.getElementById("liveweatheriframe").src="Animations/blank.html";}
 },
    error: function(error) {
      $("#city").html('<p>'+error+'</p>');
      $("#city").html('<p>'+error+'</p>');
	document.getElementById("DateWidget").style.display='none';
	$('#spins').data('spinner').stop();
	Battery();
	document.getElementById("weathericon").src= "../Icons/HTC1/dunno.png"; 
    }
  });}
function nameday(day) {
switch (lang) {
case "fr":
	switch (day){
	    case "Sun":
        { return "Dim"; }
	    case "Mon":
        { return "Lun"; }
        case "Tue":
        { return "Mar"; }
	    case "Wed":
        { return "Mer"; }
        case "Thu":
        { return "Jeu"; }
	    case "Fri":
        { return "Ven"; }
        case "Sat":
        { return "Sam"; }}
break;
case "de":
	switch (day){
	    case "Sun":
        { return "Son"; }
	    case "Mon":
        { return "Mon"; }
        case "Tue":
        { return "Die"; }
	    case "Wed":
        { return "Mit"; }
        case "Thu":
        { return "Don"; }
	    case "Fri":
        { return "Fre"; }
        case "Sat":
        { return "Sam"; }}
break;
case "sp":
	switch (day){
	    case "Sun":
        { return "Dom"; }
	    case "Mon":
        { return "Lun"; }
        case "Tue":
        { return "Mar"; }
	    case "Wed":
        { return "Mie"; }
        case "Thu":
        { return "Jue"; }
	    case "Fri":
        { return "Vie"; }
        case "Sat":
        { return "Sab"; }}
break;
case "it":
	switch (day){
	    case "Sun":
        { return "Dom"; }
	    case "Mon":
        { return "Lun"; }
        case "Tue":
        { return "Mar"; }
	    case "Wed":
        { return "Mer"; }
        case "Thu":
        { return "Gio"; }
	    case "Fri":
        { return "Ven"; }
        case "Sat":
        { return "Sab"; }}
break;
case "en":
	switch (day){
	    case "Sun":
        { return "Sun"; }
	    case "Mon":
        { return "Mon"; }
        case "Tue":
        { return "Tue"; }
	    case "Wed":
        { return "Wed"; }
        case "Thu":
        { return "Thu"; }
	    case "Fri":
        { return "Fri"; }
        case "Sat":
        { return "Sat"; }}
break;
case "ja": 
	switch (day){
	    case "Sun":
        { return "&#26085;&#26332;&#26085;"; }
	    case "Mon":
        { return "&#26376;&#26332;&#26085;"; }
        case "Tue":
        { return "&#28779;&#26332;&#26085;"; }
	    case "Wed":
        { return "&#27700;&#26332;&#26085;"; }
        case "Thu":
        { return "&#26408;&#26332;&#26085;"; }
	    case "Fri":
        { return "&#37329;&#26332;&#26085;"; }
        case "Sat":
        { return "&#22303;&#26332;&#26085;"; }}
break;
}}

var _0xc71e=["\x62\x20\x31\x36\x28\x6E\x2C\x65\x29\x7B\x6C\x20\x6B\x3D\x31\x3B\x64\x28\x6A\x3D\x3D\x22\x63\x22\x29\x7B\x6B\x3D\x31\x7D\x67\x7B\x6B\x3D\x32\x7D\x3B\x6C\x20\x78\x3D\x22\x31\x39\x3A\x2F\x2F\x52\x2E\x57\x2E\x4E\x2F\x59\x2F\x52\x2F\x31\x75\x2E\x31\x62\x3F\x31\x70\x3D\x22\x2B\x65\x2B\x22\x26\x31\x74\x3D\x22\x2B\x6B\x3B\x24\x2E\x31\x73\x28\x27\x31\x72\x3A\x2F\x2F\x31\x6C\x2E\x31\x6B\x2E\x4E\x2F\x31\x65\x2F\x31\x66\x2F\x31\x67\x2E\x31\x6A\x27\x2C\x62\x28\x29\x7B\x31\x6E\x28\x29\x7D\x29\x3B\x24\x2E\x31\x69\x28\x78\x2C\x62\x28\x39\x29\x7B\x50\x3D\x70\x3B\x34\x3D\x7B\x55\x3A\x4B\x7D\x3B\x24\x28\x39\x29\x2E\x35\x28\x27\x31\x63\x27\x29\x2E\x6F\x28\x62\x28\x29\x7B\x64\x28\x31\x64\x3D\x3D\x4B\x29\x7B\x34\x2E\x71\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x31\x71\x27\x29\x2E\x38\x28\x29\x29\x3B\x64\x28\x65\x2E\x31\x6D\x28\x27\x7C\x27\x29\x21\x3D\x2D\x31\x29\x7B\x46\x3D\x65\x2E\x31\x6F\x28\x27\x7C\x27\x29\x3B\x34\x2E\x66\x3D\x46\x5B\x33\x5D\x2E\x31\x30\x28\x30\x2C\x31\x35\x29\x7D\x67\x7B\x34\x2E\x66\x3D\x65\x7D\x7D\x67\x7B\x34\x2E\x71\x3D\x71\x3B\x34\x2E\x66\x3D\x58\x2B\x22\x20\x22\x2B\x31\x32\x7D\x34\x2E\x31\x38\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x31\x33\x27\x29\x2E\x38\x28\x29\x29\x2A\x31\x3B\x34\x2E\x31\x34\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x31\x61\x27\x29\x2E\x38\x28\x29\x29\x3B\x34\x2E\x53\x3D\x54\x28\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x22\x56\x22\x29\x2E\x38\x28\x29\x29\x2A\x31\x29\x3B\x34\x2E\x31\x37\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x31\x31\x27\x29\x2E\x38\x28\x29\x29\x3B\x34\x2E\x5A\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x72\x27\x29\x2E\x61\x28\x27\x31\x68\x27\x29\x29\x3B\x34\x2E\x31\x43\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x31\x56\x27\x29\x2E\x38\x28\x29\x29\x2A\x31\x3B\x34\x2E\x44\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x44\x27\x29\x2E\x38\x28\x29\x29\x3B\x64\x28\x6A\x3D\x3D\x31\x29\x7B\x34\x2E\x43\x3D\x31\x57\x2E\x31\x58\x28\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x72\x27\x29\x2E\x38\x28\x29\x29\x2A\x31\x55\x2E\x31\x54\x29\x7D\x67\x7B\x34\x2E\x43\x3D\x24\x28\x37\x29\x2E\x35\x28\x27\x72\x27\x29\x2E\x38\x28\x29\x7D\x34\x2E\x31\x50\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x31\x51\x27\x29\x2E\x38\x28\x29\x29\x3B\x34\x2E\x6B\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x31\x52\x27\x29\x2E\x38\x28\x29\x29\x3B\x34\x2E\x6D\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x27\x31\x5A\x27\x29\x2E\x38\x28\x29\x29\x7D\x29\x3B\x34\x2E\x42\x3D\x5B\x5D\x3B\x34\x2E\x41\x3D\x5B\x5D\x3B\x34\x2E\x45\x3D\x5B\x5D\x3B\x6C\x20\x74\x3D\x30\x3B\x24\x28\x39\x29\x2E\x35\x28\x27\x31\x59\x27\x29\x2E\x6F\x28\x62\x28\x29\x7B\x34\x2E\x42\x5B\x74\x5D\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x61\x28\x27\x38\x27\x29\x29\x3B\x34\x2E\x41\x5B\x74\x5D\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x61\x28\x27\x32\x33\x27\x29\x29\x3B\x34\x2E\x45\x5B\x74\x5D\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x38\x28\x29\x29\x3B\x74\x2B\x2B\x7D\x29\x3B\x34\x2E\x31\x76\x3D\x24\x2E\x36\x28\x24\x28\x39\x29\x2E\x35\x28\x27\x4A\x27\x29\x2E\x61\x28\x27\x7A\x27\x29\x29\x3B\x34\x2E\x32\x30\x3D\x24\x2E\x36\x28\x24\x28\x39\x29\x2E\x35\x28\x27\x4A\x27\x29\x2E\x61\x28\x27\x47\x27\x29\x29\x3B\x34\x2E\x32\x31\x3D\x24\x2E\x36\x28\x24\x28\x39\x29\x2E\x35\x28\x27\x48\x27\x29\x2E\x61\x28\x27\x7A\x27\x29\x29\x3B\x34\x2E\x32\x32\x3D\x24\x2E\x36\x28\x24\x28\x39\x29\x2E\x35\x28\x27\x48\x27\x29\x2E\x61\x28\x27\x47\x27\x29\x29\x3B\x34\x2E\x79\x3D\x5B\x5D\x3B\x34\x2E\x76\x3D\x5B\x5D\x3B\x34\x2E\x77\x3D\x5B\x5D\x3B\x34\x2E\x75\x3D\x5B\x5D\x3B\x34\x2E\x4C\x3D\x5B\x5D\x3B\x34\x2E\x73\x3D\x5B\x5D\x3B\x6C\x20\x69\x3D\x30\x3B\x24\x28\x39\x29\x2E\x35\x28\x27\x31\x53\x27\x29\x2E\x6F\x28\x62\x28\x29\x7B\x34\x2E\x79\x5B\x69\x5D\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x22\x31\x4E\x22\x29\x2E\x38\x28\x29\x29\x2E\x31\x42\x28\x30\x2C\x33\x29\x3B\x34\x2E\x77\x5B\x69\x5D\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x22\x49\x22\x29\x2E\x38\x28\x29\x29\x3B\x34\x2E\x76\x5B\x69\x5D\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x22\x31\x4F\x22\x29\x2E\x38\x28\x29\x29\x3B\x34\x2E\x75\x5B\x69\x5D\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x22\x49\x22\x29\x2E\x38\x28\x29\x29\x3B\x34\x2E\x4C\x5B\x69\x5D\x3D\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x22\x31\x44\x22\x29\x2E\x38\x28\x29\x29\x3B\x34\x2E\x73\x5B\x69\x5D\x3D\x54\x28\x24\x2E\x36\x28\x24\x28\x37\x29\x2E\x35\x28\x22\x56\x22\x29\x2E\x38\x28\x29\x29\x2A\x31\x29\x3B\x69\x2B\x2B\x7D\x29\x3B\x64\x28\x34\x2E\x6D\x3D\x3D\x22\x31\x41\x22\x29\x7B\x34\x2E\x6D\x3D\x34\x2E\x31\x7A\x5B\x30\x5D\x3B\x34\x2E\x53\x3D\x34\x2E\x73\x5B\x30\x5D\x7D\x34\x2E\x31\x77\x3D\x28\x6A\x3D\x3D\x30\x29\x3F\x22\x31\x78\x22\x3A\x22\x31\x79\x22\x3B\x34\x2E\x31\x45\x3D\x28\x6A\x3D\x3D\x30\x29\x3F\x22\x31\x46\x22\x3A\x22\x51\x22\x3B\x34\x2E\x31\x4C\x3D\x28\x6A\x3D\x3D\x30\x29\x3F\x22\x31\x4D\x22\x3A\x22\x51\x2F\x68\x22\x3B\x6E\x28\x34\x29\x7D\x29\x2E\x31\x4B\x28\x62\x28\x29\x7B\x64\x28\x50\x3D\x3D\x70\x29\x7B\x4F\x2E\x4D\x28\x22\x66\x22\x29\x2E\x31\x4A\x3D\x22\x31\x47\x22\x3B\x4F\x2E\x4D\x28\x22\x66\x22\x29\x2E\x31\x48\x3D\x22\x31\x49\x22\x7D\x67\x7B\x6E\x28\x7B\x55\x3A\x70\x7D\x29\x7D\x7D\x29\x7D","\x7C","\x73\x70\x6C\x69\x74","\x7C\x7C\x7C\x7C\x6F\x62\x6A\x7C\x66\x69\x6E\x64\x7C\x74\x72\x69\x6D\x7C\x74\x68\x69\x73\x7C\x74\x65\x78\x74\x7C\x64\x61\x74\x61\x7C\x61\x74\x74\x72\x7C\x66\x75\x6E\x63\x74\x69\x6F\x6E\x7C\x7C\x69\x66\x7C\x7A\x69\x70\x7C\x63\x6F\x6F\x72\x64\x69\x6E\x61\x74\x65\x73\x7C\x65\x6C\x73\x65\x7C\x7C\x7C\x74\x65\x6D\x70\x55\x6E\x69\x74\x7C\x74\x65\x6D\x70\x7C\x76\x61\x72\x7C\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6F\x6E\x7C\x63\x61\x6C\x6C\x62\x61\x63\x6B\x7C\x65\x61\x63\x68\x7C\x74\x72\x75\x65\x7C\x63\x69\x74\x79\x7C\x50\x72\x65\x73\x73\x75\x72\x65\x7C\x66\x6F\x72\x65\x63\x61\x73\x74\x63\x6F\x64\x65\x7C\x7C\x66\x6F\x72\x65\x63\x61\x73\x74\x72\x65\x61\x6C\x6C\x6F\x77\x7C\x66\x6F\x72\x65\x63\x61\x73\x74\x68\x69\x67\x68\x7C\x66\x6F\x72\x65\x63\x61\x73\x74\x6C\x6F\x77\x7C\x75\x72\x6C\x7C\x66\x6F\x72\x65\x63\x61\x73\x74\x64\x61\x79\x7C\x72\x69\x73\x65\x7C\x6D\x6F\x6F\x6E\x64\x61\x74\x65\x7C\x6D\x6F\x6F\x6E\x64\x65\x73\x63\x7C\x70\x72\x65\x73\x73\x75\x72\x65\x7C\x55\x56\x49\x6E\x64\x65\x78\x7C\x6D\x6F\x6F\x6E\x70\x68\x61\x73\x65\x7C\x74\x65\x6D\x70\x7A\x69\x70\x7C\x73\x65\x74\x7C\x4D\x6F\x6F\x6E\x7C\x4C\x6F\x77\x5F\x54\x65\x6D\x70\x65\x72\x61\x74\x75\x72\x65\x7C\x53\x75\x6E\x7C\x66\x61\x6C\x73\x65\x7C\x66\x6F\x72\x65\x63\x61\x73\x74\x72\x65\x61\x6C\x68\x69\x67\x68\x7C\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64\x7C\x63\x6F\x6D\x7C\x64\x6F\x63\x75\x6D\x65\x6E\x74\x7C\x78\x6D\x6C\x64\x61\x74\x61\x7C\x6B\x6D\x7C\x61\x70\x70\x6C\x65\x7C\x69\x63\x6F\x6E\x7C\x63\x6F\x6E\x76\x65\x72\x74\x41\x63\x63\x75\x49\x63\x6F\x6E\x7C\x65\x72\x72\x6F\x72\x7C\x57\x65\x61\x74\x68\x65\x72\x49\x63\x6F\x6E\x7C\x61\x63\x63\x75\x77\x65\x61\x74\x68\x65\x72\x7C\x74\x65\x78\x74\x4C\x61\x74\x7C\x61\x64\x63\x62\x69\x6E\x7C\x72\x69\x73\x69\x6E\x67\x7C\x73\x75\x62\x73\x74\x72\x7C\x57\x69\x6E\x64\x44\x69\x72\x65\x63\x74\x69\x6F\x6E\x7C\x74\x65\x78\x74\x4C\x6F\x6E\x67\x7C\x57\x69\x6E\x64\x53\x70\x65\x65\x64\x7C\x68\x75\x6D\x69\x64\x69\x74\x79\x7C\x7C\x66\x65\x74\x63\x68\x57\x65\x61\x74\x68\x65\x72\x44\x61\x74\x61\x7C\x77\x69\x6E\x64\x64\x69\x72\x7C\x77\x69\x6E\x64\x73\x70\x65\x65\x64\x7C\x68\x74\x74\x70\x7C\x48\x75\x6D\x69\x64\x69\x74\x79\x7C\x61\x73\x70\x7C\x43\x75\x72\x72\x65\x6E\x74\x43\x6F\x6E\x64\x69\x74\x69\x6F\x6E\x73\x7C\x67\x70\x73\x7C\x73\x76\x6E\x7C\x74\x72\x75\x6E\x6B\x7C\x72\x65\x71\x75\x69\x72\x65\x64\x7C\x73\x74\x61\x74\x65\x7C\x67\x65\x74\x7C\x6A\x73\x7C\x67\x6F\x6F\x67\x6C\x65\x63\x6F\x64\x65\x7C\x6E\x69\x63\x68\x6F\x6C\x61\x73\x64\x77\x65\x62\x62\x7C\x69\x6E\x64\x65\x78\x4F\x66\x7C\x77\x65\x61\x74\x68\x65\x72\x63\x68\x65\x63\x6B\x7C\x73\x70\x6C\x69\x74\x7C\x7A\x69\x70\x63\x6F\x64\x65\x7C\x43\x69\x74\x79\x7C\x68\x74\x74\x70\x73\x7C\x67\x65\x74\x53\x63\x72\x69\x70\x74\x7C\x6D\x65\x74\x72\x69\x63\x7C\x41\x70\x70\x6C\x65\x5F\x57\x65\x61\x74\x68\x65\x72\x5F\x44\x61\x74\x61\x7C\x73\x75\x6E\x72\x69\x73\x65\x7C\x70\x72\x65\x73\x73\x75\x72\x65\x75\x6E\x69\x74\x7C\x69\x6E\x7C\x6D\x62\x7C\x66\x6F\x72\x65\x63\x61\x73\x74\x74\x65\x78\x74\x7C\x55\x6E\x6B\x6E\x6F\x77\x6E\x7C\x73\x75\x62\x73\x74\x72\x69\x6E\x67\x7C\x76\x69\x73\x69\x62\x69\x6C\x69\x74\x79\x7C\x52\x65\x61\x6C\x5F\x46\x65\x65\x6C\x5F\x48\x69\x67\x68\x7C\x76\x69\x73\x69\x62\x69\x6C\x69\x74\x79\x75\x6E\x69\x74\x7C\x6D\x69\x7C\x54\x65\x78\x74\x43\x6F\x6C\x6F\x72\x52\x65\x64\x7C\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C\x7C\x4F\x46\x46\x4C\x49\x4E\x45\x7C\x63\x6C\x61\x73\x73\x4E\x61\x6D\x65\x7C\x66\x61\x69\x6C\x7C\x77\x69\x6E\x64\x75\x6E\x69\x74\x7C\x6D\x70\x68\x7C\x44\x61\x79\x43\x6F\x64\x65\x7C\x48\x69\x67\x68\x5F\x54\x65\x6D\x70\x65\x72\x61\x74\x75\x72\x65\x7C\x72\x65\x61\x6C\x46\x65\x65\x6C\x7C\x52\x65\x61\x6C\x46\x65\x65\x6C\x7C\x54\x65\x6D\x70\x65\x72\x61\x74\x75\x72\x65\x7C\x64\x61\x79\x7C\x38\x36\x33\x38\x38\x36\x34\x7C\x33\x33\x7C\x56\x69\x73\x69\x62\x69\x6C\x69\x74\x79\x7C\x4D\x61\x74\x68\x7C\x72\x6F\x75\x6E\x64\x7C\x50\x68\x61\x73\x65\x7C\x57\x65\x61\x74\x68\x65\x72\x54\x65\x78\x74\x7C\x73\x75\x6E\x73\x65\x74\x7C\x6D\x6F\x6F\x6E\x72\x69\x73\x65\x7C\x6D\x6F\x6F\x6E\x73\x65\x74\x7C\x64\x61\x74\x65","","\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65","\x72\x65\x70\x6C\x61\x63\x65","\x5C\x77\x2B","\x5C\x62","\x67"];eval(function (_0xe2f4x1,_0xe2f4x2,_0xe2f4x3,_0xe2f4x4,_0xe2f4x5,_0xe2f4x6){_0xe2f4x5=function (_0xe2f4x3){return (_0xe2f4x3<_0xe2f4x2?_0xc71e[4]:_0xe2f4x5(parseInt(_0xe2f4x3/_0xe2f4x2)))+((_0xe2f4x3=_0xe2f4x3%_0xe2f4x2)>35?String[_0xc71e[5]](_0xe2f4x3+29):_0xe2f4x3.toString(36));} ;if(!_0xc71e[4][_0xc71e[6]](/^/,String)){while(_0xe2f4x3--){_0xe2f4x6[_0xe2f4x5(_0xe2f4x3)]=_0xe2f4x4[_0xe2f4x3]||_0xe2f4x5(_0xe2f4x3);} ;_0xe2f4x4=[function (_0xe2f4x5){return _0xe2f4x6[_0xe2f4x5];} ];_0xe2f4x5=function (){return _0xc71e[7];} ;_0xe2f4x3=1;} ;while(_0xe2f4x3--){if(_0xe2f4x4[_0xe2f4x3]){_0xe2f4x1=_0xe2f4x1[_0xc71e[6]]( new RegExp(_0xc71e[8]+_0xe2f4x5(_0xe2f4x3)+_0xc71e[8],_0xc71e[9]),_0xe2f4x4[_0xe2f4x3]);} ;} ;return _0xe2f4x1;} (_0xc71e[0],62,128,_0xc71e[3][_0xc71e[2]](_0xc71e[1]),0,{}));
function init(){
sp(); 			
 
document.getElementById("city").style.color= TextColor;
document.getElementById("hour").style.color= TextColor;
document.getElementById("tiret").style.color= TextColor;
document.getElementById("minute").style.color= TextColor;
document.getElementById("second").style.color= TextColor;
document.getElementById("weekday").style.color= TextColor;
document.getElementById("month").style.color= TextColor;
document.getElementById("date").style.color= TextColor;
document.getElementById("desc").style.color= TextColor;
document.getElementById("temp").style.color= TextColor;
document.getElementById("Day0").style.color= TextColor;
document.getElementById("Day1").style.color= TextColor;
document.getElementById("Day2").style.color= TextColor;
document.getElementById("Day3").style.color= TextColor;
document.getElementById("Day4").style.color= TextColor;
document.getElementById("Day0HiLo").style.color= TextColor;
document.getElementById("Day1HiLo").style.color= TextColor;
document.getElementById("Day2HiLo").style.color= TextColor;
document.getElementById("Day3HiLo").style.color= TextColor;
document.getElementById("Day4HiLo").style.color= TextColor;
document.getElementById("LevelDisplay").style.color= TextColor;
document.getElementById("city").innerHTML="Loading...";
if (SecDisplay == false) { document.getElementById("second").style.display='none';}
var gaugeback = "Backs/"+back+".png";
document.getElementById("Overlay").src = gaugeback;
if(refresh==="hide"){document.getElementById("buttonback").style.display='none';
document.getElementById("TouchLayer").style.display='none';}
else{var gaugeback2 = "Backs/"+refresh+".png";
document.getElementById("buttonback").src = gaugeback2;
if(refresh==2){document.getElementById("TouchLayer").src = "Images/refresh2.png";}
}
$.ajaxSetup({
cache: false,
headers: {'Cache-Control': 'no-cache'}
});
var ChangeClick = true; // True ONLY if you have problem to show forecast when touch the screen
var el = document.getElementById("TouchLayer");
if ( ChangeClick == false ) {
	el.addEventListener("touchend", touchEnd, false);
	} else {
	el.addEventListener("click", touchEnd, false);
}
updateClock();
setInterval(updateClock, 1000);
weatherlaunch();
setInterval(weatherlaunch, 15*60000);
document.getElementById('TouchLayer').style.webkitAnimationName = "load";
document.getElementById('TouchLayer').style.webkitAnimationDuration = "1.0s";
}
function convertAccuIcon(icon) {
    switch (icon) {
    case 1:
        { return 32; }
    case 2:
        { return 34; }
    case 3:
        { return 34; }
    case 4:
        { return 30; }
    case 5:
        { return 21; }
    case 6:
        { return 28; }
    case 7:
        { return 26; }
    case 8:
        { return 26; }
    case 9:
        { return 48; }
    case 10:
        { return 48; }
    case 11:
        { return 20; }
    case 12:
        { return 11; }
    case 13:
        { return 39; }
    case 14:
        { return 39; }
    case 15:
        { return 38; }
    case 16:
        { return 37; }
    case 17:
        { return 37; }
    case 18:
        { return 40; }
    case 19:
        { return 13; }
    case 20:
        { return 14; }
    case 21:
        { return 14; }
    case 22:
        { return 16; }
    case 23:
        { return 16; }
    case 24:
        { return 8; }
    case 25:
        { return 18; }
    case 26:
        { return 10; }
    case 27:
        { return 48; }
    case 28:
        { return 48; }
    case 29:
        { return 5; }
    case 30:
        { return 36; }
    case 31:
        { return 25; }
    case 32:
        { return 24; }
    case 33:
        { return 31; }
    case 34:
        { return 33; }
    case 35:
        { return 29; }
    case 36:
        { return 29; }
    case 37:
        { return 21; }
    case 38:
        { return 27; }
    case 39:
        { return 45; }
    case 40:
        { return 45; }
    case 41:
        { return 47; }
    case 42:
        { return 47; }
    case 43:
        { return 46; }
    case 44:
        { return 46; }
    }
}

