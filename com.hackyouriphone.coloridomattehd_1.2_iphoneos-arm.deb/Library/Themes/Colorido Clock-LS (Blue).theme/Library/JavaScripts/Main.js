function updateClock ( ){

	var currentTime = new Date ( );
	var currentHours = currentTime.getHours ( );
	var currentMinutes = currentTime.getMinutes ( );
	var currentSeconds = currentTime.getSeconds ( );

  // Convert the hours component to 24-hour format if needed

	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;

// Convert an hours component of "0" to "24"
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
    currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;

  // Compose the string for display
     var currentTimeString = currentHours;
     var currentTimeString1 = currentMinutes;
  // Update the time display

	document.getElementById("hours").firstChild.nodeValue = currentTimeString;
	document.getElementById("mins").firstChild.nodeValue = currentTimeString1;
}

function amPm ( ){

  var currentTime = new Date ( );
  var currentHours = currentTime.getHours ( );

  // Choose either "AM" or "PM" as appropriate
  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
  
  // Convert the hours component to 12-hour format if needed
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

  // Convert an hours component of "0" to "12"
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;

  // Compose the string for display
  var currentTimeString = timeOfDay;

  // Update the time display
	document.getElementById("ampm").firstChild.nodeValue = currentTimeString;
}

function buildCal(m, y, cM, cH, cDW, cD){
	var this_weekday_name = new Array("SUN ","MON ","TUE ","WED ","THU ","FRI ","SAT ")
	var mn = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
	var dim =[31,0,31,30,31,30,31,31,30,31,30,31];
	var oD = new Date(y, m-1, 1); //DD replaced line to fix date bug when current day is 31st
	oD.od=oD.getDay()+1; //DD replaced line to fix date bug when current day is 31st
	var todaydate=new Date() //DD added
	var this_weekday = todaydate.getDay()
	var this_month = todaydate.getMonth()
	var this_date = todaydate.getDate()
	var this_year = todaydate.getYear()
	if (this_year < 2000){this_year = this_year + 1900;}
		dim[1]=(((oD.getFullYear()%100!=0)&&(oD.getFullYear()%4==0))||(oD.getFullYear()%400==0))?29:28;

	var t = '';
	days_TM=dim[this_month];
	if (this_month==0)
		days_PM=dim[11];
	else
		days_PM=dim[this_month-1];
	if (this_month==11)
		days_NM=dim[0];
	else
		days_NM=dim[this_month+1];
	k=0;
	do{
		k2=this_date-k;
		if(k2<=0)
			wkstart=days_PM+k2;
		else
			wkstart=k2;
	k++;
	}
	while(k<=this_weekday)
	for (s=0;s<7;s++){
		if (s==this_weekday){
			t+='<span id="today">'+this_weekday_name[s]+'</span>';
		}
		else{
		t+='<span id="daysofweek">'+this_weekday_name[s]+'</span>';
		}
	}
	for (L=0;L<this_weekday;L++){
		L2=L+wkstart;
		if(L2>days_PM) 
			L2=L2-days_PM;
		if(L2==this_date) 
			t+='<span id="today">'+L2+'</span>';
	}
	
	t+='<div id="month">'+mn[this_month]+" "+'<span id="date">'+this_date+", "+'</span>'+'<span id="year">'+this_year+"."+'</span>'+'</div>';
	
return t;
}
