var MainColor = "Black";
var DarkIcon = true;
var ZoomLevel = 90;