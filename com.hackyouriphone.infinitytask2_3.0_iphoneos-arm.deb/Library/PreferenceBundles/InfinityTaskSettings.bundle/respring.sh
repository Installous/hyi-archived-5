#!/bin/bash

killall -9 assertiond
