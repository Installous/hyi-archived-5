/* 
	Runs actions that places multiple items automatically.
*/
(function(window, doc) {

	function setIconStyles(elementName, width, height, iconwidth){
		var element = doc.getElementById(elementName);
		element.children[0].style.cssText = 'pointer-events:none;width:' + iconwidth + 'px;' + 'height:' + iconwidth + 'px;';
		action.setCss(elementName, 'width', iconwidth+'px');
		action.setCss(elementName, 'height', iconwidth+'px');
		action.setCss(elementName, 'top', height / 2 - iconwidth / 2 + "px");
		switch (elementName) {
			case 'day1icon':
					action.setCss(elementName, 'left', "15px");	
				break;
			case 'day2icon':
					action.setCss(elementName, 'left', "65px");	
				break;
			case 'day3icon':
					action.setCss(elementName, 'left', "115px");	
				break;
			case 'day4icon':
					action.setCss(elementName, 'left', "165px");	
				break;
		}
	}
	function setDayStyles(elementName, width, height, iconwidth){
		action.setCss(elementName, 'width', '40px');
		action.setCss(elementName, 'font-size', '12px');
		action.setCss(elementName, 'height', '12px');
		action.setCss(elementName, 'background-color', 'transparent');
		action.setCss(elementName, 'text-align', 'center');
		action.setCss(elementName, 'top', "5px");
		action.setCss(elementName, 'font-weight', 'bold');
		action.setCss(elementName, 'text-transform', 'uppercase');
		switch (elementName) {
			case 'day1day':
					action.setCss(elementName, 'left', "10px");	
				break;
			case 'day2day':
					action.setCss(elementName, 'left', "60px");	
				break;
			case 'day3day':
					action.setCss(elementName, 'left', "110px");	
				break;
			case 'day4day':
					action.setCss(elementName, 'left', "160px");	
				break;
		}
	}
	function setTempStyles(elementName, width, height, iconwidth){
		action.setCss(elementName, 'width', '25px');
		action.setCss(elementName, 'font-size', '10px');
		action.setCss(elementName, 'height', '12px');
		action.setCss(elementName, 'background-color', 'transparent');
		
		action.setCss(elementName, 'top', height-20 + "px");
		switch (elementName) {
			case 'day1high':
					action.setCss(elementName, 'font-weight', 'bold');
					action.setCss(elementName, 'text-align', 'right');
					action.setCss(elementName, 'left', "4px");	
				break;
			case 'day1low':
					action.setCss(elementName, 'text-align', 'left');
					action.setCss(elementName, 'left', "31px");	
				break;
			case 'day2high':
					action.setCss(elementName, 'font-weight', 'bold');
					action.setCss(elementName, 'text-align', 'right');
					action.setCss(elementName, 'left', "54px");	
				break;
			case 'day2low':
					action.setCss(elementName, 'text-align', 'left');
					action.setCss(elementName, 'left', "81px");	
				break;
			case 'day3high':
					action.setCss(elementName, 'font-weight', 'bold');
					action.setCss(elementName, 'text-align', 'right');
					action.setCss(elementName, 'left', "104px");	
				break;
			case 'day3low':
					action.setCss(elementName, 'text-align', 'left');
					action.setCss(elementName, 'left', "131px");	
				break;
			case 'day4high':
					action.setCss(elementName, 'font-weight', 'bold');
					action.setCss(elementName, 'text-align', 'right');
					action.setCss(elementName, 'left', "154px");	
				break;
			case 'day4low':
					action.setCss(elementName, 'text-align', 'left');
					action.setCss(elementName, 'left', "181px");	
				break;
		}
	}
	var creations = {
		MusicControls: function(){
			var name, div,
			width = 200,
			height = 60;

			action.addtoScreen('playmusic');
			action.addtoScreen('prevmusic');
			action.addtoScreen('nextmusic');

			action.selectedItem = 'playmusic';
			name = customPanel.makeFirstPanel();
			action.selectedItem = 'prevmusic';
			customPanel.addToPanel(name);
			action.selectedItem = 'nextmusic';
			customPanel.addToPanel(name);

			div = doc.getElementById(name);

			action.setCss(name, 'width', width+'px');
			action.setCss(name, 'height', height+'px');
			action.setCss(name, 'background-color', 'rgba(0,0,0,0.6)');
			action.setCss(name, 'border-radius', '10px');
			action.setCss(name, 'left', 320 / 2 - div.offsetWidth / 2 + "px");

			name = 'playmusic';
			div = doc.getElementById(name);
			action.setCss(name, 'width', '50px');
			action.setCss(name, 'height', '30px');
			action.setCss(name, 'line-height', '30px');
			action.setCss(name, 'text-align', 'center');
			action.setCss(name, 'left', width / 2 - 50 / 2 + "px");
			action.setCss(name, 'top', height / 2 - 30 / 2 + "px");

			name = 'prevmusic';
			div = doc.getElementById(name);
			action.setCss(name, 'width', '50px');
			action.setCss(name, 'height', '30px');
			action.setCss(name, 'line-height', '30px');
			action.setCss(name, 'text-align', 'center');
			action.setCss(name, 'left', "20px");
			action.setCss(name, 'top', height / 2 - 30 / 2 + "px");

			name = 'nextmusic';
			div = doc.getElementById(name);
			action.setCss(name, 'width', '50px');
			action.setCss(name, 'height', '30px');
			action.setCss(name, 'line-height', '30px');
			action.setCss(name, 'text-align', 'center');
			action.setCss(name, 'left', "130px");
			action.setCss(name, 'top', height / 2 - 30 / 2 + "px");
		},
		ForecastIcons: function(){
			var name = '', 
			div,
			width = 210,
			height = 60,
			iconwidth = 30;

			action.addtoScreen('day1icon');
			action.addtoScreen('day2icon');
			action.addtoScreen('day3icon');
			action.addtoScreen('day4icon');
			

			action.selectedItem = 'day1icon';
			name = customPanel.makeFirstPanel();
			action.selectedItem = 'day2icon';
			customPanel.addToPanel(name);
			action.selectedItem = 'day3icon';
			customPanel.addToPanel(name);
			action.selectedItem = 'day4icon';
			customPanel.addToPanel(name);


			div = doc.getElementById(name);

			action.setCss(name, 'width', width+'px');
			action.setCss(name, 'height', height+'px');
			action.setCss(name, 'background-color', 'rgba(0,0,0,0.6)');
			action.setCss(name, 'border-radius', '10px');
			action.setCss(name, 'left', 320 / 2 - div.offsetWidth / 2 + "px");

			name = 'day1icon';
			div = doc.getElementById(name);
			div.children[0].style.cssText = 'pointer-events:none;width:' + iconwidth + 'px;' + 'height:' + iconwidth + 'px;';
			action.setCss(name, 'width', iconwidth+'px');
			action.setCss(name, 'height', iconwidth+'px');
			action.setCss(name, 'top', height / 2 - iconwidth / 2 + "px");
			action.setCss(name, 'left', "15px");

			name = 'day2icon';
			div = doc.getElementById(name);
			div.children[0].style.cssText = 'pointer-events:none;width:' + iconwidth + 'px;' + 'height:' + iconwidth + 'px;';
			action.setCss(name, 'width', iconwidth + 'px');
			action.setCss(name, 'height', iconwidth + 'px');
			action.setCss(name, 'top', height / 2 - iconwidth / 2 + "px");
			action.setCss(name, 'left', "65px");

			name = 'day3icon';
			div = doc.getElementById(name);
			div.children[0].style.cssText = 'pointer-events:none;width:' + iconwidth + 'px;' + 'height:' + iconwidth + 'px;';
			action.setCss(name, 'width', iconwidth+'px');
			action.setCss(name, 'height', iconwidth+'px');
			action.setCss(name, 'top', height / 2 - iconwidth / 2 + "px");
			action.setCss(name, 'left', "115px");

			name = 'day4icon';
			div = doc.getElementById(name);
			div.children[0].style.cssText = 'pointer-events:none;width:' + iconwidth + 'px;' + 'height:' + iconwidth + 'px;';
			action.setCss(name, 'width', iconwidth+'px');
			action.setCss(name, 'height', iconwidth+'px');
			action.setCss(name, 'top', height / 2 - iconwidth / 2 + "px");
			action.setCss(name, 'left', "165px");

		},
		ForecastIconsTemp: function(){
			var width = 210,
			height = 60,
			iconwidth = 30,
			elementName = '',
			elementArray = ['day1icon', 'day2icon', 'day3icon', 'day4icon', 'day1day', 'day2day','day3day','day4day','day1high', 'day2high','day3high','day4high','day1low','day2low','day3low','day4low'],
			panel, panelDomElement;
			for (var index = 0; index < elementArray.length; index++) {
				elementName = elementArray[index];
				action.addtoScreen(elementName);
				action.selectedItem = elementName;
				switch (elementName) {
					case 'day1icon':
							panel = customPanel.makeFirstPanel();
							panelDomElement = doc.getElementById(panel);

							action.setCss(panel, 'width', width+'px');
							action.setCss(panel, 'height', height+'px');
							action.setCss(panel, 'background-color', 'rgba(0,0,0,0.8)');
							//action.setCss(panel, 'background-color', 'red');
							action.setCss(panel, 'border-radius', '10px');
							action.setCss(panel, 'left', 320 / 2 - panelDomElement.offsetWidth / 2 + "px");

							var name = 'swhite'
							$('.icon').attr('src', 'weather/real/' + name + '.png');
							action.savedElements.iconName = name;
							action.saveStorage();
							setIconStyles(elementName, width, height, iconwidth);
						break;
					case 'day2icon':
					case 'day3icon':
					case 'day4icon':
							var name = 'swhite'
							$('.icon').attr('src', 'weather/real/' + name + '.png');
							action.savedElements.iconName = name;
							action.saveStorage();
							customPanel.addToPanel(panel);
							setIconStyles(elementName, width, height, iconwidth);
						break;
					case 'day1day':
					case 'day2day':
					case 'day3day':
					case 'day4day':
							customPanel.addToPanel(panel);
							setDayStyles(elementName, width, height, iconwidth);
						break;
					case 'day1high':
					case 'day1low':
					case 'day2high':
					case 'day2low':
					case 'day3high':
					case 'day3low':
					case 'day4high':
					case 'day4low':
							customPanel.addToPanel(panel);
							setTempStyles(elementName, width, height, iconwidth);
						break;
					default:
						break;
				}
			}
		},
		StockLook: function(){
			var panel = null, panelEl;
			action.addtoScreen('zclock');
			action.selectedItem = 'zclock';

			panel = customPanel.makeFirstPanel();
			panelEl = doc.getElementById(panel);

			//set panel
			var width = 250;
			var height = 125;
			var top = 80;
			action.setCss(panel, 'width', width+'px');
			action.setCss(panel, 'top', top+'px');
			action.setCss(panel, 'height', height+'px');
			action.setCss(panel, 'background-color', 'transparent');
			action.setCss(panel, 'border-radius', '10px');
			action.setCss(panel, 'left', 320 / 2 - panelEl.offsetWidth / 2 + "px");

			//set clock
			panelEl = 'zclock';
			action.setCss(panelEl, 'font-size', '70px');
			action.setCss(panelEl, 'width', width+'px');
			action.setCss(panelEl, 'text-align', 'center');
			action.setCss(panelEl, 'font-family', '-apple-system, BlinkMacSystemFont, sans-serif');
			action.setCss(panelEl, 'font-weight', '200');
			customPanel.addToPanel(panel);

			//set date
			action.addtoScreen('datestring');
			panelEl = 'datestring';
			action.selectedItem = 'datestring';
			customPanel.addToPanel(panel);

			action.setCss(panelEl, 'font-size', '18px');
			action.setCss(panelEl, 'width', width+'px');
			action.setCss(panelEl, 'text-align', 'center');
			action.setCss(panelEl, 'font-family', '-apple-system, BlinkMacSystemFont, sans-serif');
			action.setCss(panelEl, 'font-weight', '400');
			action.setCss(panelEl, 'top', '80px');
		},
		StockLook: function(){
			var panel = null, panelEl;
			action.addtoScreen('zclock');
			action.selectedItem = 'zclock';

			panel = customPanel.makeFirstPanel();
			panelEl = doc.getElementById(panel);

			//set panel
			var width = 250;
			var height = 125;
			var top = 80;
			action.setCss(panel, 'width', width+'px');
			action.setCss(panel, 'top', top+'px');
			action.setCss(panel, 'height', height+'px');
			action.setCss(panel, 'background-color', 'transparent');
			action.setCss(panel, 'border-radius', '10px');
			action.setCss(panel, 'left', 320 / 2 - panelEl.offsetWidth / 2 + "px");

			//set clock
			panelEl = 'zclock';
			action.setCss(panelEl, 'font-size', '70px');
			action.setCss(panelEl, 'width', width+'px');
			action.setCss(panelEl, 'text-align', 'center');
			action.setCss(panelEl, 'font-family', '-apple-system, BlinkMacSystemFont, sans-serif');
			action.setCss(panelEl, 'font-weight', '200');
			customPanel.addToPanel(panel);

			//set date
			action.addtoScreen('datestring');
			panelEl = 'datestring';
			action.selectedItem = 'datestring';
			customPanel.addToPanel(panel);

			action.setCss(panelEl, 'font-size', '18px');
			action.setCss(panelEl, 'width', width+'px');
			action.setCss(panelEl, 'text-align', 'center');
			action.setCss(panelEl, 'font-family', '-apple-system, BlinkMacSystemFont, sans-serif');
			action.setCss(panelEl, 'font-weight', '400');
			action.setCss(panelEl, 'top', '80px');
		},
		MusicPlayer: function(){
			var panel = null, panelEl;
			action.addtoScreen('playmusic');
			action.selectedItem = 'playmusic';
			

			panel = customPanel.makeFirstPanel();
			panelEl = doc.getElementById(panel);
			customPanel.addToPanel(panel);
			//set panel
			var width = 225;
			var height = 225;
			var top = 120;
			var buttonTop = 185;
			action.setCss(panel, 'width', width+'px');
			action.setCss(panel, 'top', top+'px');
			action.setCss(panel, 'height', height+'px');
			action.setCss(panel, 'background-color', 'transparent');
			action.setCss(panel, 'border-radius', '10px');
			action.setCss(panel, 'overflow', 'hidden');
			action.setCss(panel, 'z-index', 9);
			action.setCss(panel, 'left', 320 / 2 - panelEl.offsetWidth / 2 + "px");

			//play
			action.setCss('playmusic', 'top', buttonTop + "px");	
			action.setCss('playmusic', 'width', 40 + "px");	
			action.setCss('playmusic', 'text-align', 'center');	
			action.setCss('playmusic', 'z-index', 4);
			action.setCss('playmusic', 'left', panelEl.offsetWidth / 2 - 20 + "px");

			//prev
			action.addtoScreen('prevmusic');
			action.selectedItem = 'prevmusic';
			customPanel.addToPanel(panel);
			action.setCss('prevmusic', 'top', buttonTop + "px");
			action.setCss('prevmusic', 'width', 40 + "px");	
			action.setCss('prevmusic', 'text-align', 'center');	
			action.setCss('prevmusic', 'z-index', 4);
			action.setCss('prevmusic', 'left', panelEl.offsetWidth / 2 - 80 + "px");

			action.addtoScreen('nextmusic');
			action.selectedItem = 'nextmusic';
			customPanel.addToPanel(panel);
			action.setCss('nextmusic', 'top', buttonTop + "px");
			action.setCss('nextmusic', 'width', 40 + "px");	
			action.setCss('nextmusic', 'text-align', 'center');	
			action.setCss('nextmusic', 'z-index', 4);
			action.setCss('nextmusic', 'left', panelEl.offsetWidth / 2 + 50 + "px");

			action.addtoScreen('boxTwenty');
			action.selectedItem = 'boxTwenty';
			customPanel.addToPanel(panel);
			action.setCss('boxTwenty', 'width', width + 'px');
			action.setCss('boxTwenty', 'top', panelEl.offsetWidth-49 + "px");
			action.setCss('boxTwenty', 'height', 50+'px');
			action.setCss('boxTwenty', 'z-index', 3);
			action.setCss('boxTwenty', 'background-color', 'rgba(0,0,0,0.6)');
			action.setCss('boxTwenty', '-webkit-backdrop-filter','blur(1px)');

			action.addtoScreen('songalbumArtnohide');
			action.selectedItem = 'songalbumArtnohide';
			customPanel.addToPanel(panel);
			action.setCss('songalbumArtnohide', 'width', width + 'px');
			action.setCss('songalbumArtnohide', 'height', height + 'px');
			action.setCss('songalbumArtnohide', 'z-index', 0);
			action.setCss('songalbumArtnohide', 'border-radius', '10px');
		},
		JMusic: function(){
			var panel = null, panelEl;
			action.addtoScreen('playmusic');
			action.selectedItem = 'playmusic';

			panel = customPanel.makeFirstPanel();
			panelEl = doc.getElementById(panel);
			customPanel.addToPanel(panel);

			//set panel
			var width = 300;
			var height = 100;
			var top = 125;
			var buttonTop = 65;

			action.setCss(panel, 'width', width+'px');
			action.setCss(panel, 'top', top+'px');
			action.setCss(panel, 'height', height+'px');
			action.setCss(panel, 'background-color', 'rgba(0,0,0,0.6)');
			action.setCss(panel, '-webkit-backdrop-filter','blur(5px)');
			action.setCss(panel, 'border-radius', '10px');
			action.setCss(panel, 'overflow', 'hidden');
			action.setCss(panel, 'z-index', 9);
			action.setCss(panel, 'left', 320 / 2 - panelEl.offsetWidth / 2 + "px");

			//prev
			action.addtoScreen('prevmusic');
			action.selectedItem = 'prevmusic';
			customPanel.addToPanel(panel);
			action.setCss('prevmusic', 'top', buttonTop + "px");
			action.setCss('prevmusic', 'width', 40 + "px");	
			action.setCss('prevmusic', 'text-align', 'center');	
			action.setCss('prevmusic', 'z-index', 4);
			action.setCss('prevmusic', 'left', 160 + "px");

			//play
			action.setCss('playmusic', 'top', buttonTop + "px");	
			action.setCss('playmusic', 'width', 40 + "px");	
			action.setCss('playmusic', 'text-align', 'center');	
			action.setCss('playmusic', 'z-index', 4);
			action.setCss('playmusic', 'left', 205 + "px");


			//next
			action.addtoScreen('nextmusic');
			action.selectedItem = 'nextmusic';
			customPanel.addToPanel(panel);
			action.setCss('nextmusic', 'top', buttonTop + "px");
			action.setCss('nextmusic', 'width', 40 + "px");	
			action.setCss('nextmusic', 'text-align', 'center');	
			action.setCss('nextmusic', 'z-index', 4);
			action.setCss('nextmusic', 'left', 250 + "px");

			//box
			// action.addtoScreen('boxTwenty');
			// action.selectedItem = 'boxTwenty';
			// customPanel.addToPanel(panel);
			// action.setCss('boxTwenty', 'width', width + 'px');
			// action.setCss('boxTwenty', 'top', panelEl.offsetWidth-49 + "px");
			// action.setCss('boxTwenty', 'height', 50+'px');
			// action.setCss('boxTwenty', 'z-index', 3);
			// action.setCss('boxTwenty', 'background-color', 'rgba(0,0,0,0.6)');
			// action.setCss('boxTwenty', '-webkit-backdrop-filter','blur(1px)');

			//album art
			action.addtoScreen('songalbumArtnohide');
			action.selectedItem = 'songalbumArtnohide';
			customPanel.addToPanel(panel);
			action.setCss('songalbumArtnohide', 'top', 7 + 'px');
			action.setCss('songalbumArtnohide', 'left', 10 + 'px');
			action.setCss('songalbumArtnohide', 'width', 85 + 'px');
			action.setCss('songalbumArtnohide', 'height', 85 + 'px');
			action.setCss('songalbumArtnohide', 'z-index', 0);
			action.setCss('songalbumArtnohide', 'border-radius', '5px');

			action.addtoScreen('songartistnohide');
			action.selectedItem = 'songartistnohide';
			customPanel.addToPanel(panel);
			action.setCss('songartistnohide', 'font-weight', '400');
			action.setCss('songartistnohide', 'font-family', 'helvetica');
			action.setCss('songartistnohide', 'font-size', 13 + "px");
			action.setCss('songartistnohide', 'top', 14 + "px");
			action.setCss('songartistnohide', 'width', 200 + "px");	
			action.setCss('songartistnohide', 'text-align', 'left');	
			action.setCss('songartistnohide', 'z-index', 4);
			action.setCss('songartistnohide', 'left', 110 + "px");

			action.addtoScreen('songtitlenohide');
			action.selectedItem = 'songtitlenohide';
			customPanel.addToPanel(panel);
			action.setCss('songartistnohide', 'font-weight', '100');
			action.setCss('songtitlenohide', 'font-family', 'helvetica');
			action.setCss('songtitlenohide', 'font-size', 13 + "px");
			action.setCss('songtitlenohide', 'top', 30 + "px");
			action.setCss('songtitlenohide', 'width', 200 + "px");	
			action.setCss('songtitlenohide', 'text-align', 'left');	
			action.setCss('songtitlenohide', 'z-index', 4);
			action.setCss('songtitlenohide', 'left', 110 + "px");
		}
	}

	function createCreation(name){
		if(creations[name]){
			creations[name]();
		}
	}
    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.make = function(name) {
            createCreation(name);
        };
        return externalMethods;
    }
    window.creator = initExternalMethods();
}(window, document));

// setTimeout(function(){
// 	creator.make('JMusic');
// },2000);