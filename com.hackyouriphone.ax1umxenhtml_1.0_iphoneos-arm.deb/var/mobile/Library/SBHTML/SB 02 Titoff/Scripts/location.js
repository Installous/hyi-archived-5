// Require JQuery !

// weather script hosted and created by Alexis CHERON (IAJcraft)
// Twitter Dev: @IAJcraftDev (#IAJcraftSupport for support)

var WeatherConfig = {
       LocationID:  locale,             // Location ID can be get at http://iajcraft-ht.ml/weather/ 
             Unit:  tempUnit,           // Celsius or Farenheit: "c" or "f".
   UpdateInterval:  updateInterval,     // Update interval in minutes.
      WeatherIcon:  iconSet             // Location of weather icons
}


function weather(callback){

   $.ajax({
    url:"http://api.iajcraft-ht.ml/weather/v1/",
    type:'GET',
    crossDomain : true,
    data: {loc: window.WeatherConfig.LocationID, unit: window.WeatherConfig.Unit, type: "jsonp"},
    dataType:'jsonp',
    jsonpCallback: 'processJSON',
    success: function(data){
        callback(data);
    }
});

} 

setTimeout(function(){ // On start of theme

    $("#cityname").html("Loading City...");
    weather(window.showWeather); 

}, 5);

if(WeatherConfig.UpdateInterval > 0)
    setInterval(function(){ weather(window.showWeather); }, WeatherConfig.UpdateInterval * 60 * 1000);






/*

Variables:


 today.code:  Return the weather code
 today.date:  Return the date in "26 Aug 2016" format
 today.temp:  Return the temperature in Celsius or Farenheit
 today.weekday:  Return the three first letters of the weekday ("Mon", "Tue", ...)
 today.description:  Return the description of the weather

*/



function showWeather(WeatherAPI){var today=WeatherAPI.weather.today;

    // Set the actions below

    $("#temp").html(today.temp + " °" + WeatherAPI.units.temp);
    dealWithWeather(today.description);
    $("#todaydate").html(today.date);
    $("#todayweekday").html(today.weekday);
    $("#cityname").html(WeatherAPI.location.city);
    $("#regionname").html(WeatherAPI.location.region);
    $("#weatherIcon").attr("src", "Imagenes/" + window.WeatherConfig.WeatherIcon + "/" + today.code + ".png");

}





